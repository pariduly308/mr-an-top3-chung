"""Cùng sáu cách xếp hạng với bản web; tỷ lệ lịch sử không phải cam kết kỳ tới."""
from .domain import now_vn, stations_on, expected_keys, VN

METHODS = ['frequency','recent10','recent20','recent50','gap','repeat']

def rank(draws,digits,method='frequency'):
    rows=[dict(number=str(n).zfill(digits),hits=0,total=0,gap=len(draws),last='Chưa thấy',recent10=0,recent20=0,recent50=0,repeat=0,count=len(draws)) for n in range(10**digits)]
    for i,draw in enumerate(draws):
        counts={}
        for value in draw['numbers']:
            if len(value)>=digits:
                n=int(value[-digits:]);counts[n]=counts.get(n,0)+1
        for n,count in counts.items():
            row=rows[n];row['hits']+=1;row['total']+=count;row['gap']=len(draws)-i-1;row['last']=draw['date']
            for window in (10,20,50):
                if i>=len(draws)-window:row['recent'+str(window)]+=1
            if i==len(draws)-1:row['repeat']=count
    return sorted(rows,key=lambda r:(-score(r,method),-r['hits'],r['number']))

def score(row,method):
    if method=='gap':return row['hits']*min(row['gap'],20)/20
    return row['hits'] if method=='frequency' else row[method]

PAIRS=[['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An'],['Tiền Giang','Kiên Giang']]

def pair_history(draws,pair):
    from collections import defaultdict
    grouped=defaultdict(dict)
    for r in draws:
        if r['station'] in pair:grouped[r['date']][r['station']]=r['numbers']
    return [dict(date=day,station=' + '.join(pair),numbers=sum([parts[s] for s in pair],[])) for day,parts in sorted(grouped.items()) if all(s in parts for s in pair)]

def capture_forecasts(db,now=None):
    now=(now or now_vn()).astimezone(VN);today=now.date().isoformat();draws=db.draws();saved=[]
    missing=set(expected_keys(db.meta('start_date',today),now))-db.keys()
    pair=PAIRS[now.weekday()]
    for members in [pair,['XSMB']]:
        station=' + '.join(members);north=station=='XSMB'
        if now.hour >= (18 if north else 16):continue
        if any(r['date']==today and r['station'] in members for r in draws):continue
        history=[r for r in draws if r['station']=='XSMB'] if north else pair_history(draws,pair)
        history=[r for r in history if r['date']<today]
        if len(history)<30 or any(s in members for _,s in missing):continue
        predictions={str(d):{m:[r['number'] for r in rank(history,d,m)[:3]] for m in METHODS} for d in (2,3)}
        snapshot=dict(date=today,station=station,members=members,createdAt=now.isoformat(),historyThrough=history[-1]['date'],historyCount=len(history),version='six-methods-v1-local' if north else 'pair-six-v1',predictions=predictions)
        if db.save_forecast(snapshot):saved.append(station)
    return saved

def tracking_report(db):
    draws={(r['date'],r['station']):r for r in db.draws()};result=[]
    for snapshot in db.forecasts():
        members=snapshot.get('members',[snapshot['station']]);actual=[draws.get((snapshot['date'],s)) for s in members];complete=all(actual);scores={}
        for d in (2,3):
            tails={n[-d:] for draw in actual for n in draw['numbers'] if len(n)>=d} if complete else set()
            scores[str(d)]={m:[n for n in ns if n in tails] if complete else None for m,ns in snapshot['predictions'][str(d)].items()}
        result.append(dict(snapshot,scores=scores,complete=complete))
    return result
