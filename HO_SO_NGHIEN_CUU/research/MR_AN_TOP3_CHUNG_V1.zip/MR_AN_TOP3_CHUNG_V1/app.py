"""Mr Ân xổ số: chạy tại máy, chỉ dùng thư viện chuẩn Python 3.10+."""
import argparse
import json
import os
import secrets
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from modules.domain import HOLIDAYS
from modules.database import Database
from modules.sync import SyncManager
from modules.analysis import tracking_report, capture_forecasts

ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
HOME=Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else ROOT

def create_server(db,sync,port=8775):
    token=secrets.token_urlsafe(32)
    page=(ROOT/'web/page.html').read_text(encoding='utf-8')
    page=page.replace('/*ANALYSIS*/',(ROOT/'web/analysis.js').read_text(encoding='utf-8').replace('export ',''))
    page=page.replace('/*UI*/',(ROOT/'web/ui.js').read_text(encoding='utf-8')).replace('__LOCAL_TOKEN__',token).replace('__HOLIDAYS__',json.dumps(HOLIDAYS))
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def send(self,data,content_type='application/json; charset=utf-8',status=200):
            body=data.encode('utf-8') if isinstance(data,str) else json.dumps(data,ensure_ascii=False).encode('utf-8')
            self.send_response(status);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body)
        def allowed_host(self):
            return self.headers.get('Host') in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
        def do_GET(self):
            if not self.allowed_host():return self.send({'error':'Host không hợp lệ'},status=403)
            path=urlsplit(self.path).path
            if path=='/':return self.send(page,'text/html; charset=utf-8')
            if path=='/analysis-worker.js':
                code=(ROOT/'web/analysis.js').read_text(encoding='utf-8').replace('export ','')+'\nonmessage=e=>postMessage(backtest(e.data.history,e.data.digits));'
                return self.send(code,'text/javascript; charset=utf-8')
            if path=='/data.json':return self.send(db.draws())
            if path=='/api/status':return self.send(sync.status())
            if path=='/api/tracking':return self.send(tracking_report(db))
            if path=='/api/health':return self.send({'app':'mr-an-top3-chung-v1'})
            return self.send({'error':'Không tìm thấy'},status=404)
        def do_POST(self):
            origin=self.headers.get('Origin')
            if not self.allowed_host() or self.headers.get('X-Local-Token')!=token or (origin and origin not in {f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'}):
                return self.send({'error':'Yêu cầu không hợp lệ. Tải lại trang app.'},status=403)
            path=urlsplit(self.path).path
            if path=='/api/update':
                started=sync.start();return self.send({'started':started,'inProgress':True},status=202)
            if path=='/api/forecast':return self.send({'saved':capture_forecasts(db)})
            return self.send({'error':'Không tìm thấy'},status=404)
    return ThreadingHTTPServer(('127.0.0.1',port),Handler)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--no-browser',action='store_true');parser.add_argument('--no-sync',action='store_true',help='Mở hoàn toàn offline');parser.add_argument('--port',type=int,default=8775);parser.add_argument('--data-dir',type=Path,default=HOME/'data_top3_chung');args=parser.parse_args()
    db=Database(args.data_dir/'top3_chung.db');db.seed(ROOT/'seed.json');capture_forecasts(db);sync=SyncManager(db)
    try:server=create_server(db,sync,args.port)
    except OSError:
        # Chỉ dùng lại cửa sổ nếu đúng app này đang mở trên cổng đã chọn.
        from urllib.request import urlopen
        try:
            with urlopen(f'http://127.0.0.1:{args.port}/api/health',timeout=2) as r:health=json.load(r)
            if health.get('app')=='mr-an-top3-chung-v1':
                if not args.no_browser:webbrowser.open(f'http://127.0.0.1:{args.port}')
                return
        except Exception:pass
        raise RuntimeError('Cổng đang được sử dụng. Chạy với --port 8776 hoặc đóng chương trình đang dùng cổng.')
    url=f'http://127.0.0.1:{server.server_port}'
    print('Mr Ân / Top 3 chung\n'+url+'\nĐóng cửa sổ này hoặc nhấn Ctrl+C để thoát.',flush=True)
    if not args.no_sync:
        sync.start();threading.Thread(target=sync.periodic,daemon=True).start()
    if not args.no_browser:threading.Timer(0.5,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:sync.stop_event.set();server.server_close()

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('LỖI: '+str(exc),file=sys.stderr);sys.exit(1)
