import json,time,subprocess
from pathlib import Path
p=Path(__file__).parent
while True:
 try:m=json.loads((p/'manifest.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):m=[]
 if len(m)==523:break
 time.sleep(5)
assert not any('error'in r for r in m)
for cmd in [['node',str(p/'parse.mjs')],['python',str(p/'quality.py')],['python',str(p/'verify.py')],['python',str(p/'backtest.py')],['node',str(p/'verify_rank.mjs')],['python',str(p/'evaluate.py')],['python',str(p/'report.py')]]:
 print('STEP',cmd[-1],flush=True);subprocess.run(cmd,check=True)
