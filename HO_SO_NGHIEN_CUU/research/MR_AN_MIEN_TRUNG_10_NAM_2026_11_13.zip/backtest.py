import json,csv,datetime,collections,math
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent;rows=json.loads((p/'data.json').read_text())
groups=collections.defaultdict(list)
for r in rows:groups[r['station']].append(r)
methods=['frequency','recent10','recent20','recent50','gap','repeat'];summ=collections.defaultdict(lambda:[0,0]);primary={};out=p/'retrospective_predictions.csv'
def lower(date,y):
 d=datetime.date.fromisoformat(date)
 try:return d.replace(year=d.year-y).isoformat()
 except ValueError:return d.replace(year=d.year-y,month=3,day=1).isoformat()
with out.open('w') as f:
 w=csv.writer(f);w.writerow(['date','target','digits','method','years','training_draws','top3','hit'])
 for station,ds in groups.items():
  ds.sort(key=lambda r:r['date']);dates=np.array([r['date'] for r in ds]);n=len(ds)
  for digits in [2,3]:
   size=10**digits;nums=np.arange(size);count=np.zeros((n,size),dtype=np.int16)
   for i,r in enumerate(ds):
    for x in r['numbers']:
     if len(x)>=digits:count[i,int(x[-digits:])]+=1
   hits=count>0;prefix=np.vstack([np.zeros((1,size),dtype=np.int32),np.cumsum(hits,axis=0,dtype=np.int32)]);last=np.full(size,-1,dtype=np.int32)
   for i,date in enumerate(dates):
    if date>='2021-11-10':
     actual=hits[i];records={}
     for y in [1,3,5]:
      lo=int(np.searchsorted(dates,lower(str(date),y)));h=prefix[i]-prefix[lo];gap=np.where(last>=lo,i-last-1,i-lo)
      scores=[h,*[prefix[i]-prefix[max(lo,i-k)] for k in [10,20,50]],h*np.minimum(gap,20)/20,count[i-1]]
      for method,sc in zip(methods,scores):
       top=np.lexsort((nums,-h,-sc))[:3];hit=int(actual[top].any());w.writerow([date,station,digits,method,y,i-lo,' '.join(str(x).zfill(digits) for x in top),hit])
       for yr in [str(date)[:4],'ALL']:
        a=summ[(station,digits,method,y,yr)];a[0]+=hit;a[1]+=1
       if digits==2 and ((' + 'in station and method=='repeat') or(station=='XSMB'and method=='frequency')):records[y]=hit
     if records:primary[(str(date),station)]=records
    last[hits[i]]=i
  print('done',station,n,flush=True)
summary=[]
for (station,digits,method,years,year),(wins,n) in sorted(summ.items()):
 z=1.96;ph=wins/n;den=1+z*z/n;center=(ph+z*z/(2*n))/den;half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
 summary.append(dict(target=station,digits=digits,method=method,years=years,year=year,wins=wins,n=n,rate=ph,wilson95=[max(0,center-half),min(1,center+half)]))

(p/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
