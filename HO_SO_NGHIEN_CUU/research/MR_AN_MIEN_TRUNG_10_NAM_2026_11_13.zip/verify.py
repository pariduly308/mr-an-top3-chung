from lxml import html
from pathlib import Path
import json,re,collections,random
p=Path(__file__).parent;data=json.loads((p/'data.json').read_text());by={(r['date'],r['station']):r['numbers']for r in data};files=sorted((p/'pages').glob('mien-trung*'));tested=0
for i in sorted(set([0,len(files)//2,len(files)-1,*range(0,len(files),40)])):
 root=html.fromstring(files[i].read_bytes())
 for b in root.xpath('//div[@class="box_kqxs"]'):
  links=b.xpath('.//*[@class="title"]//a/@href');dates=[]
  for link in links:
   m=re.search(r'/mien-trung/(\d{2})-(\d{2})-(\d{4})\.html',link)
   if m:dates.append(f'{m[3]}-{m[2]}-{m[1]}')
  if not dates:continue
  day=dates[0]
  for t in b.xpath('.//table[@class="rightcl"]'):
   station=''.join(t.xpath('.//td[@class="tinh"]/a/text()')).strip()
   if (day,station)not in by:continue
   numbers=[]
   for name in ['giai8','giai7','giai6','giai5','giai4','giai3','giai2','giai1','giaidb']:
    vals=t.xpath(f'.//td[@class="{name}"]/div/text()');numbers.extend(v.strip()for v in vals)
   assert numbers==by[(day,station)],(day,station,numbers,by[(day,station)])
   tested+=1
print('Independent DOM parsed tables checked:',tested)
assert tested>=40
(p/'verification.json').write_text(json.dumps({'independent_DOM_tables':tested,'matched':True}))
