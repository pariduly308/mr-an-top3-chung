from pathlib import Path
import json,collections,datetime
p=Path(__file__).parent;a=json.loads((p/'parse_audit.json').read_text());rows=json.loads((p/'data.json').read_text());expected={2:1,3:1,4:4,5:11,6:1}
assert len({(r['date'],r['station']) for r in rows})==len(rows)
assert all(collections.Counter(map(len,r['numbers']))==({2:1,3:1,4:4,5:12} if r['date']<'2017-04-01' else expected) and all(n.isascii()and n.isdigit()for n in r['numbers'])for r in rows)
coverage=[]
for r in a['coverage']:
 day=r['file'].removeprefix('mien-trung_').removesuffix('.html');coverage.append({'file':r['file'],'request_date':day,'request_present':day in r['dates'],'min_date':min(r['dates'])if r['dates']else None,'max_date':max(r['dates'])if r['dates']else None,'future_dates':[d for d in r['dates']if d>day]})
assert not any(r['future_dates']for r in coverage)
by=collections.defaultdict(list)
for r in rows:by[r['station']].append(r)
res={'tables':len(rows),'first':min(r['date']for r in rows),'last':max(r['date']for r in rows),'duplicates':0,'conflicts':a['conflicts'],'invalid_shapes':0,'leading_zero_values':sum(n.startswith('0')for r in rows for n in r['numbers']),'request_date_not_present':[r for r in coverage if not r['request_present']],'stations':{s:{'n':len(rs),'first':rs[0]['date'],'last':rs[-1]['date'],'weekday_counts':dict(collections.Counter(datetime.date.fromisoformat(r['date']).weekday()for r in rs))}for s,rs in by.items()}}
(p/'quality.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False))
