export function parse(html,region){
 const result=[];const shapes=region==='mien-bac'?{giai7:[4,2],giai6:[3,3],giai5:[6,4],giai4:[4,4],giai3:[6,5],giai2:[2,5],giai1:[1,5],giaidb:[1,5]}:{giai8:[1,2],giai7:[1,3],giai6:[3,4],giai5:[1,4],giai4:[7,5],giai3:[2,5],giai2:[1,5],giai1:[1,5],giaidb:[1,6]};
 for(const block of html.split('<div class="box_kqxs">').slice(1)){
  const match=block.match(new RegExp('class="title"[\\s\\S]*?/('+region+')/(\\d{2})-(\\d{2})-(\\d{4})\\.html'));if(!match)continue;
  const date=`${match[4]}-${match[3]}-${match[2]}`;if(region==='mien-trung')shapes.giaidb=[1,date<'2017-04-01'?5:6];const dt=new Date(date+'T12:00:00Z');if(!Number.isFinite(+dt)||dt.toISOString().slice(0,10)!==date)continue;
  const tables=region!=='mien-bac'?[...block.matchAll(/<table[^>]*class="rightcl"[^>]*>([\s\S]*?)<\/table>/g)].map(m=>m[1]):[block];
  for(const table of tables){
   const station=region==='mien-bac'?'XSMB':table.match(/class="tinh"[^>]*>\s*<a[^>]*>(.*?)<\/a>/s)?.[1].trim();if(!station)continue;
   const prizes={};let bad=false;
   for(const cell of table.matchAll(/<td class="(giai[1-8]|giaidb)"[^>]*>([\s\S]*?)<\/td>/g)){
    if(!shapes[cell[1]]||prizes[cell[1]]){bad=true;break;}
    const ns=[...cell[2].matchAll(/<div[^>]*>\s*(\d{2,6})\s*<\/div>/g)].map(x=>x[1]),[count,width]=shapes[cell[1]];
    if(ns.length!==count||ns.some(n=>n.length!==width)){bad=true;break;}prizes[cell[1]]=ns;
   }
   if(!bad&&Object.keys(shapes).every(k=>prizes[k]))result.push({date,station,numbers:Object.keys(shapes).flatMap(k=>prizes[k])});
  }
 }
 return result;
}
