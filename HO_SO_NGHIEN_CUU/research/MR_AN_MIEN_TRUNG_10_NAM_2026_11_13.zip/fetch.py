import concurrent.futures,datetime,json,time,urllib.request,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;out=p/'pages';out.mkdir(exist_ok=True)
end=datetime.date(2026,11,12);start=datetime.date(2016,11,10)
jobs=[]
while end>=start:
 for region in ['mien-trung']:jobs.append((region,end))
 end-=datetime.timedelta(days=7)
def run(job):
 region,day=job;name=f'{region}_{day.isoformat()}.html';path=out/name;url=f'https://www.minhngoc.net.vn/ket-qua-xo-so/{region}/{day:%d-%m-%Y}.html'
 if path.exists():return {'url':url,'file':name,'cached':True,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 for attempt in range(2):
  try:
   with urllib.request.urlopen(url,timeout=25) as r:b=r.read()
   if b'box_kqxs' not in b:raise ValueError('No result table')
   path.write_bytes(b);return {'url':url,'file':name,'bytes':len(b),'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(b).hexdigest()}
  except Exception as e:
   if attempt:return {'url':url,'file':name,'error':type(e).__name__+': '+str(e)}
manifest=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for i,r in enumerate(ex.map(run,jobs),1):
  manifest.append(r)
  if i%40==0:print(i,'/',len(jobs),'errors',sum('error'in x for x in manifest),flush=True)
  (p/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('DONE',len(manifest),'errors',sum('error'in x for x in manifest),flush=True)
