import json,collections,datetime,hashlib,math
from pathlib import Path
import pandas as pd,numpy as np
p=Path(__file__).parent
rows=json.loads((p/'data.json').read_text());a=json.loads((p/'parse_audit.json').read_text());manifest=json.loads((p/'manifest.json').read_text());assert not a['conflicts'];assert len(manifest)==523 and not any('error'in r for r in manifest)
f=pd.read_csv(p/'retrospective_predictions.csv',dtype={'top3':str,'date':str});f['period']=np.where(f.date<'2024-11-10','development',np.where(f.date<'2025-11-10','validation','late'))
baselines={}
for r in rows:
 for d in [2,3]:
  u=len(set(n[-d:]for n in r['numbers']if len(n)>=d));N=10**d;baselines[(r['date'],r['station'],d)]=1-math.comb(N-u,3)/math.comb(N,3)
f['uniform']=[baselines[(r.date,r.target,r.digits)] for r in f.itertuples()]
g=f.groupby(['digits','method','years','period']).agg(wins=('hit','sum'),n=('hit','size'),rate=('hit','mean'),uniform=('uniform','mean')).reset_index();g.to_csv(p/'aggregate.csv',index=False)
selected=[];comparisons=[];rng=np.random.default_rng(131126)
for d in [2,3]:
 v=g[(g.digits==d)&(g.period=='validation')].sort_values(['rate','method','years'],ascending=[False,True,True]).iloc[0];m=v['method'];y=int(v['years']);sel=f[(f.digits==d)&(f.method==m)&(f.years==y)&(f.period=='late')];selected.append({'digits':d,'method':m,'years':y,'validation_rate':float(v.rate),'late_rate':float(sel.hit.mean()),'n':len(sel)})
 for control in ['frequency','repeat','uniform']:
  if control=='uniform':t=sel[['date','target','hit','uniform']].copy();t['control']=t.uniform
  else:
   c=f[(f.digits==d)&(f.method==control)&(f.years==5)&(f.period=='late')][['date','target','hit']].rename(columns={'hit':'control'});t=sel[['date','target','hit']].merge(c,on=['date','target'],validate='one_to_one')
  t['delta']=t.hit-t.control;by=t.groupby('date').agg(delta=('delta','sum'),n=('delta','size'));D=by.delta.to_numpy();N=by.n.to_numpy();n=len(by);vals=[]
  for _ in range(10000):
   ix=((rng.integers(n,size=math.ceil(n/7))[:,None]+np.arange(7))%n).ravel()[:n];vals.append(D[ix].sum()/N[ix].sum())
  diff=t.delta.mean();null=np.array(vals)-diff;pv=(1+np.sum(np.abs(null)>=abs(diff)))/(len(null)+1)
  comparisons.append({'digits':d,'method':m,'years':y,'control':control,'n_draws':len(t),'n_days':n,'candidate':float(t.hit.mean()),'control_rate':float(t.control.mean()),'difference':float(diff),'ci95':np.quantile(vals,[.025,.975]).tolist(),'p_bootstrap_approx':float(pv),'per_station_delta':t.groupby('target').delta.mean().to_dict()})
order=sorted(range(len(comparisons)),key=lambda i:comparisons[i]['p_bootstrap_approx']);prior=0
for j,i in enumerate(order):
 prior=max(prior,min(1,(len(order)-j)*comparisons[i]['p_bootstrap_approx']));comparisons[i]['holm_p_approx']=prior
(p/'evaluation.json').write_text(json.dumps({'selected_on_validation':selected,'comparisons':comparisons,'warning':'Retrospective only; block-bootstrap approximate inference, historical gaps unresolved; no future proof.'},ensure_ascii=False,indent=2))
# Calendar screening is not evidence a missing table should exist.
schedule={0:['Huế','Phú Yên'],1:['Đắk Lắk','Quảng Nam'],2:['Đà Nẵng','Khánh Hòa'],3:['Bình Định','Quảng Trị','Quảng Bình'],4:['Gia Lai','Ninh Thuận'],5:['Đà Nẵng','Quảng Ngãi','Đắk Nông'],6:['Khánh Hòa','Kon Tum','Huế']}
unexpected=[{'date':r['date'],'station':r['station']} for r in rows if r['station'] not in schedule[datetime.date.fromisoformat(r['date']).weekday()]]
(p/'unexpected_weekdays.json').write_text(json.dumps(unexpected,ensure_ascii=False,indent=2))
keys={(r['date'],r['station'])for r in rows};missing=[];date=datetime.date(2016,11,10)
while date<=datetime.date(2026,11,12):
 for s in schedule[date.weekday()]:
  if (str(date),s)not in keys:missing.append({'date':str(date),'station':s,'status':'unclassified_current_schedule_only'})
 date+=datetime.timedelta(days=1)
(p/'calendar_review.json').write_text(json.dumps(missing,ensure_ascii=False,indent=2))
print(json.dumps({'tables':len(rows),'stations':a['stations'],'selected':selected,'comparisons':comparisons,'calendar_unclassified':len(missing)},ensure_ascii=False))
