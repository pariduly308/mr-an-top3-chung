"""Offline research only. No writes to Site, forecasts, or production code."""
import json
import csv
from collections import defaultdict,deque
from datetime import date
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
METHODS=['frequency','recent10','recent20','recent50','gap','repeat']
LABELS=['Tần suất toàn kỳ','10 kỳ gần nhất','20 kỳ gần nhất','50 kỳ gần nhất','Hay ra và đang vắng','Lặp nhiều ở kỳ trước']
rows=json.loads((ROOT/'seed.json').read_text())
south=[r for r in rows if r['station']!='XSMB']
by_date=defaultdict(list)
for row in south:by_date[row['date']].append(row)

class State:
    def __init__(self,size):
        self.size=size
        self.n=0
        self.hits=np.zeros(size,dtype=np.int32)
        self.last=np.full(size,-1,dtype=np.int32)
        self.repeat=np.zeros(size,dtype=np.int32)
        self.recent={w:np.zeros(size,dtype=np.int32) for w in (10,20,50)}
        self.history=deque(maxlen=50)
    def top(self):
        gap=self.n-self.last-1
        scores=[self.hits,self.recent[10],self.recent[20],self.recent[50],self.hits*np.minimum(gap,20)/20,self.repeat]
        return [np.lexsort((np.arange(self.size),-self.hits,-score))[:3] for score in scores]
    def add(self,counts):
        present=(counts>0).astype(np.int32)
        for w in self.recent:
            if len(self.history)>=w:self.recent[w]-=self.history[-w]
            self.recent[w]+=present
        self.history.append(present)
        self.hits+=present
        self.last[present>0]=self.n
        self.repeat=counts.copy()
        self.n+=1

def counts_of(numbers,digits):
    c=np.zeros(10**digits,dtype=np.int32)
    for n in numbers:
        if len(n)>=digits:c[int(n[-digits:])]+=1
    return c

records=[]
for digits in (2,3):
    station_states=defaultdict(lambda:State(10**digits))
    day_state=State(10**digits)
    for day,draws in sorted(by_date.items()):
        weekday=date.fromisoformat(day).weekday()
        scored=day>='2022-11-10'
        day_top=day_state.top() if weekday<5 and scored else None
        # Build ALL forecasts before admitting any result of this day.
        for draw in draws:
            state=station_states[draw['station']]
            actual=counts_of(draw['numbers'],digits)
            if scored:
                own_top=state.top()
                for j,method in enumerate(METHODS):
                    records.append({'date':day,'station':draw['station'],'digits':digits,'method':method,'weekday':weekday,'hit_station':int(np.any(actual[own_top[j]]>0)),'hit_day':int(np.any(actual[day_top[j]]>0)) if day_top is not None else None,'top_station':','.join(str(int(n)).zfill(digits) for n in own_top[j]),'top_day':','.join(str(int(n)).zfill(digits) for n in day_top[j]) if day_top is not None else ''})
        for draw in draws:station_states[draw['station']].add(counts_of(draw['numbers'],digits))
        if weekday<5:day_state.add(counts_of([n for draw in draws for n in draw['numbers']],digits))

with (ROOT/'du_bao_hoi_cuu.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)

rng=np.random.default_rng(20261111)
def summary(part,bootstrap=False):
    n=len(part);a=sum(r['hit_station'] for r in part)
    matched=[r for r in part if r['hit_day'] is not None]
    b=sum(r['hit_day'] for r in matched);c=sum(r['hit_station'] for r in matched)
    result={'n_all':n,'station_hits_all':a,'n_matched':len(matched),'station_hits_matched':c,'day_hits_matched':b}
    if bootstrap and matched:
        # Date clusters retain dependence between stations drawing on the same day.
        days=defaultdict(lambda:[0,0])
        for r in matched:
            days[r['date']][0]+=r['hit_day']-r['hit_station'];days[r['date']][1]+=1
        v=np.array(list(days.values()));differences=[]
        for _ in range(4000):
            totals=v[rng.integers(len(v),size=len(v))].sum(axis=0)
            differences.append(totals[0]/totals[1])
        result['difference_ci95']=np.quantile(differences,[.025,.975]).tolist()
        result['difference_ci_bonferroni12']=np.quantile(differences,[.05/24,1-.05/24]).tolist()
    return result

output={'source_start':min(by_date),'source_end':max(by_date),'source_rows':len(rows),'south_rows':len(south),'warmup_end':'2022-11-09','test_start':'2022-11-10','results':{}}
for digits in (2,3):
    output['results'][str(digits)]={}
    for method in METHODS:
        part=[r for r in records if r['digits']==digits and r['method']==method]
        item=summary(part,True);item['periods']={};item['stations']={}
        for start in range(2022,2026):
            begin=f'{start}-11-10';end=f'{start+1}-11-10'
            item['periods'][begin+' / '+end]=summary([r for r in part if begin<=r['date']<end])
        for station in sorted({r['station'] for r in part}):item['stations'][station]=summary([r for r in part if r['station']==station])
        output['results'][str(digits)][method]=item
(ROOT/'ket_qua.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
for digits,methods in output['results'].items():
    print(digits)
    for method,r in methods.items():
        n=r['n_matched'];print(method,n,round(100*r['station_hits_matched']/n,2),round(100*r['day_hits_matched']/n,2),[round(100*x,2) for x in r['difference_ci_bonferroni12']])
