# So sánh hai giả thuyết trên dữ liệu 5 năm

Ngày nghiên cứu 11/11/2026. Chỉ tính thử. Chưa thay đổi thuật toán trên Site hoặc bản máy tính. Mọi cách tính muốn áp dụng phải được người dùng đồng ý trước.

## Dữ liệu và thiết kế

Dữ liệu Minh Ngọc có 7545 bảng, trong đó 5739 bảng miền Nam, từ 2021-11-10 đến 2026-11-09. Nghiên cứu này chỉ dùng miền Nam. Năm đầu đến 09/11/2022 dùng khởi tạo. Từ 10/11/2022 chấm cuốn chiếu từng kỳ đến 09/11/2026.

**Giả thuyết 1:** sáu công thức hiện hành, lịch sử riêng từng đài. Lịch sử gồm cả tuần; có báo cáo đầy đủ cả tuần và báo cáo giới hạn thứ Hai–thứ Sáu để so sánh công bằng.

**Giả thuyết 2:** giữ sáu công thức, gộp kết quả tất cả đài miền Nam trong một ngày thành một quan sát, chỉ từ thứ Hai đến thứ Sáu. Một số có mặt nhiều đài cùng ngày vẫn chỉ tăng số ngày có mặt một lần. Số lần lặp ở ngày trước tính đủ mọi lần trong các đài ngày đó. Thứ Bảy/Chủ nhật bị bỏ khỏi chuỗi giả thuyết 2. Đây là định nghĩa làm việc cho yêu cầu tính thử chuỗi thứ Hai–thứ Sáu.

Cùng một Top 3 của giả thuyết 2 được chấm riêng cho từng đài mở thưởng trong ngày. Cả hai được so trên đúng 3.129 kỳ đài thứ Hai–thứ Sáu. Đạt nếu ít nhất một số trong Top 3 xuất hiện ở bất kỳ giải đủ độ dài của đài đích. 3 số cuối bỏ giải chỉ có 2 chữ số. Tỷ lệ ở đây là tỷ lệ đạt Top 3, không phải xác suất từng số.

Dự báo cho tất cả đài trong ngày được tạo trước khi thêm bất kỳ kết quả nào của ngày đó. Tần suất toàn kỳ dùng lịch sử tích lũy. Cửa sổ 10/20/50 là kỳ của đài ở giả thuyết 1, ngày hợp lệ ở giả thuyết 2, nên độ dài lịch khác nhau. Điểm hay ra và đang vắng = số kỳ có mặt × min(kỳ vắng,20)/20. Khi bằng điểm, dùng số kỳ có mặt rồi thứ tự số. Không chọn lại trọng số hoặc công thức sau khi xem kết quả.

## 2 số cuối

| Công thức | Theo đài | Theo ngày T2–T6 | Chênh ngày − đài | Khoảng bất định điều chỉnh 12 so sánh |
|---|---:|---:|---:|---|
| Tần suất toàn kỳ | 42.73% | 42.70% | -0.03 điểm % | [-3.74; 3.20] điểm % |
| 10 kỳ gần nhất | 42.19% | 43.37% | +1.18 điểm % | [-2.46; 4.99] điểm % |
| 20 kỳ gần nhất | 43.02% | 41.83% | -1.18 điểm % | [-4.83; 2.23] điểm % |
| 50 kỳ gần nhất | 42.86% | 41.87% | -0.99 điểm % | [-4.70; 2.62] điểm % |
| Hay ra và đang vắng | 41.99% | 43.53% | +1.53 điểm % | [-2.12; 5.05] điểm % |
| Lặp nhiều ở kỳ trước | 42.44% | 43.11% | +0.67 điểm % | [-2.99; 4.38] điểm % |

### Kết quả theo từng năm cuốn chiếu

| Giai đoạn bắt đầu | Công thức | Kỳ so chung | Theo đài | Theo ngày |
|---|---|---:|---:|---:|
| 2022-11-10 (12 tháng) | Tần suất toàn kỳ | 783 | 43.42% | 41.25% |
| 2023-11-10 (12 tháng) | Tần suất toàn kỳ | 783 | 43.68% | 41.51% |
| 2024-11-10 (12 tháng) | Tần suất toàn kỳ | 780 | 42.05% | 44.74% |
| 2025-11-10 (12 tháng) | Tần suất toàn kỳ | 783 | 41.76% | 43.30% |
| 2022-11-10 (12 tháng) | 10 kỳ gần nhất | 783 | 42.15% | 45.08% |
| 2023-11-10 (12 tháng) | 10 kỳ gần nhất | 783 | 42.78% | 43.55% |
| 2024-11-10 (12 tháng) | 10 kỳ gần nhất | 780 | 42.56% | 42.18% |
| 2025-11-10 (12 tháng) | 10 kỳ gần nhất | 783 | 41.25% | 42.66% |
| 2022-11-10 (12 tháng) | 20 kỳ gần nhất | 783 | 40.23% | 40.74% |
| 2023-11-10 (12 tháng) | 20 kỳ gần nhất | 783 | 41.63% | 42.40% |
| 2024-11-10 (12 tháng) | 20 kỳ gần nhất | 780 | 43.72% | 43.97% |
| 2025-11-10 (12 tháng) | 20 kỳ gần nhất | 783 | 46.49% | 40.23% |
| 2022-11-10 (12 tháng) | 50 kỳ gần nhất | 783 | 41.89% | 41.38% |
| 2023-11-10 (12 tháng) | 50 kỳ gần nhất | 783 | 42.15% | 39.85% |
| 2024-11-10 (12 tháng) | 50 kỳ gần nhất | 780 | 43.59% | 42.56% |
| 2025-11-10 (12 tháng) | 50 kỳ gần nhất | 783 | 43.81% | 43.68% |
| 2022-11-10 (12 tháng) | Hay ra và đang vắng | 783 | 42.02% | 44.83% |
| 2023-11-10 (12 tháng) | Hay ra và đang vắng | 783 | 44.06% | 43.42% |
| 2024-11-10 (12 tháng) | Hay ra và đang vắng | 780 | 38.59% | 43.08% |
| 2025-11-10 (12 tháng) | Hay ra và đang vắng | 783 | 43.30% | 42.78% |
| 2022-11-10 (12 tháng) | Lặp nhiều ở kỳ trước | 783 | 41.00% | 41.25% |
| 2023-11-10 (12 tháng) | Lặp nhiều ở kỳ trước | 783 | 42.02% | 42.53% |
| 2024-11-10 (12 tháng) | Lặp nhiều ở kỳ trước | 780 | 42.82% | 46.41% |
| 2025-11-10 (12 tháng) | Lặp nhiều ở kỳ trước | 783 | 43.93% | 42.27% |

### Giả thuyết 1 trên cả tuần

| Công thức | Kỳ được chấm | Kỳ đạt | Tỷ lệ |
|---|---:|---:|---:|
| Tần suất toàn kỳ | 4592 | 1961 | 42.70% |
| 10 kỳ gần nhất | 4592 | 1924 | 41.90% |
| 20 kỳ gần nhất | 4592 | 1974 | 42.99% |
| 50 kỳ gần nhất | 4592 | 1959 | 42.66% |
| Hay ra và đang vắng | 4592 | 1922 | 41.86% |
| Lặp nhiều ở kỳ trước | 4592 | 1919 | 41.79% |
## 3 số cuối

| Công thức | Theo đài | Theo ngày T2–T6 | Chênh ngày − đài | Khoảng bất định điều chỉnh 12 so sánh |
|---|---:|---:|---:|---|
| Tần suất toàn kỳ | 4.99% | 4.86% | -0.13 điểm % | [-1.60; 1.37] điểm % |
| 10 kỳ gần nhất | 4.79% | 5.11% | +0.32 điểm % | [-1.20; 1.89] điểm % |
| 20 kỳ gần nhất | 5.37% | 5.15% | -0.22 điểm % | [-1.79; 1.36] điểm % |
| 50 kỳ gần nhất | 5.02% | 4.99% | -0.03 điểm % | [-1.46; 1.56] điểm % |
| Hay ra và đang vắng | 4.63% | 4.79% | +0.16 điểm % | [-1.46; 1.72] điểm % |
| Lặp nhiều ở kỳ trước | 5.27% | 5.75% | +0.48 điểm % | [-1.11; 2.24] điểm % |

### Kết quả theo từng năm cuốn chiếu

| Giai đoạn bắt đầu | Công thức | Kỳ so chung | Theo đài | Theo ngày |
|---|---|---:|---:|---:|
| 2022-11-10 (12 tháng) | Tần suất toàn kỳ | 783 | 5.62% | 5.62% |
| 2023-11-10 (12 tháng) | Tần suất toàn kỳ | 783 | 4.47% | 5.36% |
| 2024-11-10 (12 tháng) | Tần suất toàn kỳ | 780 | 4.49% | 3.97% |
| 2025-11-10 (12 tháng) | Tần suất toàn kỳ | 783 | 5.36% | 4.47% |
| 2022-11-10 (12 tháng) | 10 kỳ gần nhất | 783 | 6.00% | 5.36% |
| 2023-11-10 (12 tháng) | 10 kỳ gần nhất | 783 | 4.21% | 4.60% |
| 2024-11-10 (12 tháng) | 10 kỳ gần nhất | 780 | 4.36% | 5.77% |
| 2025-11-10 (12 tháng) | 10 kỳ gần nhất | 783 | 4.60% | 4.73% |
| 2022-11-10 (12 tháng) | 20 kỳ gần nhất | 783 | 4.47% | 5.87% |
| 2023-11-10 (12 tháng) | 20 kỳ gần nhất | 783 | 4.09% | 5.11% |
| 2024-11-10 (12 tháng) | 20 kỳ gần nhất | 780 | 5.64% | 5.13% |
| 2025-11-10 (12 tháng) | 20 kỳ gần nhất | 783 | 7.28% | 4.47% |
| 2022-11-10 (12 tháng) | 50 kỳ gần nhất | 783 | 5.62% | 4.85% |
| 2023-11-10 (12 tháng) | 50 kỳ gần nhất | 783 | 4.34% | 4.47% |
| 2024-11-10 (12 tháng) | 50 kỳ gần nhất | 780 | 5.00% | 5.00% |
| 2025-11-10 (12 tháng) | 50 kỳ gần nhất | 783 | 5.11% | 5.62% |
| 2022-11-10 (12 tháng) | Hay ra và đang vắng | 783 | 5.49% | 4.85% |
| 2023-11-10 (12 tháng) | Hay ra và đang vắng | 783 | 4.73% | 6.00% |
| 2024-11-10 (12 tháng) | Hay ra và đang vắng | 780 | 5.38% | 3.59% |
| 2025-11-10 (12 tháng) | Hay ra và đang vắng | 783 | 2.94% | 4.73% |
| 2022-11-10 (12 tháng) | Lặp nhiều ở kỳ trước | 783 | 5.36% | 5.87% |
| 2023-11-10 (12 tháng) | Lặp nhiều ở kỳ trước | 783 | 4.21% | 5.24% |
| 2024-11-10 (12 tháng) | Lặp nhiều ở kỳ trước | 780 | 6.15% | 5.51% |
| 2025-11-10 (12 tháng) | Lặp nhiều ở kỳ trước | 783 | 5.36% | 6.39% |

### Giả thuyết 1 trên cả tuần

| Công thức | Kỳ được chấm | Kỳ đạt | Tỷ lệ |
|---|---:|---:|---:|
| Tần suất toàn kỳ | 4592 | 219 | 4.77% |
| 10 kỳ gần nhất | 4592 | 214 | 4.66% |
| 20 kỳ gần nhất | 4592 | 232 | 5.05% |
| 50 kỳ gần nhất | 4592 | 220 | 4.79% |
| Hay ra và đang vắng | 4592 | 232 | 5.05% |
| Lặp nhiều ở kỳ trước | 4592 | 235 | 5.12% |

## Kết luận và giới hạn

Chưa đủ bằng chứng cho thấy chuỗi ngày thứ Hai–thứ Sáu cải thiện cách theo đài. Cả 12 khoảng chênh lệch sau điều chỉnh đều chứa 0. Một vài tỷ lệ điểm cao hơn chưa đủ để chọn mô hình. Giữ các kết quả này ở nghiên cứu.

Khoảng bất định được ước lượng bằng bootstrap ghép cặp theo ngày, giữ các đài cùng ngày trong một khối, 4.000 lần lấy mẫu lại. Có khoảng 95% danh nghĩa và khoảng dùng mức Bonferroni cho 12 phép so sánh định trước. Đây là xấp xỉ thăm dò; chưa mô hình hóa đầy đủ phụ thuộc giữa các ngày liên tiếp, cũng chưa điều chỉnh cho mọi thử nghiệm trong các phiên nghiên cứu trước. Không dùng bảng từng năm/từng đài để chọn riêng ô có tỷ lệ cao rồi tuyên bố thắng.

Đây là hồi cứu trên dữ liệu đã được xem trong quá trình phát triển. Sau khi chọn một giả thuyết, cần cố định mô hình và theo dõi các kỳ mới. Nghiên cứu này chưa đánh giá dự báo xác suất từng số, chưa tối ưu cửa sổ và không khẳng định có lợi thế so với quá trình quay đồng đều.

Đã đối chiếu Top 3 của 108 trường hợp ở ba ngày thuộc các giai đoạn khác nhau, cả sáu công thức và 2/3 số, với mã JavaScript hiện hành và cùng mã áp dụng trên chuỗi ngày. Cả 216 so sánh đều khớp.

## Tái lập

- `seed.json` chứa bản dữ liệu đầu vào thực tế.
- `compare.py` chạy nghiên cứu, cần Python và NumPy; đây là mã nghiên cứu riêng.
- `du_bao_hoi_cuu.csv` lưu từng dự báo và điểm đối chiếu.
- `ket_qua.json` chứa kết quả cả tuần, trên cùng kỳ so sánh, từng năm và từng đài. Đài chỉ quay cuối tuần có 0 kỳ so chung và vẫn có báo cáo cả tuần ở giả thuyết 1.

SHA-256 dữ liệu: `a2d49d6197fad66fab4dfca06851e7b8f667fc2a65c87030efcfd26c393de1e0`.