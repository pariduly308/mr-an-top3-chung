# Bảng nháp: giả thuyết khác thường — 12/11/2026

Đã chạy 16 tổ hợp mới, không quét mọi quy tắc và không tối ưu lại sau kết quả. Dữ liệu nguồn 10/11/2016–11/11/2026, 14.658 bảng; 5 năm đầu khởi tạo, chấm 10/11/2021–11/11/2026. Các kỳ đã xem là hồi cứu, không phải dự báo tương lai. Không sử dụng kết quả 12/11 trong đợt này.

## Kết quả đầy đủ

Tỷ lệ = Top 3 có ít nhất một số xuất hiện. MN dò hai đài theo lịch, MB dò XSMB; không so trực tiếp tỷ lệ hai miền. App đối chứng giữ repeatMN/frequencyMB,5năm. CI theo khối7ngày là mô tả, chưa hiệu chỉnh chọn lọc nhiều mô hình.

| Miền | Đuôi | Cách thử | Kỳ | Mới | App | Chênh điểm% | CI95% chênh | Phần cuối mới/app |
|---|---:|---|---:|---:|---:|---:|---|---|
| MN | 2 | Chọn ngược công thức chính | 1828 | 67.78% | 67.83% | -0.05 | [-3.06; +3.06] | 63.22%/70.57% |
| MN | 2 | 1 năm nổi hơn 5 năm | 1828 | 67.12% | 67.83% | -0.71 | [-3.56; +2.02] | 70.57%/70.57% |
| MN | 2 | 5 năm nổi hơn 1 năm | 1828 | 67.34% | 67.83% | -0.49 | [-3.67; +2.57] | 70.84%/70.57% |
| MN | 3 | Chọn ngược công thức chính | 1828 | 9.74% | 8.10% | +1.64 | [-0.22; +3.61] | 10.63%/8.99% |
| MN | 3 | 1 năm nổi hơn 5 năm | 1828 | 9.25% | 8.10% | +1.15 | [-0.82; +2.95] | 7.90%/8.99% |
| MN | 3 | 5 năm nổi hơn 1 năm | 1828 | 9.35% | 8.10% | +1.26 | [-0.55; +3.17] | 9.54%/8.99% |
| MB | 2 | Chọn ngược công thức chính | 1808 | 55.03% | 54.37% | +0.66 | [-2.65; +3.76] | 59.50%/54.82% |
| MB | 2 | 1 năm nổi hơn 5 năm | 1808 | 58.02% | 54.37% | +3.65 | [+0.44; +6.97] | 58.95%/54.82% |
| MB | 2 | 5 năm nổi hơn 1 năm | 1808 | 54.65% | 54.37% | +0.28 | [-2.93; +3.65] | 55.37%/54.82% |
| MB | 2 | Đảo số chiều → tối | 1808 | 55.75% | 54.37% | +1.38 | [-1.66; +4.70] | 59.23%/54.82% |
| MB | 2 | Cộng 5 từng chữ số chiều → tối | 1808 | 57.02% | 54.37% | +2.65 | [-0.44; +5.75] | 58.95%/54.82% |
| MB | 3 | Chọn ngược công thức chính | 1808 | 7.63% | 7.85% | -0.22 | [-1.88; +1.49] | 7.71%/8.54% |
| MB | 3 | 1 năm nổi hơn 5 năm | 1808 | 6.75% | 7.85% | -1.11 | [-2.60; +0.39] | 6.06%/8.54% |
| MB | 3 | 5 năm nổi hơn 1 năm | 1808 | 5.92% | 7.85% | -1.94 | [-3.43; -0.39] | 4.96%/8.54% |
| MB | 3 | Đảo số chiều → tối | 1808 | 7.47% | 7.85% | -0.39 | [-2.05; +1.33] | 9.37%/8.54% |
| MB | 3 | Cộng 5 từng chữ số chiều → tối | 1808 | 6.64% | 7.85% | -1.22 | [-2.88; +0.39] | 6.06%/8.54% |

Phần cuối:10/11/2025–11/11/2026, MN367kỳ,MB363kỳ; vẫn đã được xem. Không chọn nó làm kiểm tra mới.

## Điểm đáng chú ý và đối chứng mạnh hơn

XSMB2số short_rise đạt58,02%, hơn app5năm3,65điểm%, nhưng chỉ hơn frequency1năm57,08% khoảng0,94điểm%. Hướng gần–xa50/50 đã thử trước đạt58,74%, nên hướng mới này cũng không vượt mức hồi cứu đó. Không lựa mốc yếu nhất để gọi là cải thiện.

Chọn ngượcMN2số67,78% gần như app67,83%; không có lợi thế. Đảo số chiều55,75%, cộng5chiều57,02% cũng chưa thể kết luận tốt hơn cáchMB1năm57,08%. Chọn ngượcMN3số9,74% gần mốc đồng đều lý tưởng9,71%: thắng app8,10% chưa đủ để thắng chọn ngẫu nhiên.

Không tổ hợp nào đạt toàn bộ điều kiện sàng lọc đã ghi. Không có Brier/hiệu chỉnh vì các cách chỉ sinh thứ hạng, chưa định nghĩa xác suất từng số.

## Sáu đối chứng và ba cửa sổ chính — cùng kỳ

| Miền | Đuôi | Phương pháp | Kỳ | Tỷ lệ |
|---|---:|---|---:|---:|
| MN | 2 | base_frequency | 1828 | 67.67% |
| MN | 2 | base_recent10 | 1828 | 65.37% |
| MN | 2 | base_recent20 | 1828 | 64.00% |
| MN | 2 | base_recent50 | 1828 | 66.30% |
| MN | 2 | base_gap | 1828 | 67.83% |
| MN | 2 | base_repeat | 1828 | 67.83% |
| MN | 2 | primary_1 | 1828 | 66.96% |
| MN | 2 | primary_3 | 1828 | 67.18% |
| MN | 3 | base_frequency | 1828 | 9.63% |
| MN | 3 | base_recent10 | 1828 | 9.74% |
| MN | 3 | base_recent20 | 1828 | 9.68% |
| MN | 3 | base_recent50 | 1828 | 9.19% |
| MN | 3 | base_gap | 1828 | 10.07% |
| MN | 3 | base_repeat | 1828 | 8.10% |
| MN | 3 | primary_1 | 1828 | 10.18% |
| MN | 3 | primary_3 | 1828 | 9.08% |
| MB | 2 | base_frequency | 1808 | 54.37% |
| MB | 2 | base_recent10 | 1808 | 56.08% |
| MB | 2 | base_recent20 | 1808 | 58.46% |
| MB | 2 | base_recent50 | 1808 | 55.86% |
| MB | 2 | base_gap | 1808 | 56.25% |
| MB | 2 | base_repeat | 1808 | 56.19% |
| MB | 2 | primary_1 | 1808 | 57.08% |
| MB | 2 | primary_3 | 1808 | 54.92% |
| MB | 3 | base_frequency | 1808 | 7.85% |
| MB | 3 | base_recent10 | 1808 | 6.47% |
| MB | 3 | base_recent20 | 1808 | 6.69% |
| MB | 3 | base_recent50 | 1808 | 7.02% |
| MB | 3 | base_gap | 1808 | 7.47% |
| MB | 3 | base_repeat | 1808 | 6.58% |
| MB | 3 | primary_1 | 1808 | 7.25% |
| MB | 3 | primary_3 | 1808 | 7.02% |

## Kiểm tra âm tính và giới hạn phát hiện sau chạy

Đã chạy199dịch vòng cho mỗi tổ hợp =3184đối chứng âm tính, giữ nguyên bảng kết quả và nhóm năm/cặpđài. Lưu toàn bộ kết quả cùng p mô tả/Holm16 trong results.json. Không có Holm p<0,05; với199lần, p nhỏ nhất0,005 nên bước đầu Holm16 tối thiểu0,08: thiết kế này không đủ độ phân giải để bất kỳ ứng viên nào vượt ngưỡng0,05. Đây là lỗi độ phân giải của thiết kế sàng lọc, không phải bằng chứng các ứng viên chắc chắn không hiệu quả. Không tăng số lần sau khi nhìn kết quả trong đợt này; lần sau phải đăng ký số lần phù hợp trước. Cùng với giới hạn mô hình thích nghi bên dưới, các p này chỉ lưu chẩn đoán, không dùng suy luận lợi thế.

**Phép dịch này không là kiểm định hợp lệ để xác nhận ưu thế của mô hình thích nghi.** Dự báo ban đầu đã học trên chuỗi thật; ghép với ngày khác có thể đưa các kỳ từng tham gia huấn luyện vào tập đích giả. Vì thế chọn số ít xuất hiện dễ có p trông nhỏ, còn chọn số vừa tăng có thể gặp hiệu ứng ngược. Đây là giới hạn của kiểm tra âm tính, không phải bằng chứng dự báo. Không sửa phép thử sau khi thấy kết quả rồi chỉ báo cái đẹp.

Lượt sau nếu cần kiểm tra âm tính mạnh hơn: đăng ký riêng phép hoán vị toàn chuỗi đầu vào và chạy lại toàn bộ huấn luyện cuốn chiếu trên mỗi chuỗi, thay vì chỉ dịch kết quả; phải kiểm soát xu hướng, nhóm lịch và số giải. Chưa chạy cách này trong đợt hiện tại.

## Kiểm toán và khả năng nối nghiên cứu

Đã kiểm tra 14,658 bảng: không trùngđài/ngày, số lượng/độdài đúng, giữ chuỗi0đầu. Đã đối chiếu 43,632 bộTop3 đối chứng với báo cáo cửa sổ trước: khớp. Kiểm tra lại độc lập đạt/khôngđạt, sốkhớp và mốc chọnngẫu nhiên cho toàn bộ 87,224 dự báo. Các đặc trưng chỉ dùng trướcngàyđích, ngoại trừ nguồnMNchiều dùng cùngngày cho thử nghiệmB; không dùngMBtối để xếp. Lịch sử không có timestamp chứng minh tất cả nguồnMN đã đầyđủ trước18h, vì vậyB chỉ là hồi cứu giả định.

480vị trí lịch sử chưa phân loại đầyđủ còn nguyên; chưa xác minh lại nguồn ngàynghỉ. Mốc đồng đều theo sốđuôi duy nhất thực tế được lưu từngkỳ, cùngTop3. Mốc lý tưởng độc lập:MN2 66,60%,MN3 9,71%,MB2 56,06%,MB3 6,68%.

predictions.json giữ tất cả Top3, sốkhớp, thành viên cặp, sáuđốichứng và cửa sổ chính1/3; results.json giữ từngnăm/từngcặp/phươngpháp. Tổng16tổhợp mới,3184đốichứng âm tính; giữ lịch sử19biếnthểMN+10MN→MB(cả2/3chếđộ),14tổhợp trước và nghiêncứucửasổ; không đặt bộđếm về0.

Không thay app, không sửa bảnkhóa1/3/5năm, không gửi cảnh báo số tối nay. Bước tiếp: ưu tiên hoàn thiện chất lượng và dựbáo tươnglai đãkhóa; nếu khóa ứngviên khác phải địnhtrước phiênbản riêng.

## Dấu vết
- source SHA256: `821038b49415151984dae9dbff1ae894f3a6c63e04873adf9053fedb82c53820`
- protocol SHA256: `d9407c9a4f84e8a22e616deddcb16025c056332600a4a7b96529b78a3d6d3b35`
- Thời điểm hoàn tất kiểm toán: 2026-11-12T12:03:23.664279+00:00