import json,collections,hashlib,datetime,zipfile,math
from pathlib import Path
p=Path(__file__).resolve().parent;r=json.loads((p/'results.json').read_text());pred=json.loads((p/'predictions.json').read_text());src=p.parent/'unusual_inputs/archive';data=json.loads((src/'research_10y_data.json').read_text());by={(x['date'],x['station']):x for x in data}
assert len(by)==len(data)
for x in data:
 expected={2:4,3:3,4:10,5:10}if x['station']=='XSMB'else{2:1,3:1,4:4,5:11,6:1}
 assert dict(collections.Counter(map(len,x['numbers'])))==expected
 assert all(isinstance(s,str)and s.isdigit()for s in x['numbers'])
for a in pred:
 top=a['top3'].split();assert len(top)==len(set(top))==3 and all(len(s)==a['digits']for s in top)
 names=a['target'].split(' + ');actual={s[-a['digits']:]for name in names for s in by[a['date'],name]['numbers']if len(s)>=a['digits']}
 assert a['hit']==int(bool(set(top)&actual));assert a['matches']==len(set(top)&actual)
 # exact random selection baseline via combinations, independent formula check
 N=10**a['digits'];u=len(actual);assert abs(a['uniform']-(1-math.comb(N-u,3)/math.comb(N,3)))<1e-12
labels={'anti':'Chọn ngược công thức chính','short_rise':'1 năm nổi hơn 5 năm','long_rise':'5 năm nổi hơn 1 năm','reverse':'Đảo số chiều → tối','plus5':'Cộng 5 từng chữ số chiều → tối'}
def pct(v):return f'{100*v:.2f}%'
def interval(v):return '['+'; '.join(f'{x*100:+.2f}'for x in v)+']'
lines=['# Bảng nháp: giả thuyết khác thường — 12/11/2026','', 'Đã chạy 16 tổ hợp mới, không quét mọi quy tắc và không tối ưu lại sau kết quả. Dữ liệu nguồn 10/11/2016–11/11/2026, 14.658 bảng; 5 năm đầu khởi tạo, chấm 10/11/2021–11/11/2026. Các kỳ đã xem là hồi cứu, không phải dự báo tương lai. Không sử dụng kết quả 12/11 trong đợt này.','', '## Kết quả đầy đủ','', 'Tỷ lệ = Top 3 có ít nhất một số xuất hiện. MN dò hai đài theo lịch, MB dò XSMB; không so trực tiếp tỷ lệ hai miền. App đối chứng giữ repeatMN/frequencyMB,5năm. CI theo khối7ngày là mô tả, chưa hiệu chỉnh chọn lọc nhiều mô hình.','', '| Miền | Đuôi | Cách thử | Kỳ | Mới | App | Chênh điểm% | CI95% chênh | Phần cuối mới/app |','|---|---:|---|---:|---:|---:|---:|---|---|']
for a in r['summary']:
 late=a['periods']['late'];lines.append(f"| {a['region']} | {a['digits']} | {labels[a['method']]} | {a['n']} | {pct(a['rate'])} | {pct(a['app'])} | {(a['rate']-a['app'])*100:+.2f} | {interval(a['ci95_difference'])} | {pct(late['rate'])}/{pct(late['app'])} |")
lines+=['','Phần cuối:10/11/2025–11/11/2026, MN367kỳ,MB363kỳ; vẫn đã được xem. Không chọn nó làm kiểm tra mới.','', '## Điểm đáng chú ý và đối chứng mạnh hơn','', 'XSMB2số short_rise đạt58,02%, hơn app5năm3,65điểm%, nhưng chỉ hơn frequency1năm57,08% khoảng0,94điểm%. Hướng gần–xa50/50 đã thử trước đạt58,74%, nên hướng mới này cũng không vượt mức hồi cứu đó. Không lựa mốc yếu nhất để gọi là cải thiện.','', 'Chọn ngượcMN2số67,78% gần như app67,83%; không có lợi thế. Đảo số chiều55,75%, cộng5chiều57,02% cũng chưa thể kết luận tốt hơn cáchMB1năm57,08%. Chọn ngượcMN3số9,74% gần mốc đồng đều lý tưởng9,71%: thắng app8,10% chưa đủ để thắng chọn ngẫu nhiên.','', 'Không tổ hợp nào đạt toàn bộ điều kiện sàng lọc đã ghi. Không có Brier/hiệu chỉnh vì các cách chỉ sinh thứ hạng, chưa định nghĩa xác suất từng số.','', '## Sáu đối chứng và ba cửa sổ chính — cùng kỳ','', '| Miền | Đuôi | Phương pháp | Kỳ | Tỷ lệ |','|---|---:|---|---:|---:|']
for region in['MN','MB']:
 for k in[2,3]:
  for method in['base_frequency','base_recent10','base_recent20','base_recent50','base_gap','base_repeat','primary_1','primary_3']:
   a=[x for x in pred if x['region']==region and x['digits']==k and x['method']==method];lines.append(f"| {region} | {k} | {method} | {len(a)} | {pct(sum(x['hit']for x in a)/len(a))} |")
lines+=['','## Kiểm tra âm tính và giới hạn phát hiện sau chạy','', 'Đã chạy199dịch vòng cho mỗi tổ hợp =3184đối chứng âm tính, giữ nguyên bảng kết quả và nhóm năm/cặpđài. Lưu toàn bộ kết quả cùng p mô tả/Holm16 trong results.json. Không có Holm p<0,05; với199lần, p nhỏ nhất0,005 và Holm cho16so sánh có độ phân giải hạn chế.','', '**Phép dịch này không là kiểm định hợp lệ để xác nhận ưu thế của mô hình thích nghi.** Dự báo ban đầu đã học trên chuỗi thật; ghép với ngày khác có thể đưa các kỳ từng tham gia huấn luyện vào tập đích giả. Vì thế chọn số ít xuất hiện dễ có p trông nhỏ, còn chọn số vừa tăng có thể gặp hiệu ứng ngược. Đây là giới hạn của kiểm tra âm tính, không phải bằng chứng dự báo. Không sửa phép thử sau khi thấy kết quả rồi chỉ báo cái đẹp.','', 'Lượt sau nếu cần kiểm tra âm tính mạnh hơn: đăng ký riêng phép hoán vị toàn chuỗi đầu vào và chạy lại toàn bộ huấn luyện cuốn chiếu trên mỗi chuỗi, thay vì chỉ dịch kết quả; phải kiểm soát xu hướng, nhóm lịch và số giải. Chưa chạy cách này trong đợt hiện tại.','', '## Kiểm toán và khả năng nối nghiên cứu','', f"Đã kiểm tra {len(data):,} bảng: không trùngđài/ngày, số lượng/độdài đúng, giữ chuỗi0đầu. Đã đối chiếu {r['baseline_checks']:,} bộTop3 đối chứng với báo cáo cửa sổ trước: khớp. Kiểm tra lại độc lập đạt/khôngđạt, sốkhớp và mốc chọnngẫu nhiên cho toàn bộ {len(pred):,} dự báo. Các đặc trưng chỉ dùng trướcngàyđích, ngoại trừ nguồnMNchiều dùng cùngngày cho thử nghiệmB; không dùngMBtối để xếp. Lịch sử không có timestamp chứng minh tất cả nguồnMN đã đầyđủ trước18h, vì vậyB chỉ là hồi cứu giả định.", '', '480vị trí lịch sử chưa phân loại đầyđủ còn nguyên; chưa xác minh lại nguồn ngàynghỉ. Mốc đồng đều theo sốđuôi duy nhất thực tế được lưu từngkỳ, cùngTop3. Mốc lý tưởng độc lập:MN2 66,60%,MN3 9,71%,MB2 56,06%,MB3 6,68%.','', 'predictions.json giữ tất cả Top3, sốkhớp, thành viên cặp, sáuđốichứng và cửa sổ chính1/3; results.json giữ từngnăm/từngcặp/phươngpháp. Tổng16tổhợp mới,3184đốichứng âm tính; giữ lịch sử19biếnthểMN+10MN→MB(cả2/3chếđộ),14tổhợp trước và nghiêncứucửasổ; không đặt bộđếm về0.','', 'Không thay app, không sửa bảnkhóa1/3/5năm, không gửi cảnh báo số tối nay. Bước tiếp: ưu tiên hoàn thiện chất lượng và dựbáo tươnglai đãkhóa; nếu khóa ứngviên khác phải địnhtrước phiênbản riêng.','', '## Dấu vết',f"- source SHA256: `{r['source_sha256']}`",f"- protocol SHA256: `{r['protocol_sha256']}`",f"- Thời điểm hoàn tất kiểm toán: {datetime.datetime.now(datetime.timezone.utc).isoformat()}"]
(p/'BAO_CAO_NHAP.md').write_text('\n'.join(lines))
# Per member summaries, not independent samples of pair outcome.
mem=collections.defaultdict(lambda:[0,0])
for a in pred:
 for name,hit in a.get('member_hits',{}).items():
  key=(name,a['date'][:4],a['digits'],a['method']);mem[key][0]+=hit;mem[key][1]+=1
(p/'member_summaries.json').write_text(json.dumps([dict(station=s,year=y,digits=k,method=m,hits=v[0],n=v[1])for(s,y,k,m),v in mem.items()],ensure_ascii=False))
(p/'validation.json').write_text(json.dumps(dict(rows=len(data),predictions=len(pred),baseline_matched=r['baseline_checks'],all_assertions_passed=True)))
j=p.parent/'unusual_inputs/MR_AN_TOP3_CHUNG_NHAT_KY_NGHIEN_CUU.md';j.write_text(j.read_text()+'\n\n## Lô giả thuyết khác thường v1 — 12/11/2026\n'+(p/'BAO_CAO_NHAP.md').read_text()+'\nGói nối tiếp: MR_AN_GIA_THUYET_KHAC_THUONG_2026_11_12.zip.\n')
with zipfile.ZipFile(p/'MR_AN_GIA_THUYET_KHAC_THUONG_2026_11_12.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in p.iterdir():
  if f.suffix in['.py','.md','.json']:z.write(f,f.name)
print('validated and packaged',len(pred))
