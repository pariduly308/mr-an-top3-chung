import json,datetime,collections,hashlib,csv,math
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent; src=p.parent/'unusual_inputs/archive'; rows=json.loads((src/'research_10y_data.json').read_text()); rng=np.random.default_rng(12112026)
pairs=[['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An'],['Tiền Giang','Kiên Giang']]
by={(r['date'],r['station']):r for r in rows}; groups=collections.defaultdict(list); pairday={}
for r in rows:
 if r['station']=='XSMB':groups['XSMB'].append(r)
for d in sorted({r['date'] for r in rows}):
 pair=pairs[datetime.date.fromisoformat(d).weekday()]
 if all((d,s)in by for s in pair):
  r={'date':d,'station':' + '.join(pair),'numbers':sum([by[d,s]['numbers'] for s in pair],[]),'members':pair};groups[r['station']].append(r);pairday[d]=r
methods=['frequency','recent10','recent20','recent50','gap','repeat'];records=[];actuals={};baseline_ref={}
with (src/'retrospective_predictions.csv').open() as f:
 for r in csv.DictReader(f):
  if r['target'] in groups:baseline_ref[r['date'],r['target'],int(r['digits']),r['method'],int(r['years'])]=r
checks=0
def lower(d,y):
 t=datetime.date.fromisoformat(d)
 try:return t.replace(year=t.year-y).isoformat()
 except ValueError:return t.replace(year=t.year-y,month=3,day=1).isoformat()
def vec(numbers,k):
 a=np.zeros(10**k,dtype=int)
 for x in numbers:
  if len(x)>=k:a[int(x[-k:])]+=1
 return a
for name,ds in groups.items():
 ds.sort(key=lambda r:r['date']);dates=np.array([r['date'] for r in ds]);region='MB' if name=='XSMB'else'MN';main='frequency'if region=='MB'else'repeat'
 for k in [2,3]:
  size=10**k; nums=np.arange(size);counts=np.array([vec(r['numbers'],k)for r in ds]);hits=counts>0;pre=np.vstack([np.zeros(size,dtype=int),hits.cumsum(axis=0)]);last=np.full(size,-1)
  for i,d in enumerate(dates):
   if d>='2021-11-10':
    lo=np.searchsorted(dates,lower(str(d),5));h=pre[i]-pre[lo];n=i-lo;gap=np.where(last>=lo,i-last-1,n);scores=[h,*[pre[i]-pre[max(lo,i-z)]for z in[10,20,50]],h*np.minimum(gap,20)/20,counts[i-1]];tops={}
    for m,sc in zip(methods,scores):
     order=np.lexsort((nums,-h,-sc));tops['base_'+m]=order[:3]
     ref=baseline_ref[str(d),name,k,m,5];assert list(map(int,ref['top3'].split()))==list(order[:3]);checks+=1
     if m==main:tops['anti']=order[-3:][::-1]
    for y in[1,3]:
     l=np.searchsorted(dates,lower(str(d),y));hy=pre[i]-pre[l];sc=hy if main=='frequency'else counts[i-1];tops['primary_'+str(y)]=np.lexsort((nums,-hy,-sc))[:3]
    l=np.searchsorted(dates,lower(str(d),1));diff=(pre[i]-pre[l])/(i-l)-h/n
    tops['short_rise']=np.lexsort((nums,-h,-diff))[:3];tops['long_rise']=np.lexsort((nums,-h,diff))[:3]
    if region=='MB'and d in pairday:
     for transform in['reverse','plus5']:
      v=np.zeros(size,dtype=int)
      for x in pairday[d]['numbers']:
       if len(x)<k:continue
       s=x[-k:];s=s[::-1]if transform=='reverse'else ''.join(str((int(c)+5)%10)for c in s);v[int(s)]+=1
      tops[transform]=np.lexsort((nums,-h,-v))[:3];assert (v[tops[transform]]>0).all()
    u=int(hits[i].sum());uniform=1-((size-u)*(size-u-1)*(size-u-2))/(size*(size-1)*(size-2));actuals[str(d),name,k]=hits[i]
    for m,top in tops.items():
     rec=dict(date=str(d),target=name,region=region,digits=k,method=m,top3=' '.join(str(x).zfill(k)for x in top),hit=int(hits[i,top].any()),matches=int(hits[i,top].sum()),uniform=uniform,app=int(hits[i,tops['base_'+main]].any()))
     if region=='MN':rec['member_hits']={s:int((vec(by[str(d),s]['numbers'],k)[top]>0).any())for s in ds[i]['members']}
     records.append(rec)
   last[hits[i]]=i
print('baseline verified',checks,flush=True)
def ci(delta):
 a=np.array(delta);n=len(a);out=[]
 for _ in range(2000):
  starts=rng.integers(0,n,size=math.ceil(n/7));ix=((starts[:,None]+np.arange(7))%n).ravel()[:n];out.append(a[ix].mean())
 return np.quantile(out,[.025,.975]).tolist()
def period(d):return 'development'if d<'2024-11-10'else 'validation'if d<'2025-11-10'else 'late'
def stats(a):return dict(n=len(a),rate=float(np.mean([r['hit']for r in a])),app=float(np.mean([r['app']for r in a])),uniform=float(np.mean([r['uniform']for r in a])))
summ=[];detail=[]
for region in['MN','MB']:
 for k in[2,3]:
  names=['anti','short_rise','long_rise']+(['reverse','plus5']if region=='MB'else[])
  for m in names:
   a=sorted([r for r in records if r['region']==region and r['digits']==k and r['method']==m],key=lambda r:r['date']);res=dict(region=region,digits=k,method=m,**stats(a));res['ci95_difference']=ci([r['hit']-r['app']for r in a]);res['periods']={z:stats([r for r in a if period(r['date'])==z])for z in['development','validation','late']};late=[r for r in a if period(r['date'])=='late'];res['late_ci95_difference']=ci([r['hit']-r['app']for r in late]);null=[];parts=collections.defaultdict(list)
   for r in a:parts[r['date'][:4],r['target']].append(r)
   for _ in range(199):
    total=0
    for group in parts.values():
     shift=int(rng.integers(1,len(group)))if len(group)>1 else 0
     for j,r in enumerate(group):
      target=group[(j+shift)%len(group)];total+=int(actuals[target['date'],target['target'],k][list(map(int,r['top3'].split()))].any())
    null.append(total/len(a))
   res['shift_null95']=np.quantile(null,[.025,.975]).tolist();res['shift_p']=(1+sum(x>=res['rate']for x in null))/200;res['null_rates']=null;summ.append(res)
for i,r in enumerate(sorted(summ,key=lambda r:r['shift_p'])):r['holm_p']=min(1,max((16-j)*x['shift_p']for j,x in enumerate(sorted(summ,key=lambda r:r['shift_p'])[:i+1])))
for r in summ:
 r['screen_pass']=bool(r['rate']-r['app']>=.03 and r['periods']['late']['rate']-r['periods']['late']['app']>=.03 and r['late_ci95_difference'][0]>0 and sum(v['rate']>v['app']for v in r['periods'].values())>=2 and r['rate']>r['uniform']and r['holm_p']<.05)
for (region,k,m,target,year),a in __import__('itertools').groupby(sorted(records,key=lambda r:(r['region'],r['digits'],r['method'],r['target'],r['date'][:4])),key=lambda r:(r['region'],r['digits'],r['method'],r['target'],r['date'][:4])):
 a=list(a);detail.append(dict(region=region,digits=k,method=m,target=target,year=year,**stats(a)))
(p/'predictions.json').write_text(json.dumps(records,ensure_ascii=False));(p/'results.json').write_text(json.dumps(dict(summary=summ,by_year_target=detail,baseline_checks=checks,new_combinations=16,negative_controls=3184,source_sha256=hashlib.sha256((src/'research_10y_data.json').read_bytes()).hexdigest(),protocol_sha256=hashlib.sha256((p/'PROTOCOL.md').read_bytes()).hexdigest()),ensure_ascii=False,indent=2))
print(json.dumps([{k:v for k,v in r.items()if k not in['null_rates','periods']}for r in summ],ensure_ascii=False,indent=2))
