# Bổ sung thử nghiệm XSMB — không áp dụng vào app

Giữ nguyên XSMB trên app. Đây là thử nghiệm thêm theo yêu cầu: nhóm ứng viên là các số ra ở bất kỳ đài nào trong cặp miền Nam buổi chiều, chọn đúng 3 số dò XSMB tối cùng ngày. Không bắt buộc số xuất hiện cả hai đài. Không dùng kết quả XSMB tối nay để chọn số cho chính tối nay.

Dùng cùng dữ liệu 5 năm, năm đầu khởi tạo, ba năm tiếp chọn công thức, năm cuối chấm. Năm cuối có 361 bảng XSMB; 4 ngày không có dữ liệu XSMB không được điền giả. Dữ liệu lịch sử đã được nghiên cứu trước, kết quả vẫn mang tính khám phá.

Sáu cách cũ lấy đúng hàm xếp hạng theo lịch sử XSMB. Mười hướng mới gồm sáu cách xếp hạng XSMB giới hạn trong nhóm số chiều; ưu tiên số lần ra chiều; ưu tiên xuất hiện cả hai đài nhưng vẫn lấy đủ ba từ nhóm hợp; kết hợp thứ hạng chiều với tần suất XSMB; kết hợp với 20 kỳ XSMB. Hằng số kết hợp cố định trước khi chạy, không tìm mức cho kết quả đẹp. Các mã phương pháp và công thức nằm trong north_experiment.py.

Công thức cũ và mới đều chọn bằng tỷ lệ đạt ba năm phát triển, không chọn công thức cao nhất năm cuối. App có nhiều cách cho người dùng chọn; công thức cũ được chọn ở đây là chuẩn so sánh nghiên cứu, không khẳng định là lựa chọn đang mở trên máy anh.

## Đuôi 2 số

Cách cũ chọn trước: old_gap. Cách mới chọn trước: south_recent10.

Cũ: 203/361 = 56.23%. Mới: 191/361 = 52.91%. Đối chứng chọn ngẫu nhiên ba số trong nhóm chiều: 55.78%.

| Phương pháp | Ba năm phát triển | Năm sau | Cả bốn năm chấm |

|---|---:|---:|---:|

| old_frequency | 55.35% | 57.06% | 55.78% |

| south_frequency | 56.18% | 58.45% | 56.75% |

| old_recent10 | 55.07% | 54.57% | 54.95% |

| south_recent10 | 58.21% | 52.91% | 56.89% |

| old_recent20 | 56.27% | 58.45% | 56.82% |

| south_recent20 | 57.47% | 52.35% | 56.19% |

| old_recent50 | 54.52% | 57.62% | 55.29% |

| south_recent50 | 56.09% | 52.35% | 55.16% |

| old_gap | 56.73% | 56.23% | 56.61% |

| south_gap | 57.66% | 51.80% | 56.19% |

| old_repeat | 56.46% | 54.85% | 56.06% |

| south_repeat | 55.17% | 54.29% | 54.95% |

| afternoon_count | 56.73% | 56.79% | 56.75% |

| joint_first | 54.70% | 56.79% | 55.22% |

| blend_frequency | 55.90% | 56.79% | 56.12% |

| blend_recent20 | 57.29% | 53.19% | 56.26% |

## Đuôi 3 số

Cách cũ chọn trước: old_frequency. Cách mới chọn trước: south_recent10.

Cũ: 32/361 = 8.86%. Mới: 29/361 = 8.03%. Đối chứng chọn ngẫu nhiên ba số trong nhóm chiều: 7.08%.

| Phương pháp | Ba năm phát triển | Năm sau | Cả bốn năm chấm |

|---|---:|---:|---:|

| old_frequency | 8.03% | 8.86% | 8.24% |

| south_frequency | 6.73% | 6.93% | 6.78% |

| old_recent10 | 6.00% | 4.16% | 5.54% |

| south_recent10 | 7.38% | 8.03% | 7.54% |

| old_recent20 | 5.63% | 7.20% | 6.02% |

| south_recent20 | 6.46% | 5.26% | 6.16% |

| old_recent50 | 6.27% | 8.59% | 6.85% |

| south_recent50 | 6.73% | 5.54% | 6.44% |

| old_gap | 6.37% | 8.03% | 6.78% |

| south_gap | 6.46% | 8.86% | 7.06% |

| old_repeat | 6.73% | 9.14% | 7.34% |

| south_repeat | 7.10% | 7.20% | 7.13% |

| afternoon_count | 6.92% | 5.54% | 6.57% |

| joint_first | 7.20% | 5.82% | 6.85% |

| blend_frequency | 6.55% | 7.76% | 6.85% |

| blend_recent20 | 6.00% | 6.65% | 6.16% |

## Kết luận

Cả hai loại đuôi, hướng mới được chọn từ giai đoạn trước đều thấp hơn cách cũ trong năm sau. Chưa đủ bằng chứng để thay XSMB. Không suy ra xác suất riêng từng số từ tỷ lệ trúng của cả bộ ba. Đối chiếu 36 dự báo cũ với hàm JavaScript app khớp; kiểm tra 46.240 bản ghi điều kiện nhóm ứng viên, đủ ba số và kết quả: khớp.

Chạy north_experiment.py sau compare.py; có NumPy. north_results.json chứa các khoảng chênh lệch và hiệu chỉnh 20 phép so sánh chính trong nhánh Bắc. Khi xét cả nhánh Nam và Bắc là một nghiên cứu lớn, số thử tăng thêm; không được coi ngưỡng từng nhánh là hiệu chỉnh toàn bộ lịch sử nghiên cứu.