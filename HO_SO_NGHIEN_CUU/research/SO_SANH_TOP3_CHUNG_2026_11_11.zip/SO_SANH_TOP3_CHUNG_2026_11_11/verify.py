import json,csv
from pathlib import Path
R=Path(__file__).resolve().parent
pred=list(csv.DictReader((R/'predictions.csv').open(encoding='utf-8-sig')))
idx={(r['date'],int(r['digits']),r['method']):r for r in pred}
refs=json.loads((R/'js_reference.json').read_text())
for r in refs:
 p=idx[(r['date'],r['digits'],r['method'])]
 assert p['top_a']==r['top_a'] and p['top_b']==r['top_b'],r
rows=json.loads((R/'seed.json').read_text());data={(r['date'],r['station']):r['numbers'] for r in rows};res=json.loads((R/'results.json').read_text())
for p in pred:
 d=int(p['digits']);a,b=res['pairs'][int(p['weekday'])];day=p['date']
 ta,tb=set(p['top_a'].split(',')),set(p['top_b'].split(','));assert len(ta)==len(tb)==3
 if not p['method'].startswith('old_'):assert ta==tb
 va=[n[-d:] for n in data[(day,a)] if len(n)>=d];vb=[n[-d:] for n in data[(day,b)] if len(n)>=d]
 ha,hb=bool(ta&set(va)),bool(tb&set(vb))
 assert int(ha or hb)==int(p['hit'])
 assert int(ha)+int(hb)==int(p['hit_stations'])
 assert len(ta&set(va))+len(tb&set(vb))==int(p['matching_slots'])
 assert sum(n in ta for n in va)+sum(n in tb for n in vb)==int(p['occurrences'])
out={'app_reference_forecasts':len(refs),'outcomes_checked':len(pred),'passed':True}
(R/'verification.json').write_text(json.dumps(out,indent=2));print(out)
