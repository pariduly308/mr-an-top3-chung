"""Supplemental South-afternoon to North-evening research. Production unchanged."""
import ast,json,csv,math
from pathlib import Path
from collections import defaultdict,deque
from datetime import date
import numpy as np
R=Path(__file__).resolve().parent
tree=ast.parse((R/'compare.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='State'] ,type_ignores=[]),'state','exec'))
base_results=json.loads((R/'results.json').read_text());pairs=base_results['pairs']
methods=['frequency','recent10','recent20','recent50','gap','repeat']
rows=json.loads((R/'seed.json').read_text());byday=defaultdict(dict)
for r in rows:byday[r['date']][r['station']]=r['numbers']
def counts(nums,d):
 c=np.zeros(10**d,int)
 for n in nums:
  if len(n)>=d:c[int(n[-d:])]+=1
 return c
def chance(m,u):return 1-math.comb(m-u,3)/math.comb(m,3)
recs=[]
for d in (2,3):
 m=10**d;s=State(m)
 for day,draws in sorted(byday.items()):
  if 'XSMB' not in draws:continue
  w=date.fromisoformat(day).weekday();a,b=pairs[w];ca,cb=counts(draws[a],d),counts(draws[b],d)
  union=(ca+cb)>0;joint=(ca>0)&(cb>0);actual=counts(draws['XSMB'],d)>0;ranks=s.rank()
  if day>='2022-11-10':
   options={}
   for method,rank in zip(methods,ranks):
    options['old_'+method]=rank[:3]
    options['south_'+method]=rank[union[rank]][:3]
   scorelist={'afternoon_count':ca+cb,'joint_first':joint.astype(int)}
   # Rank aggregation uses fixed offsets/weights, not tuned on outcomes.
   arank=np.lexsort((np.arange(m),-(ca+cb)));inv_a=np.empty(m,int);inv_a[arank]=np.arange(m)
   for j,label in [(0,'blend_frequency'),(2,'blend_recent20')]:
    inv=np.empty(m,int);inv[ranks[j]]=np.arange(m)
    scorelist[label]=1/(10+inv_a)+1/(10+inv)
   for method,score in scorelist.items():
    rank=np.lexsort((np.arange(m),-s.hits,-score));options[method]=rank[union[rank]][:3]
   for method,top in options.items():
    assert len(top)==3
    recs.append(dict(date=day,weekday=w,digits=d,method=method,period='later' if day>='2025-11-10' else 'development',top=','.join(str(int(n)).zfill(d) for n in top),hit=int(actual[top].any()),random=chance(m,int(actual.sum())),random_union=chance(int(union.sum()),int((union&actual).sum()))))
  s.add(counts(draws['XSMB'],d))
with (R/'north_predictions.csv').open('w',encoding='utf-8-sig',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(recs[0]));wr.writeheader();wr.writerows(recs)
idx={(r['digits'],r['method'],r['date']):r for r in recs};rng=np.random.default_rng(20261113)
def summarize(part):return {'n':len(part),'hits':sum(r['hit'] for r in part),'rate':float(np.mean([r['hit'] for r in part])),'random':float(np.mean([r['random'] for r in part])),'random_union':float(np.mean([r['random_union'] for r in part]))}
out={}
for d in (2,3):
 names=list(dict.fromkeys(r['method'] for r in recs if r['digits']==d));items={}
 for method in names:
  part=[r for r in recs if r['digits']==d and r['method']==method]
  items[method]={p:summarize([r for r in part if p=='all' or r['period']==p]) for p in ('all','development','later')}
  items[method]['years']={str(y):summarize([r for r in part if f'{y}-11-10'<=r['date']<f'{y+1}-11-10']) for y in range(2022,2026)}
 old=max([m for m in names if m.startswith('old_')],key=lambda m:items[m]['development']['rate'])
 new=max([m for m in names if not m.startswith('old_')],key=lambda m:items[m]['development']['rate'])
 for method in names:
  if method.startswith('old_'):continue
  part=[r for r in recs if r['digits']==d and r['method']==method and r['period']=='later'];groups=defaultdict(list);diff=[]
  for r in part:
   delta=r['hit']-idx[(d,old,r['date'])]['hit'];diff.append(delta);groups[(date.fromisoformat(r['date'])-date(2021,11,8)).days//7].append(delta)
  v=np.array([[sum(v),len(v)] for v in groups.values()]);a=v[rng.integers(len(v),size=(20000,len(v)))].sum(axis=1);deltas=a[:,0]/a[:,1]
  items[method]['comparison']={'baseline':old,'delta':float(np.mean(diff)),'ci95':np.quantile(deltas,[.025,.975]).tolist(),'ci_adjusted20':np.quantile(deltas,[.05/40,1-.05/40]).tolist()}
 out[str(d)]={'old_selected':old,'new_selected':new,'methods':items}
# Independently check every stored candidate membership and hit using string sets.
for r in recs:
 d=r['digits'];draws=byday[r['date']];a,b=pairs[r['weekday']];top=set(r['top'].split(','));assert len(top)==3
 if not r['method'].startswith('old_'):assert top <= {n[-d:] for n in draws[a]+draws[b] if len(n)>=d}
 assert r['hit']==int(bool(top & {n[-d:] for n in draws['XSMB'] if len(n)>=d}))
(R/'north_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
(R/'north_verification.json').write_text(json.dumps({'outcomes_checked':len(recs),'passed':True}))
for d,x in out.items():
 print(d,'old',x['old_selected'],x['methods'][x['old_selected']]['later'],'new',x['new_selected'],x['methods'][x['new_selected']]['later'],x['methods'][x['new_selected']]['comparison'])
