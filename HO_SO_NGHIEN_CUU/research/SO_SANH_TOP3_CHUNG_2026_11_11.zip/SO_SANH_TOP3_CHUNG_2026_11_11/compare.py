"""Research only. No XSMB modeling or production writes. Python + numpy."""
import json,csv,math,hashlib
from pathlib import Path
from collections import defaultdict,deque
from datetime import date
import numpy as np
R=Path(__file__).resolve().parent
PAIRS=[['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An'],['Tiền Giang','Kiên Giang']]
METHODS=['frequency','recent10','recent20','recent50','gap','repeat']
class State:
 def __init__(self,m):
  self.n=0;self.hits=np.zeros(m,int);self.last=np.full(m,-1,int);self.repeat=np.zeros(m,int);self.hist=deque(maxlen=50);self.recent={w:np.zeros(m,int) for w in (10,20,50)}
 def rank(self):
  scores=[self.hits,self.recent[10],self.recent[20],self.recent[50],self.hits*np.minimum(self.n-self.last-1,20)/20,self.repeat]
  return [np.lexsort((np.arange(len(self.hits)),-self.hits,-s)) for s in scores]
 def add(self,c):
  p=(c>0).astype(int)
  for w in self.recent:
   if len(self.hist)>=w:self.recent[w]-=self.hist[-w]
   self.recent[w]+=p
  self.hist.append(p);self.hits+=p;self.last[p>0]=self.n;self.repeat=c;self.n+=1
 def prob(self,w,base):
  n=self.n if w==0 else min(self.n,w);h=self.hits if w==0 else self.recent[w]
  return (h+20*base)/(n+20)
def counts(nums,d):
 c=np.zeros(10**d,int)
 for n in nums:
  if len(n)>=d:c[int(n[-d:])]+=1
 return c
def chance(m,u,k=3):return 1-math.comb(m-u,k)/math.comb(m,k)
def texttop(t,d):return ','.join(str(int(x)).zfill(d) for x in t)
raw=(R/'seed.json').read_bytes();rows=json.loads(raw);byday=defaultdict(dict)
for r in rows:
 assert r['station'] not in byday[r['date']]
 byday[r['date']][r['station']]=r['numbers']
records=[]
for d in (2,3):
 m=10**d;base=1-(1-1/m)**(18 if d==2 else 17)
 stations=defaultdict(lambda:State(m));pair_states=[State(m) for _ in PAIRS]
 for day,draws in sorted(byday.items()):
  w=date.fromisoformat(day).weekday();a,b=PAIRS[w];assert a in draws and b in draws
  sa,sb=stations[a],stations[b];ra,rb=sa.rank(),sb.rank();rp=pair_states[w].rank()
  ca,cb=counts(draws[a],d),counts(draws[b],d);ha,hb=ca>0,cb>0
  if day>='2022-11-10':
   predictions={}
   for j,method in enumerate(METHODS):
    predictions['old_'+method]=(ra[j][:3],rb[j][:3])
    predictions['pair_'+method]=(rp[j][:3],rp[j][:3])
   # Four windows: smoothed per-station hit rates, combine probability at either.
   # Independence is a ranking hypothesis only; not a calibrated forecast %.
   for win in (0,10,20,50):
    pa,pb=sa.prob(win,base),sb.prob(win,base)
    for name,score in [('either',1-(1-pa)*(1-pb)),('best_station',np.maximum(pa,pb)),('balanced',np.minimum(pa,pb))]:
     top=np.lexsort((np.arange(m),-(sa.hits/max(sa.n,1)+sb.hits/max(sb.n,1)),-score))[:3]
     predictions[f'{name}_{win}']=(top,top)
   # Equal rank aggregation of the two stations across stable frequency/recent windows.
   score=np.zeros(m)
   for rank in [ra[j] for j in (0,2,3)]+[rb[j] for j in (0,2,3)]:score[rank]+=1/(10+np.arange(m))
   top=np.lexsort((np.arange(m),-score))[:3];predictions['rank_consensus']=(top,top)
   for name,(ta,tb) in predictions.items():
    hit_a=int(ha[ta].any());hit_b=int(hb[tb].any());old=name.startswith('old_')
    random=1-(1-chance(m,int(ha.sum())))*(1-chance(m,int(hb.sum()))) if old else chance(m,int((ha|hb).sum()))
    records.append(dict(date=day,digits=d,weekday=w,method=name,period='later' if day>='2025-11-10' else 'development',top_a=texttop(ta,d),top_b=texttop(tb,d),hit=int(hit_a or hit_b),hit_a=hit_a,hit_b=hit_b,hit_stations=hit_a+hit_b,matching_slots=int(ha[ta].sum()+hb[tb].sum()),occurrences=int(ca[ta].sum()+cb[tb].sum()),random=random))
  # Admit all South draws, including the other weekly HCM draw, after predictions.
  for station,nums in draws.items():
   if station!='XSMB':stations[station].add(counts(nums,d))
  pair_states[w].add(ca+cb)
with (R/'predictions.csv').open('w',encoding='utf-8-sig',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(records[0]));wr.writeheader();wr.writerows(records)
index={(r['digits'],r['method'],r['date']):r for r in records}
def summarize(part):
 return dict(n=len(part),hits=sum(r['hit'] for r in part),rate=float(np.mean([r['hit'] for r in part])),random=float(np.mean([r['random'] for r in part])),stations=float(np.mean([r['hit_stations'] for r in part])),slots=float(np.mean([r['matching_slots'] for r in part])))
rng=np.random.default_rng(20261112)
def compare(part,baseline):
 dif=np.array([r['hit']-index[(r['digits'],baseline,r['date'])]['hit'] for r in part]);groups=defaultdict(list)
 for r,x in zip(part,dif):groups[(date.fromisoformat(r['date'])-date(2021,11,8)).days//7].append(int(x))
 vals=np.array([[sum(x),len(x)] for x in groups.values()]);sample=rng.integers(len(vals),size=(20000,len(vals)));s=vals[sample].sum(axis=1);delta=s[:,0]/s[:,1]
 return dict(baseline=baseline,delta=float(dif.mean()),new_only=int(sum(dif==1)),old_only=int(sum(dif==-1)),ci95=np.quantile(delta,[.025,.975]).tolist(),ci_adjusted38=np.quantile(delta,[.05/76,1-.05/76]).tolist())
out={'source_sha256':hashlib.sha256(raw).hexdigest(),'start':min(byday),'end':max(byday),'source_rows':len(rows),'pairs':PAIRS,'digits':{}}
for d in (2,3):
 methods=list(dict.fromkeys(r['method'] for r in records if r['digits']==d));items={}
 for method in methods:
  part=[r for r in records if r['digits']==d and r['method']==method]
  items[method]={p:summarize([r for r in part if p=='all' or r['period']==p]) for p in ('all','development','later')}
  items[method]['years']={str(y):summarize([r for r in part if f'{y}-11-10'<=r['date']<f'{y+1}-11-10']) for y in range(2022,2026)}
  items[method]['weekday_later']={str(w):summarize([r for r in part if r['weekday']==w and r['period']=='later']) for w in range(7)}
 old=max([m for m in methods if m.startswith('old_')],key=lambda m:items[m]['development']['rate'])
 new=max([m for m in methods if not m.startswith('old_')],key=lambda m:items[m]['development']['rate'])
 for method in methods:
  if method.startswith('old_'):continue
  part=[r for r in records if r['digits']==d and r['method']==method and r['period']=='later']
  items[method]['comparison']=compare(part,old)
  if method.startswith('pair_'):items[method]['same_formula_comparison']=compare(part,method.replace('pair_','old_'))
 out['digits'][str(d)]={'old_selected':old,'new_selected':new,'methods':items}
(R/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
for d,x in out['digits'].items():
 print('DIGITS',d,'OLD',x['old_selected'],x['methods'][x['old_selected']]['later'])
 print('NEW',x['new_selected'],x['methods'][x['new_selected']]['later'],x['methods'][x['new_selected']]['comparison'])
 for name,item in x['methods'].items():print(name,round(100*item['all']['rate'],2),round(100*item['later']['rate'],2))
