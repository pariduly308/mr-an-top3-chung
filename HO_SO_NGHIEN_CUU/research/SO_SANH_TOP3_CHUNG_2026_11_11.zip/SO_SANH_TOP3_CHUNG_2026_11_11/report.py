import json
from pathlib import Path
R=Path(__file__).resolve().parent
res=json.loads((R/'results.json').read_text());ver=json.loads((R/'verification.json').read_text())
fmt=lambda v:f'{100*v:.2f}%'
names={'frequency':'Tần suất','recent10':'10 kỳ gần','recent20':'20 kỳ gần','recent50':'50 kỳ gần','gap':'Tần suất × độ vắng','repeat':'Lặp ở kỳ trước'}
def label(m):
 if m=='rank_consensus':return 'Đồng thuận thứ hạng hai đài'
 prefix,last=m.rsplit('_',1)
 if prefix in ('old','pair'):return ('Riêng từng đài: ' if prefix=='old' else 'Gộp lịch sử cặp: ')+names[last]
 return {'either':'Kết hợp cơ hội ở ít nhất một đài','best_station':'Ưu tiên đài mạnh hơn','balanced':'Cân bằng hai đài'}[prefix]+' — '+('toàn kỳ' if last=='0' else last+' kỳ')
ls=['# So sánh hai Top 3 riêng với một Top 3 chung — 11/11/2026',
'**Đính chính tiêu chí:** bộ 3 chung có ít nhất một số xuất hiện ở bất kỳ đài nào là đạt. Không đòi cùng số xuất hiện cả hai đài. Kết quả 9,86% trong nghiên cứu trước đo tiêu chí khác, không dùng trả lời yêu cầu này.',
'**Chỉ nghiên cứu. Không sửa XSMB, app, website, dữ liệu sản xuất, quyền riêng tư hay tác vụ tự động.**',
'## Kết luận',
'Chưa đủ bằng chứng rằng bộ 3 chung làm tăng đáng kể và bền vững tỷ lệ đạt. Có lợi ích gọn giao diện và có một số tín hiệu để theo dõi, nhưng chưa đủ cơ sở xây app mới với lời hứa dự báo chính xác hơn.',
'Đuôi 2 số: chọn công thức bằng ba năm phát triển, rồi chấm năm sau: cách cũ 253/365 = 69,32%; cách mới 257/365 = 70,41%, tăng 1,10 điểm phần trăm (4 ngày). Khoảng chênh lệch 95% xấp xỉ −4,46 đến +6,74 điểm phần trăm, vẫn có khả năng cách mới kém hơn.',
'Đuôi 3 số: cách được chọn từ giai đoạn trước đạt 6,03% cũ và 8,77% mới; mức mới vẫn dưới đối chứng ngẫu nhiên khoảng 9,70%. Không thể chỉ nhìn tăng so với một cách cũ xuống phong độ để kết luận có lợi thế.',
'## Dữ liệu và cách chấm',
f'Dữ liệu đóng băng gồm {res["source_rows"]:,} bảng từ {res["start"]} đến {res["end"]}, SHA256 `{res["source_sha256"]}`. Chỉ dùng miền Nam trong phép thử này. Giữ nguyên tám đài loại trừ và bảy cặp đài đã thống nhất.',
'Năm đầu làm lịch sử ban đầu; 1.461 ngày kế tiếp được chấm cuốn chiếu. Mỗi ngày dự báo được tạo trước khi đưa kết quả ngày đó vào lịch sử. Giai đoạn phát triển: 10/11/2022–09/11/2025. Giai đoạn sau: 10/11/2025–09/11/2026 (365 ngày). Dữ liệu đã được xem trong các nghiên cứu trước: đây là nghiên cứu hồi cứu, không phải tập kiểm định hoàn toàn chưa từng thấy.',
'Cách cũ: mỗi đài Top 3 riêng, dò đúng đài tương ứng. Cách mới: cùng một Top 3, dò cả hai đài. Đơn vị đánh giá chính là ngày/cặp đài: có ít nhất một lượt số–đài trúng thì đạt. Cả hai đều có 6 lượt số–đài. Đuôi 2 và 3 số chấm riêng, không cộng thành một tỷ lệ chung; không suy ra lợi nhuận từ tỷ lệ có ít nhất một lượt trúng.',
'Lịch sử riêng của TP. HCM gồm cả hai lần quay mỗi tuần, đúng cấu trúc theo đài. Lịch sử cặp cố định chỉ gồm các ngày cặp đó cùng quay. Không trộn các cặp đài khác nhau để tăng mẫu giả tạo.',
'App cho người dùng chọn một trong sáu công thức. Vì chưa biết công thức anh đang chọn trên thiết bị, báo cáo trình bày cả sáu; không gọi bất kỳ một công thức nào là cấu hình cá nhân hiện tại. So sánh chính chọn công thức cũ và mới tốt nhất trên giai đoạn phát triển, cùng tiêu chí, không chọn theo năm cuối.',
'## Những hướng đã thử',
'- 6 cách cũ: tần suất toàn kỳ, 10/20/50 kỳ gần, tần suất × độ vắng chặn 20 kỳ, số lần ra kỳ trước.',
'- 6 cách gộp lịch sử cặp: cùng sáu công thức, số xuất hiện ở một hoặc cả hai đài được tính là có mặt trong kỳ của cặp. Lặp kỳ trước tính số lần xuất hiện tổng hai đài.',
'- 12 cách kết hợp hai đài: bốn cửa sổ toàn kỳ/10/20/50, mỗi cửa sổ thử kết hợp cơ hội ở ít nhất một đài, ưu tiên đài mạnh hơn, hoặc ưu tiên số cân bằng hai đài. Tỷ lệ riêng được làm trơn bằng 20 kỳ giả định theo mức đồng đều; tham số được cố định cho lần thử, không dò tối ưu sau khi xem kết quả. Công thức 1−(1−pA)(1−pB) là giả thuyết xếp hạng dựa trên độc lập, không được hiển thị như xác suất đã hiệu chỉnh.',
'- 1 cách đồng thuận thứ hạng: tổng nghịch đảo thứ hạng có độ lệch 10, từ tần suất và 20/50 kỳ của hai đài. Không dò ngưỡng để chọn con số đẹp nhất.',
'Tổng cộng 19 hướng mới × 2 loại đuôi = 38 so sánh chính với cách cũ đã chọn. Có thêm 12 so sánh cùng công thức cũ/mới để giải thích tác động của việc gộp. Phân tích theo năm và từng cặp chỉ để kiểm tra độ ổn định, không chọn bỏ cặp sau khi thấy kết quả.',
'Đối chứng ngẫu nhiên tính chính xác bằng tổ hợp trên các số thực tế của ngày đó. Cách cũ lấy ngẫu nhiên độc lập ba số cho mỗi đài; cách mới lấy ngẫu nhiên một bộ ba chung. Khoảng bất định được lấy mẫu lại theo tuần lịch 20.000 lần, có khoảng hiệu chỉnh 38 so sánh chính. Khoảng này là xấp xỉ và không xử lý hết việc dữ liệu đã được nghiên cứu nhiều lần trước đây.']
for d,x in res['digits'].items():
 old,new=x['old_selected'],x['new_selected'];o,n=x['methods'][old],x['methods'][new]
 ls += [f'## Đuôi {d} số',f'Cách cũ chọn từ giai đoạn phát triển: **{label(old)}**. Cách mới chọn từ giai đoạn phát triển: **{label(new)}**.',
 '| Chỉ tiêu năm sau | Cũ | Mới |','|---|---:|---:|',f'| Ngày đạt / tổng ngày | {o["later"]["hits"]}/365 | {n["later"]["hits"]}/365 |',f'| Tỷ lệ đạt | {fmt(o["later"]["rate"])} | {fmt(n["later"]["rate"])} |',f'| Đối chứng ngẫu nhiên | {fmt(o["later"]["random"])} | {fmt(n["later"]["random"])} |']
 c=n['comparison'];ls += [f'Số ngày mới trúng/cũ trượt: {c["new_only"]}; cũ trúng/mới trượt: {c["old_only"]}. Khoảng chênh lệch 95%: {100*c["ci95"][0]:.2f} đến {100*c["ci95"][1]:.2f} điểm phần trăm.',
 '| Năm bắt đầu 10/11 | Cũ | Mới |','|---|---:|---:|']
 for y in o['years']:ls.append(f'| {y} | {fmt(o["years"][y]["rate"])} | {fmt(n["years"][y]["rate"])} |')
 ls += ['### Tất cả các hướng, kể cả kém hơn','| Hướng | Ba năm phát triển | Năm sau | Cả bốn năm chấm |','|---|---:|---:|---:|']
 for m,t in x['methods'].items():ls.append(f'| {label(m)} | {fmt(t["development"]["rate"])} | {fmt(t["later"]["rate"])} | {fmt(t["all"]["rate"])} |')
 ls+=['### Từng cặp đài trong năm sau — công thức đã chọn','| Cặp đài | Số ngày | Cũ | Mới |','|---|---:|---:|---:|']
 for w,pair in enumerate(res['pairs']):
  a,b=o['weekday_later'][str(w)],n['weekday_later'][str(w)];ls.append(f'| {" + ".join(pair)} | {a["n"]} | {fmt(a["rate"])} | {fmt(b["rate"])} |')
ls += ['## Tín hiệu dễ gây hiểu lầm',
'Đuôi 2 số, gộp theo 10 kỳ gần đạt 72,88% năm cuối, cao hơn cách riêng cùng 10 kỳ là 64,38%. Nhưng tính cả bốn năm, cách gộp chỉ 65,30%, thấp hơn cách riêng 66,46%. Hướng này không được chọn từ giai đoạn trước, và khoảng hiệu chỉnh cho so sánh cùng công thức vẫn chứa 0; không dùng riêng năm tốt để tuyên bố tăng chắc chắn.',
'Gộp theo lặp kỳ trước đạt 70,41% năm cuối, trong khi giữ nguyên công thức lặp kỳ trước theo từng đài đạt 70,96%. Do đó tăng 1,10 điểm so với cách cũ được chọn không có nghĩa việc gộp tự nó tốt hơn khi giữ cùng công thức.',
'Một bộ ba chung có mức ngẫu nhiên khoảng 66,66% cho đuôi 2 số trên hai đài. Vượt 60% trong bài toán này chưa đủ chứng minh thuật toán giỏi. Tỷ lệ của bộ ba ở hai đài cũng không phải xác suất của một số riêng lẻ.',
'## Kiểm tra và giới hạn',
f'Đã đối chiếu {ver["app_reference_forecasts"]} dự báo cũ và gộp với hàm xếp hạng JavaScript lấy từ mã app; khớp toàn bộ. Kiểm tra lại {ver["outcomes_checked"]:,} bản ghi về Top 3, đúng đài, điều kiện đạt, số lượt và số lần xuất hiện: khớp. Những bản ghi này là các công thức cùng ngày, không phải mẫu độc lập.',
'Dữ liệu dùng lại bản đóng băng đã kiểm tra cấu trúc và đối chiếu mẫu 24 bảng ở nghiên cứu ngay trước. Lần này không tải lại toàn bộ Minh Ngọc. Không kiểm định XSMB và không kết luận về độ chính xác XSMB chỉ từ cảm nhận gần đây.',
'## Đề xuất',
'Chưa chuyển app chính hoặc tách app mới vì lý do “xác suất tăng cao”. Có thể giữ bộ ba chung làm ứng viên nghiên cứu vì gọn. Nếu anh duyệt bước tiếp theo, nên khóa vài công thức, ghi dự báo trước quay trên kỳ tương lai, xác định trước thời gian đánh giá và mức tăng tối thiểu anh thấy có giá trị. Chỉ đánh giá lại ở mốc đã chốt, không đổi công thức hằng ngày theo kết quả. Chưa thiết lập bước tương lai này.',
'## Tái lập',
'Chạy `python compare.py` (cần NumPy), `node verify.mjs`, `python verify.py`, `python report.py`. Có dữ liệu đầu vào, mã phân tích, bản sao hàm xếp hạng app để kiểm tra, dự báo từng ngày, kết quả theo năm/cặp và kiểm tra. Không gọi API cập nhật hoặc xuất bản app.']
(R/'BAO_CAO.md').write_text('\n\n'.join(ls),encoding='utf-8')
print('Report generated')
