import fs from 'node:fs';
import {rank} from './app_analysis_reference.mjs';
const root=new URL('./',import.meta.url),rows=JSON.parse(fs.readFileSync(new URL('seed.json',root)));
const results=JSON.parse(fs.readFileSync(new URL('results.json',root)));
const methods=['frequency','recent10','recent20','recent50','gap','repeat'];
const out=[];
for(const day of ['2022-11-10','2023-05-17','2024-11-11','2025-11-10','2026-06-05','2026-11-09']){
 const w=(new Date(day+'T00:00:00Z').getUTCDay()+6)%7;const [a,b]=results.pairs[w];
 const prior=rows.filter(r=>r.date<day);
 const grouped=new Map();
 for(const r of prior){if(![a,b].includes(r.station)||(new Date(r.date+'T00:00:00Z').getUTCDay()+6)%7!==w)continue; if(!grouped.has(r.date))grouped.set(r.date,{date:r.date,numbers:[]});grouped.get(r.date).numbers.push(...r.numbers);}
 for(const d of [2,3])for(const method of methods){
  const top=ds=>rank(ds,d,method).slice(0,3).map(x=>x.number).join(',');
  out.push({date:day,digits:d,method:'old_'+method,top_a:top(prior.filter(r=>r.station===a)),top_b:top(prior.filter(r=>r.station===b))});
  const common=top([...grouped.values()]);out.push({date:day,digits:d,method:'pair_'+method,top_a:common,top_b:common});
 }
}
fs.writeFileSync(new URL('js_reference.json',root),JSON.stringify(out));
console.log(out.length+' reference forecasts from actual app ranking function');
const north=[];
for(const day of ['2022-11-10','2024-11-11','2026-11-09'])for(const digits of [2,3])for(const method of methods){
 const top=rank(rows.filter(r=>r.station==='XSMB'&&r.date<day),digits,method).slice(0,3).map(r=>r.number).join(',');
 north.push({date:day,digits,method:'old_'+method,top});
}
fs.writeFileSync(new URL('north_js_reference.json',root),JSON.stringify(north));
