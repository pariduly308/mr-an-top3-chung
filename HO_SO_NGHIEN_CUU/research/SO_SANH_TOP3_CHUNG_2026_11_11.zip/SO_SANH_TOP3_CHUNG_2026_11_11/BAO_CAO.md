# So sánh hai Top 3 riêng với một Top 3 chung — 11/11/2026

**Đính chính tiêu chí:** bộ 3 chung có ít nhất một số xuất hiện ở bất kỳ đài nào là đạt. Không đòi cùng số xuất hiện cả hai đài. Kết quả 9,86% trong nghiên cứu trước đo tiêu chí khác, không dùng trả lời yêu cầu này.

**Chỉ nghiên cứu. Không sửa XSMB, app, website, dữ liệu sản xuất, quyền riêng tư hay tác vụ tự động.**

## Kết luận

Chưa đủ bằng chứng rằng bộ 3 chung làm tăng đáng kể và bền vững tỷ lệ đạt. Có lợi ích gọn giao diện và có một số tín hiệu để theo dõi, nhưng chưa đủ cơ sở xây app mới với lời hứa dự báo chính xác hơn.

Đuôi 2 số: chọn công thức bằng ba năm phát triển, rồi chấm năm sau: cách cũ 253/365 = 69,32%; cách mới 257/365 = 70,41%, tăng 1,10 điểm phần trăm (4 ngày). Khoảng chênh lệch 95% xấp xỉ −4,46 đến +6,74 điểm phần trăm, vẫn có khả năng cách mới kém hơn.

Đuôi 3 số: cách được chọn từ giai đoạn trước đạt 6,03% cũ và 8,77% mới; mức mới vẫn dưới đối chứng ngẫu nhiên khoảng 9,70%. Không thể chỉ nhìn tăng so với một cách cũ xuống phong độ để kết luận có lợi thế.

## Dữ liệu và cách chấm

Dữ liệu đóng băng gồm 7,545 bảng từ 2021-11-10 đến 2026-11-09, SHA256 `a2d49d6197fad66fab4dfca06851e7b8f667fc2a65c87030efcfd26c393de1e0`. Chỉ dùng miền Nam trong phép thử này. Giữ nguyên tám đài loại trừ và bảy cặp đài đã thống nhất.

Năm đầu làm lịch sử ban đầu; 1.461 ngày kế tiếp được chấm cuốn chiếu. Mỗi ngày dự báo được tạo trước khi đưa kết quả ngày đó vào lịch sử. Giai đoạn phát triển: 10/11/2022–09/11/2025. Giai đoạn sau: 10/11/2025–09/11/2026 (365 ngày). Dữ liệu đã được xem trong các nghiên cứu trước: đây là nghiên cứu hồi cứu, không phải tập kiểm định hoàn toàn chưa từng thấy.

Cách cũ: mỗi đài Top 3 riêng, dò đúng đài tương ứng. Cách mới: cùng một Top 3, dò cả hai đài. Đơn vị đánh giá chính là ngày/cặp đài: có ít nhất một lượt số–đài trúng thì đạt. Cả hai đều có 6 lượt số–đài. Đuôi 2 và 3 số chấm riêng, không cộng thành một tỷ lệ chung; không suy ra lợi nhuận từ tỷ lệ có ít nhất một lượt trúng.

Lịch sử riêng của TP. HCM gồm cả hai lần quay mỗi tuần, đúng cấu trúc theo đài. Lịch sử cặp cố định chỉ gồm các ngày cặp đó cùng quay. Không trộn các cặp đài khác nhau để tăng mẫu giả tạo.

App cho người dùng chọn một trong sáu công thức. Vì chưa biết công thức anh đang chọn trên thiết bị, báo cáo trình bày cả sáu; không gọi bất kỳ một công thức nào là cấu hình cá nhân hiện tại. So sánh chính chọn công thức cũ và mới tốt nhất trên giai đoạn phát triển, cùng tiêu chí, không chọn theo năm cuối.

## Những hướng đã thử

- 6 cách cũ: tần suất toàn kỳ, 10/20/50 kỳ gần, tần suất × độ vắng chặn 20 kỳ, số lần ra kỳ trước.

- 6 cách gộp lịch sử cặp: cùng sáu công thức, số xuất hiện ở một hoặc cả hai đài được tính là có mặt trong kỳ của cặp. Lặp kỳ trước tính số lần xuất hiện tổng hai đài.

- 12 cách kết hợp hai đài: bốn cửa sổ toàn kỳ/10/20/50, mỗi cửa sổ thử kết hợp cơ hội ở ít nhất một đài, ưu tiên đài mạnh hơn, hoặc ưu tiên số cân bằng hai đài. Tỷ lệ riêng được làm trơn bằng 20 kỳ giả định theo mức đồng đều; tham số được cố định cho lần thử, không dò tối ưu sau khi xem kết quả. Công thức 1−(1−pA)(1−pB) là giả thuyết xếp hạng dựa trên độc lập, không được hiển thị như xác suất đã hiệu chỉnh.

- 1 cách đồng thuận thứ hạng: tổng nghịch đảo thứ hạng có độ lệch 10, từ tần suất và 20/50 kỳ của hai đài. Không dò ngưỡng để chọn con số đẹp nhất.

Tổng cộng 19 hướng mới × 2 loại đuôi = 38 so sánh chính với cách cũ đã chọn. Có thêm 12 so sánh cùng công thức cũ/mới để giải thích tác động của việc gộp. Phân tích theo năm và từng cặp chỉ để kiểm tra độ ổn định, không chọn bỏ cặp sau khi thấy kết quả.

Đối chứng ngẫu nhiên tính chính xác bằng tổ hợp trên các số thực tế của ngày đó. Cách cũ lấy ngẫu nhiên độc lập ba số cho mỗi đài; cách mới lấy ngẫu nhiên một bộ ba chung. Khoảng bất định được lấy mẫu lại theo tuần lịch 20.000 lần, có khoảng hiệu chỉnh 38 so sánh chính. Khoảng này là xấp xỉ và không xử lý hết việc dữ liệu đã được nghiên cứu nhiều lần trước đây.

## Đuôi 2 số

Cách cũ chọn từ giai đoạn phát triển: **Riêng từng đài: Tần suất × độ vắng**. Cách mới chọn từ giai đoạn phát triển: **Gộp lịch sử cặp: Lặp ở kỳ trước**.

| Chỉ tiêu năm sau | Cũ | Mới |

|---|---:|---:|

| Ngày đạt / tổng ngày | 253/365 | 257/365 |

| Tỷ lệ đạt | 69.32% | 70.41% |

| Đối chứng ngẫu nhiên | 66.57% | 66.66% |

Số ngày mới trúng/cũ trượt: 78; cũ trúng/mới trượt: 74. Khoảng chênh lệch 95%: -4.46 đến 6.74 điểm phần trăm.

| Năm bắt đầu 10/11 | Cũ | Mới |

|---|---:|---:|

| 2022 | 68.22% | 71.78% |

| 2023 | 70.49% | 66.67% |

| 2024 | 63.56% | 69.59% |

| 2025 | 69.32% | 70.41% |

### Tất cả các hướng, kể cả kém hơn

| Hướng | Ba năm phát triển | Năm sau | Cả bốn năm chấm |

|---|---:|---:|---:|

| Riêng từng đài: Tần suất | 66.42% | 67.95% | 66.80% |

| Gộp lịch sử cặp: Tần suất | 65.42% | 66.03% | 65.57% |

| Riêng từng đài: 10 kỳ gần | 67.15% | 64.38% | 66.46% |

| Gộp lịch sử cặp: 10 kỳ gần | 62.77% | 72.88% | 65.30% |

| Riêng từng đài: 20 kỳ gần | 65.33% | 71.51% | 66.87% |

| Gộp lịch sử cặp: 20 kỳ gần | 60.95% | 67.12% | 62.49% |

| Riêng từng đài: 50 kỳ gần | 66.97% | 67.67% | 67.15% |

| Gộp lịch sử cặp: 50 kỳ gần | 63.87% | 68.22% | 64.96% |

| Riêng từng đài: Tần suất × độ vắng | 67.43% | 69.32% | 67.90% |

| Gộp lịch sử cặp: Tần suất × độ vắng | 66.06% | 71.78% | 67.49% |

| Riêng từng đài: Lặp ở kỳ trước | 66.33% | 70.96% | 67.49% |

| Gộp lịch sử cặp: Lặp ở kỳ trước | 69.34% | 70.41% | 69.61% |

| Kết hợp cơ hội ở ít nhất một đài — toàn kỳ | 65.05% | 66.03% | 65.30% |

| Ưu tiên đài mạnh hơn — toàn kỳ | 66.15% | 63.01% | 65.37% |

| Cân bằng hai đài — toàn kỳ | 66.51% | 66.30% | 66.46% |

| Kết hợp cơ hội ở ít nhất một đài — 10 kỳ | 65.33% | 70.14% | 66.53% |

| Ưu tiên đài mạnh hơn — 10 kỳ | 64.32% | 66.85% | 64.96% |

| Cân bằng hai đài — 10 kỳ | 67.34% | 69.59% | 67.90% |

| Kết hợp cơ hội ở ít nhất một đài — 20 kỳ | 63.50% | 65.75% | 64.07% |

| Ưu tiên đài mạnh hơn — 20 kỳ | 64.69% | 67.12% | 65.30% |

| Cân bằng hai đài — 20 kỳ | 65.69% | 66.03% | 65.78% |

| Kết hợp cơ hội ở ít nhất một đài — 50 kỳ | 66.79% | 66.03% | 66.60% |

| Ưu tiên đài mạnh hơn — 50 kỳ | 66.79% | 67.95% | 67.08% |

| Cân bằng hai đài — 50 kỳ | 66.51% | 64.66% | 66.05% |

| Đồng thuận thứ hạng hai đài | 67.15% | 65.21% | 66.67% |

### Từng cặp đài trong năm sau — công thức đã chọn

| Cặp đài | Số ngày | Cũ | Mới |

|---|---:|---:|---:|

| TP. HCM + Đồng Tháp | 53 | 69.81% | 58.49% |

| Bến Tre + Vũng Tàu | 52 | 71.15% | 69.23% |

| Đồng Nai + Cần Thơ | 52 | 67.31% | 65.38% |

| Tây Ninh + An Giang | 52 | 73.08% | 78.85% |

| Vĩnh Long + Bình Dương | 52 | 75.00% | 71.15% |

| TP. HCM + Long An | 52 | 51.92% | 80.77% |

| Tiền Giang + Kiên Giang | 52 | 76.92% | 69.23% |

## Đuôi 3 số

Cách cũ chọn từ giai đoạn phát triển: **Riêng từng đài: Tần suất × độ vắng**. Cách mới chọn từ giai đoạn phát triển: **Cân bằng hai đài — toàn kỳ**.

| Chỉ tiêu năm sau | Cũ | Mới |

|---|---:|---:|

| Ngày đạt / tổng ngày | 22/365 | 32/365 |

| Tỷ lệ đạt | 6.03% | 8.77% |

| Đối chứng ngẫu nhiên | 9.71% | 9.70% |

Số ngày mới trúng/cũ trượt: 30; cũ trúng/mới trượt: 20. Khoảng chênh lệch 95%: -0.55 đến 5.93 điểm phần trăm.

| Năm bắt đầu 10/11 | Cũ | Mới |

|---|---:|---:|

| 2022 | 9.86% | 10.14% |

| 2023 | 8.47% | 10.93% |

| 2024 | 13.70% | 9.04% |

| 2025 | 6.03% | 8.77% |

### Tất cả các hướng, kể cả kém hơn

| Hướng | Ba năm phát triển | Năm sau | Cả bốn năm chấm |

|---|---:|---:|---:|

| Riêng từng đài: Tần suất | 9.31% | 7.40% | 8.83% |

| Gộp lịch sử cặp: Tần suất | 8.21% | 11.78% | 9.10% |

| Riêng từng đài: 10 kỳ gần | 9.49% | 8.77% | 9.31% |

| Gộp lịch sử cặp: 10 kỳ gần | 8.94% | 9.32% | 9.03% |

| Riêng từng đài: 20 kỳ gần | 8.85% | 12.60% | 9.79% |

| Gộp lịch sử cặp: 20 kỳ gần | 9.49% | 10.96% | 9.86% |

| Riêng từng đài: 50 kỳ gần | 9.40% | 9.04% | 9.31% |

| Gộp lịch sử cặp: 50 kỳ gần | 8.58% | 10.96% | 9.17% |

| Riêng từng đài: Tần suất × độ vắng | 10.68% | 6.03% | 9.51% |

| Gộp lịch sử cặp: Tần suất × độ vắng | 9.85% | 8.22% | 9.45% |

| Riêng từng đài: Lặp ở kỳ trước | 10.22% | 11.78% | 10.61% |

| Gộp lịch sử cặp: Lặp ở kỳ trước | 8.85% | 10.41% | 9.24% |

| Kết hợp cơ hội ở ít nhất một đài — toàn kỳ | 8.58% | 9.32% | 8.76% |

| Ưu tiên đài mạnh hơn — toàn kỳ | 8.58% | 8.22% | 8.49% |

| Cân bằng hai đài — toàn kỳ | 10.04% | 8.77% | 9.72% |

| Kết hợp cơ hội ở ít nhất một đài — 10 kỳ | 8.30% | 9.59% | 8.62% |

| Ưu tiên đài mạnh hơn — 10 kỳ | 8.85% | 8.77% | 8.83% |

| Cân bằng hai đài — 10 kỳ | 8.39% | 9.59% | 8.69% |

| Kết hợp cơ hội ở ít nhất một đài — 20 kỳ | 8.39% | 10.41% | 8.90% |

| Ưu tiên đài mạnh hơn — 20 kỳ | 7.85% | 12.33% | 8.97% |

| Cân bằng hai đài — 20 kỳ | 8.49% | 6.58% | 8.01% |

| Kết hợp cơ hội ở ít nhất một đài — 50 kỳ | 8.39% | 9.86% | 8.76% |

| Ưu tiên đài mạnh hơn — 50 kỳ | 8.76% | 9.86% | 9.03% |

| Cân bằng hai đài — 50 kỳ | 8.58% | 10.41% | 9.03% |

| Đồng thuận thứ hạng hai đài | 9.03% | 11.23% | 9.58% |

### Từng cặp đài trong năm sau — công thức đã chọn

| Cặp đài | Số ngày | Cũ | Mới |

|---|---:|---:|---:|

| TP. HCM + Đồng Tháp | 53 | 5.66% | 1.89% |

| Bến Tre + Vũng Tàu | 52 | 7.69% | 9.62% |

| Đồng Nai + Cần Thơ | 52 | 7.69% | 5.77% |

| Tây Ninh + An Giang | 52 | 1.92% | 19.23% |

| Vĩnh Long + Bình Dương | 52 | 5.77% | 9.62% |

| TP. HCM + Long An | 52 | 5.77% | 9.62% |

| Tiền Giang + Kiên Giang | 52 | 7.69% | 5.77% |

## Tín hiệu dễ gây hiểu lầm

Đuôi 2 số, gộp theo 10 kỳ gần đạt 72,88% năm cuối, cao hơn cách riêng cùng 10 kỳ là 64,38%. Nhưng tính cả bốn năm, cách gộp chỉ 65,30%, thấp hơn cách riêng 66,46%. Hướng này không được chọn từ giai đoạn trước, và khoảng hiệu chỉnh cho so sánh cùng công thức vẫn chứa 0; không dùng riêng năm tốt để tuyên bố tăng chắc chắn.

Gộp theo lặp kỳ trước đạt 70,41% năm cuối, trong khi giữ nguyên công thức lặp kỳ trước theo từng đài đạt 70,96%. Do đó tăng 1,10 điểm so với cách cũ được chọn không có nghĩa việc gộp tự nó tốt hơn khi giữ cùng công thức.

Một bộ ba chung có mức ngẫu nhiên khoảng 66,66% cho đuôi 2 số trên hai đài. Vượt 60% trong bài toán này chưa đủ chứng minh thuật toán giỏi. Tỷ lệ của bộ ba ở hai đài cũng không phải xác suất của một số riêng lẻ.

## Kiểm tra và giới hạn

Đã đối chiếu 144 dự báo cũ và gộp với hàm xếp hạng JavaScript lấy từ mã app; khớp toàn bộ. Kiểm tra lại 73,050 bản ghi về Top 3, đúng đài, điều kiện đạt, số lượt và số lần xuất hiện: khớp. Những bản ghi này là các công thức cùng ngày, không phải mẫu độc lập.

Dữ liệu dùng lại bản đóng băng đã kiểm tra cấu trúc và đối chiếu mẫu 24 bảng ở nghiên cứu ngay trước. Lần này không tải lại toàn bộ Minh Ngọc. Không kiểm định XSMB và không kết luận về độ chính xác XSMB chỉ từ cảm nhận gần đây.

## Đề xuất

Chưa chuyển app chính hoặc tách app mới vì lý do “xác suất tăng cao”. Có thể giữ bộ ba chung làm ứng viên nghiên cứu vì gọn. Nếu anh duyệt bước tiếp theo, nên khóa vài công thức, ghi dự báo trước quay trên kỳ tương lai, xác định trước thời gian đánh giá và mức tăng tối thiểu anh thấy có giá trị. Chỉ đánh giá lại ở mốc đã chốt, không đổi công thức hằng ngày theo kết quả. Chưa thiết lập bước tương lai này.

## Tái lập

Chạy `python compare.py` (cần NumPy), `node verify.mjs`, `python verify.py`, `python report.py`. Có dữ liệu đầu vào, mã phân tích, bản sao hàm xếp hạng app để kiểm tra, dự báo từng ngày, kết quả theo năm/cặp và kiểm tra. Không gọi API cập nhật hoặc xuất bản app.