# Nghiên cứu chọn số cho kỳ kế tiếp — tham khảo thống kê Minh Ngọc

Ngày13/11/2026. Đã chạy8quy tắc×2chế độ×3phạm vi=48tổ hợp, so18đối chứnggốc. Không tự nhận đã thử mọi quy tắc có thể tồn tại. Đây là môhình Top3 do nghiêncứu địnhnghĩa dựa trên ýtưởng thốngkê, KHÔNG phải dựbáo được MinhNgọc côngbố.

**Mục tiêu:** chỉ nhìn lịch sử trước kỳt, chọn3số, sauđó chấm kếtquả kỳt. Số liệu dưới đây đo hiệuquả chọn cho kỳkếtiếp trong hồi cứu, không chỉ xếp thốngkê và không là xácsuất đảm bảo kỳtới.

Nguồn14.658bảng10/11/2016–11/11/2026; khởi tạo5năm, chấm10/11/2021–11/11/2026. Không sử dụng ngày12/11/2026. Đãxem cácgiaiđoạn trướcđây, không gọi kiểmtra tươnglai mới. Còn480vịtrílịch chưa phânloại nghỉ/thaylịch/thiếu; kếtquảtạmthời.

## 2 số — toàn bộ tám quy tắc

| Quy tắc | MN từng đài,5745kỳ | CặpMN,1828kỳ | XSMB,1808kỳ |
|---|---:|---:|---:|
| Tổng lượt 1 năm | 41.04% | 66.79% | 56.91% |
| Tổng lượt 3 năm | 43.12% | 67.18% | 56.14% |
| Tổng lượt 5 năm | 42.75% | 67.18% | 55.64% |
| Tổng lượt 10 kỳ | 42.33% | 64.66% | 55.64% |
| Tổng lượt 20 kỳ | 41.39% | 65.48% | 57.85% |
| Tổng lượt 50 kỳ | 41.81% | 66.30% | 57.91% |
| Vắng lâu nhất | 41.88% | 67.45% | 56.03% |
| Ra liên tiếp | 43.36% | 66.14% | 56.86% |
| Mốc chính | 42.65% | 67.83% | 54.37% |

## 3 số — toàn bộ tám quy tắc

| Quy tắc | MN từng đài,5745kỳ | CặpMN,1828kỳ | XSMB,1808kỳ |
|---|---:|---:|---:|
| Tổng lượt 1 năm | 4.82% | 9.03% | 7.41% |
| Tổng lượt 3 năm | 5.05% | 9.52% | 6.97% |
| Tổng lượt 5 năm | 4.63% | 9.52% | 7.91% |
| Tổng lượt 10 kỳ | 5.43% | 8.86% | 5.42% |
| Tổng lượt 20 kỳ | 4.86% | 9.41% | 6.19% |
| Tổng lượt 50 kỳ | 4.61% | 8.70% | 6.47% |
| Vắng lâu nhất | 4.51% | 10.67% | 6.25% |
| Ra liên tiếp | 5.29% | 9.74% | 6.64% |
| Mốc chính | 4.70% | 8.10% | 7.85% |

Mốc chính:từngđàiMN frequency5năm chỉ là mốc kỹthuật (app có6lựa chọn),cặpMNrepeat5năm,MBfrequency5năm. MNtừngđài có nhiềuđài/ngày nên bấtđịnh ghép toàn bộđài theo ngày; không coi5745kỳ là5745ngày độc lập. Không so trực tiếp ba cột vì khác sốgiải/cơhội.

## Tín hiệu thăm dò đáng theo dõi: tổng lượt50kỳ XSMB2số

Toànphần:57,91% vsapp5năm54,37%,chênh+3,54điểm%,CI95môtả[+0,22;+6,75]. So frequency1năm57,08%,chỉhơn0,83điểm%. So đếm sốkỳhiệndiện cùng50kỳ và cùngpháhòa:55,20%,chênh+2,71điểm%,CI[+0,94;+4,48]. Đốichứng50kỳ này có pháhòa theo cùng50kỳ; recent50gốc pháhòa theo tầnsuấttoàncửasổ nên làđốichứng khác, vẫnđược giữ trong bảng18côngthức.

Pháttriển1084kỳ57,47%; xác thực361kỳ53,46%; cuối363kỳ63,64% (10/11/2025–11/11/2026). Cuối soapp54,82%,chênh+8,82điểm%,CI[+1,65;+15,71]. Nhưng ứngviên KHÔNG được chọn trên xác thực; chúý nó saukhi thấy nămcuối là chọnlọc saukếtquả. CI chưahiệuchỉnh48tổhợp và lịch sửthử trước. Không đổi63,64% thành xácsuất kỳtới.

CặpMN3số tổnglượt3năm đượcchọnxácthực:cuối12,81%vsapp8,99%,CIchênh[-0,27;+8,17];so đối chứng repeat1năm11,72% chỉhơn1,09điểm%. Toànphần9,52% thấp hơn mốcđồngđều thực tế9,71%. Chưađủbằngchứng.

## Ứng viên chọn đúng phần xác thực

| Phạm vi | Đuôi | Ứng viên | Cuối mới | Cuối mốc chính | Cuối mốc cũ chọn xác thực | CI chênh mốc chính | Đạt sàng lọc |
|---|---:|---|---:|---:|---:|---|---|
| MN từng đài | 2 | Tổng lượt 3 năm | 43.97% | 43.71% | frequency_3:44.06% | [-2.86; +3.38] | Chưa |
| MN từng đài | 3 | Ra liên tiếp | 6.33% | 4.86% | repeat_3:5.81% | [-0.43; +3.39] | Chưa |
| MN cặp chung | 2 | Ra liên tiếp | 67.57% | 70.57% | repeat_3:66.49% | [-8.17; +2.72] | Chưa |
| MN cặp chung | 3 | Tổng lượt 3 năm | 12.81% | 8.99% | repeat_1:11.72% | [-0.27; +8.17] | Chưa |
| XSMB | 2 | Tổng lượt 3 năm | 55.37% | 54.82% | repeat_3:54.27% | [-6.61; +7.44] | Chưa |
| XSMB | 3 | Tổng lượt 1 năm | 7.44% | 8.54% | gap_1:4.68% | [-4.41; +1.93] | Chưa |

Không ứngviên chọnxácthực nào đạt toàn bộ tiêu chí. Điểmhay đángnghiêncứu là phânbiệt sốlần lặp và sốkỳhiệndiện; chưa có căn cứ thayapp. Cácquytắcrawgap/streak chỉdùng ngàytrướcđích, khôngmặcđịnh vắnglâu thì sắpra. Không có Brier/hiệuchỉnh vì chưađịnhnghĩa xácsuấttừngsố.

## Đầy đủ48so sánh và bất định

| Phạm vi | Đuôi | Quy tắc | Tỷ lệ | Mốc chính | CI95 chênh điểm% | Đồng đều |
|---|---:|---|---:|---:|---|---:|
| MN từng đài | 2 | Tổng lượt 1 năm | 41.04% | 42.65% | [-3.43; +0.21] | 42.23% |
| MN từng đài | 2 | Tổng lượt 3 năm | 43.12% | 42.65% | [-1.01; +1.98] | 42.23% |
| MN từng đài | 2 | Tổng lượt 5 năm | 42.75% | 42.65% | [-0.97; +1.17] | 42.23% |
| MN từng đài | 2 | Tổng lượt 10 kỳ | 42.33% | 42.65% | [-2.12; +1.46] | 42.23% |
| MN từng đài | 2 | Tổng lượt 20 kỳ | 41.39% | 42.65% | [-3.01; +0.42] | 42.23% |
| MN từng đài | 2 | Tổng lượt 50 kỳ | 41.81% | 42.65% | [-2.52; +0.99] | 42.23% |
| MN từng đài | 2 | Vắng lâu nhất | 41.88% | 42.65% | [-2.70; +1.18] | 42.23% |
| MN từng đài | 2 | Ra liên tiếp | 43.36% | 42.65% | [-1.01; +2.49] | 42.23% |
| MN từng đài | 3 | Tổng lượt 1 năm | 4.82% | 4.70% | [-0.63; +0.92] | 4.98% |
| MN từng đài | 3 | Tổng lượt 3 năm | 5.05% | 4.70% | [-0.30; +1.04] | 4.98% |
| MN từng đài | 3 | Tổng lượt 5 năm | 4.63% | 4.70% | [-0.26; +0.12] | 4.98% |
| MN từng đài | 3 | Tổng lượt 10 kỳ | 5.43% | 4.70% | [-0.04; +1.53] | 4.98% |
| MN từng đài | 3 | Tổng lượt 20 kỳ | 4.86% | 4.70% | [-0.59; +0.89] | 4.98% |
| MN từng đài | 3 | Tổng lượt 50 kỳ | 4.61% | 4.70% | [-0.82; +0.63] | 4.98% |
| MN từng đài | 3 | Vắng lâu nhất | 4.51% | 4.70% | [-0.97; +0.61] | 4.98% |
| MN từng đài | 3 | Ra liên tiếp | 5.29% | 4.70% | [-0.23; +1.39] | 4.98% |
| MN cặp chung | 2 | Tổng lượt 1 năm | 66.79% | 67.83% | [-4.16; +1.97] | 66.64% |
| MN cặp chung | 2 | Tổng lượt 3 năm | 67.18% | 67.83% | [-3.34; +2.19] | 66.64% |
| MN cặp chung | 2 | Tổng lượt 5 năm | 67.18% | 67.83% | [-3.39; +2.19] | 66.64% |
| MN cặp chung | 2 | Tổng lượt 10 kỳ | 64.66% | 67.83% | [-6.02; -0.38] | 66.64% |
| MN cặp chung | 2 | Tổng lượt 20 kỳ | 65.48% | 67.83% | [-5.36; +0.44] | 66.64% |
| MN cặp chung | 2 | Tổng lượt 50 kỳ | 66.30% | 67.83% | [-4.60; +1.59] | 66.64% |
| MN cặp chung | 2 | Vắng lâu nhất | 67.45% | 67.83% | [-3.56; +2.74] | 66.64% |
| MN cặp chung | 2 | Ra liên tiếp | 66.14% | 67.83% | [-4.54; +1.20] | 66.64% |
| MN cặp chung | 3 | Tổng lượt 1 năm | 9.03% | 8.10% | [-0.82; +2.63] | 9.71% |
| MN cặp chung | 3 | Tổng lượt 3 năm | 9.52% | 8.10% | [-0.49; +3.12] | 9.71% |
| MN cặp chung | 3 | Tổng lượt 5 năm | 9.52% | 8.10% | [-0.38; +3.06] | 9.71% |
| MN cặp chung | 3 | Tổng lượt 10 kỳ | 8.86% | 8.10% | [-0.93; +2.52] | 9.71% |
| MN cặp chung | 3 | Tổng lượt 20 kỳ | 9.41% | 8.10% | [-0.49; +3.23] | 9.71% |
| MN cặp chung | 3 | Tổng lượt 50 kỳ | 8.70% | 8.10% | [-1.15; +2.35] | 9.71% |
| MN cặp chung | 3 | Vắng lâu nhất | 10.67% | 8.10% | [+0.66; +4.38] | 9.71% |
| MN cặp chung | 3 | Ra liên tiếp | 9.74% | 8.10% | [+0.38; +2.90] | 9.71% |
| XSMB | 2 | Tổng lượt 1 năm | 56.91% | 54.37% | [-1.00; +5.97] | 56.10% |
| XSMB | 2 | Tổng lượt 3 năm | 56.14% | 54.37% | [-1.22; +4.65] | 56.10% |
| XSMB | 2 | Tổng lượt 5 năm | 55.64% | 54.37% | [-0.88; +3.43] | 56.10% |
| XSMB | 2 | Tổng lượt 10 kỳ | 55.64% | 54.37% | [-1.99; +4.26] | 56.10% |
| XSMB | 2 | Tổng lượt 20 kỳ | 57.85% | 54.37% | [+0.28; +6.80] | 56.10% |
| XSMB | 2 | Tổng lượt 50 kỳ | 57.91% | 54.37% | [+0.22; +6.75] | 56.10% |
| XSMB | 2 | Vắng lâu nhất | 56.03% | 54.37% | [-1.55; +5.03] | 56.10% |
| XSMB | 2 | Ra liên tiếp | 56.86% | 54.37% | [-0.94; +5.81] | 56.10% |
| XSMB | 3 | Tổng lượt 1 năm | 7.41% | 7.85% | [-1.88; +1.00] | 6.68% |
| XSMB | 3 | Tổng lượt 3 năm | 6.97% | 7.85% | [-2.21; +0.39] | 6.68% |
| XSMB | 3 | Tổng lượt 5 năm | 7.91% | 7.85% | [-0.39; +0.44] | 6.68% |
| XSMB | 3 | Tổng lượt 10 kỳ | 5.42% | 7.85% | [-4.04; -0.94] | 6.68% |
| XSMB | 3 | Tổng lượt 20 kỳ | 6.19% | 7.85% | [-3.32; +0.00] | 6.68% |
| XSMB | 3 | Tổng lượt 50 kỳ | 6.47% | 7.85% | [-3.04; +0.22] | 6.68% |
| XSMB | 3 | Vắng lâu nhất | 6.25% | 7.85% | [-3.21; +0.00] | 6.68% |
| XSMB | 3 | Ra liên tiếp | 6.64% | 7.85% | [-2.88; +0.39] | 6.68% |

## Kiểm toán, lưu trữ, bước tiếp
- 150,096 dự báo ứngviên được chấm lại độc lập từ bảngthật; 144Top3 được dựng lại bằng Counter trực tiếp; 37,524 kếtquảđối chứng frequency/repeat được đốichiếu lại. Không phát hiệnkhácbiệt.
- Giữ18đối chứng đủtừnggiaiđoạn trongresults.json; đủtừngnăm/từngđài/cặp và2/3số; predictions.json lưuTop3 thực tế tính lại. Mỗiđích chỉ dùng dữliệu trướcngàyđích; cậpnhật last/streak sauchấm.
- 48tổhợp mới cộng vào16tổhợp khác thường và14tổhợp trước; giữ19biếnthểMN/10MN→MB cũ và nghiêncứucửasổ, không đặt bộđếm về0. Một số ýtưởng trùng loại môhìnhđãthử nên không gọi toàn bộ là giảthuyết độc lập.
- Không thêm hoánvị saukhi xem kếtquả. Không dùng phép dịchngày lỗi củađợttrước đểkhẳngđịnh. Cần địnhtrước phépkiểmtraâm tính chạy lại toànchuỗihuấnluyện nếu nghiêncứu tiếp.
- Chỉ đềxuất đưa total50MB2 vào một phép theo dõi tươnglai riêng với côngthức và thờiđiểmkhóa cốđịnh; chưa tạo bảnkhóa hay áp dụng tronglượt này. Không sửa app, không sửa snapshot1/3/5năm.
- Chỉ báo cáo liênquan mục tiêu kỳkếtiếp; không kếtluận MinhNgọc hơn/kém môhình mình vì website không côngbố quytrìnhTop3 dựbáo tươngứng.

Source SHA256:821038b49415151984dae9dbff1ae894f3a6c63e04873adf9053fedb82c53820
Protocol SHA256:13fe7754704684efb7bc28fe17d52ef4481fb354b034906fd17d665680e452f2
Hoàn tất:2026-11-13T01:18:44.163620+00:00