import json,csv,datetime,collections,hashlib,math
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent;src=p.parent/'unusual_inputs/archive';raw=(src/'research_10y_data.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='821038b49415151984dae9dbff1ae894f3a6c63e04873adf9053fedb82c53820';rows=json.loads(raw);groups=collections.defaultdict(list)
for r in rows:groups[r['station']].append(r)
pairs=[['Tiền Giang','Kiên Giang'],['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An']]
for pair in pairs:
 by=collections.defaultdict(dict)
 for r in rows:
  if r['station']in pair:by[r['date']][r['station']]=r['numbers']
 name=' + '.join(pair);groups[name]=[dict(date=d,station=name,numbers=sum([g[s]for s in pair],[]))for d,g in sorted(by.items())if all(s in g for s in pair)]
base={};bm=['frequency','recent10','recent20','recent50','gap','repeat'];oldnames=[f'{m}_{y}'for m in bm for y in[1,3,5]]
with (src/'retrospective_predictions.csv').open()as f:
 for r in csv.DictReader(f):base.setdefault((r['date'],r['target'],int(r['digits'])),{})[r['method']+'_'+r['years']]=int(r['hit'])
newnames=['total1y','total3y','total5y','total10','total20','total50','rawgap','streak'];records=[];verified=0

def lower(d,y):
 t=datetime.date.fromisoformat(d)
 try:return t.replace(year=t.year-y).isoformat()
 except ValueError:return t.replace(year=t.year-y,month=3,day=1).isoformat()
for name,ds in groups.items():
 ds.sort(key=lambda r:r['date']);dates=np.array([r['date']for r in ds]);region='MB'if name=='XSMB'else'PAIR'if' + 'in name else'STATION'
 for k in[2,3]:
  N=10**k;count=np.zeros((len(ds),N),dtype=np.int16);nums=np.arange(N)
  for i,r in enumerate(ds):
   for x in r['numbers']:
    if len(x)>=k:count[i,int(x[-k:])]+=1
  present=count>0;pc=np.vstack([np.zeros(N,int),count.cumsum(axis=0)]);ph=np.vstack([np.zeros(N,int),present.cumsum(axis=0)]);last=np.full(N,-1);streak=np.zeros(N,int)
  for i,d in enumerate(dates):
   if d>='2021-11-10':
    d=str(d);lo=int(np.searchsorted(dates,lower(d,5)));h=ph[i]-ph[lo];gap=np.where(last>=lo,i-last-1,i-lo);scores={};op={}
    for y in[1,3,5]:
     l=int(np.searchsorted(dates,lower(d,y)));hy=ph[i]-ph[l];scores[f'total{y}y']=(pc[i]-pc[l],hy);op[f'total{y}y']=np.lexsort((nums,-hy))[:3]
    for z in[10,20,50]:
     l=max(lo,i-z);hy=ph[i]-ph[l];scores['total'+str(z)]=(pc[i]-pc[l],hy);op['total'+str(z)]=np.lexsort((nums,-hy))[:3]
    scores['rawgap']=(gap,h);scores['streak']=(np.minimum(streak,i-lo),h)
    actual=present[i];u=int(actual.sum());uniform=1-((N-u)*(N-u-1)*(N-u-2))/(N*(N-1)*(N-2));key=(d,name,k);assert len(base[key])==18
    # Check inherited frequency5 and repeat5 outcomes independently on every target.
    for m,sc in[('frequency',h),('repeat',count[i-1])]:
     top=np.lexsort((nums,-h,-sc))[:3];assert int(actual[top].any())==base[key][m+'_5'];verified+=1
    for m,(sc,hh)in scores.items():
     top=np.lexsort((nums,-hh,-sc))[:3];rec=dict(date=d,target=name,region=region,digits=k,method=m,top3=' '.join(str(x).zfill(k)for x in top),hit=int(actual[top].any()),matches=int(actual[top].sum()),uniform=uniform)
     if m in op:rec['presence_same_window']=int(actual[op[m]].any())
     records.append(rec)
   last[present[i]]=i;streak=np.where(present[i],streak+1,0)
 print('computed',name,flush=True)
(p/'predictions.json').write_text(json.dumps(records,ensure_ascii=False));rng=np.random.default_rng(13112026)
def period(d):return 'development'if d<'2024-11-10'else'validation'if d<'2025-11-10'else'late'
def compare(a,control):
 by=collections.defaultdict(lambda:[0,0,0])
 for r in a:
  z=by[r['date']];z[0]+=r['hit'];z[1]+=control(r);z[2]+=1
 arr=np.array([by[d]for d in sorted(by)]);n=len(arr);out=[]
 for _ in range(2000):
  ix=((rng.integers(0,n,size=math.ceil(n/7))[:,None]+np.arange(7))%n).ravel()[:n];v=arr[ix].sum(axis=0);out.append((v[0]-v[1])/v[2])
 total=arr.sum(axis=0);return dict(n=int(total[2]),days=n,rate=float(total[0]/total[2]),control_rate=float(total[1]/total[2]),delta=float((total[0]-total[1])/total[2]),ci95=np.quantile(out,[.025,.975]).tolist())
summary=[];selections=[];oldsummary=[]
for region in['STATION','PAIR','MB']:
 for k in[2,3]:
  main='repeat_5'if region=='PAIR'else'frequency_5';ra=[r for r in records if r['region']==region and r['digits']==k];target=sorted({(r['date'],r['target'],k)for r in ra});val=[x for x in target if period(x[0])=='validation'];bestold=sorted(oldnames,key=lambda m:(-sum(base[x][m]for x in val),m))[0]
  bestnew=sorted(newnames,key=lambda m:(-sum(r['hit']for r in ra if r['method']==m and period(r['date'])=='validation'),m))[0]
  for m in oldnames:
   for z in['ALL','development','validation','late']:
    ix=[x for x in target if z=='ALL'or period(x[0])==z];oldsummary.append(dict(region=region,digits=k,method=m,period=z,n=len(ix),rate=sum(base[x][m]for x in ix)/len(ix)))
  for m in newnames:
   aa=[r for r in ra if r['method']==m];control=lambda r:base[r['date'],r['target'],k][main];c=compare(aa,control);late=[r for r in aa if period(r['date'])=='late'];lc=compare(late,control);bc=compare(late,lambda r:base[r['date'],r['target'],k][bestold]);prs={z:dict(n=len(x:=[r for r in aa if period(r['date'])==z]),rate=sum(r['hit']for r in x)/len(x),control=sum(control(r)for r in x)/len(x))for z in['development','validation','late']};res=dict(region=region,digits=k,method=m,main=main,**c,late=lc,late_vs_validation_best=bc,validation_best_old=bestold,periods=prs,uniform=sum(r['uniform']for r in aa)/len(aa),selected_on_validation=m==bestnew)
   if m.startswith('total'):res['same_window_comparison']=compare(aa,lambda r:r['presence_same_window'])
   res['screen_pass']=bool(m==bestnew and lc['delta']>=.03 and bc['delta']>=.03 and lc['ci95'][0]>0 and bc['ci95'][0]>0 and lc['rate']>sum(r['uniform']for r in late)/len(late)and sum(v['rate']>v['control']for v in prs.values())>=2);summary.append(res)
  print('summarized',region,k,flush=True)
byyear=collections.defaultdict(lambda:[0,0])
for r in records:
 z=byyear[r['target'],r['digits'],r['method'],r['date'][:4]];z[0]+=r['hit'];z[1]+=1
out=dict(summary=summary,old_summary=oldsummary,by_year_target=[dict(target=s,digits=k,method=m,year=y,hits=v[0],n=v[1])for(s,k,m,y),v in byyear.items()],verified_baselines=verified,new_combinations=48,source_hash=hashlib.sha256(raw).hexdigest(),protocol_hash=hashlib.sha256((p/'PROTOCOL.md').read_bytes()).hexdigest())
(p/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('DONE',len(records),flush=True)
