import json,collections,datetime,hashlib,zipfile
from pathlib import Path
p=Path(__file__).resolve().parent;rows=json.loads((p.parent/'unusual_inputs/archive/research_10y_data.json').read_text());pred=json.loads((p/'predictions.json').read_text());result=json.loads((p/'results.json').read_text());by={(r['date'],r['station']):r for r in rows};assert len(by)==len(rows)
for r in rows:
 exp={2:4,3:3,4:10,5:10}if r['station']=='XSMB'else{2:1,3:1,4:4,5:11,6:1}
 assert dict(collections.Counter(map(len,r['numbers'])))==exp and all(isinstance(s,str)and s.isascii()and s.isdigit()for s in r['numbers'])
sets={}
for a in pred:
 key=(a['date'],a['target'],a['digits']);k=a['digits'];top=a['top3'].split();assert len(set(top))==3
 if key not in sets:sets[key]={n[-k:]for s in a['target'].split(' + ')for n in by[a['date'],s]['numbers']if len(n)>=k}
 assert a['matches']==len(set(top)&sets[key]);assert a['hit']==int(a['matches']>0)
# Independent direct Counter implementation on 144 representative candidate forecasts.
checks=0
for region in['STATION','PAIR','MB']:
 for k in[2,3]:
  for method in['total1y','total3y','total5y','total10','total20','total50','rawgap','streak']:
   aa=sorted([r for r in pred if r['region']==region and r['digits']==k and r['method']==method],key=lambda x:(x['date'],x['target']))
   for a in[aa[0],aa[len(aa)//2],aa[-1]]:
    members=a['target'].split(' + ');target=datetime.date.fromisoformat(a['date']);years=int(method[5])if method.endswith('y') else 5
    try:lower=target.replace(year=target.year-years).isoformat()
    except ValueError:lower=target.replace(year=target.year-years,month=3,day=1).isoformat()
    dates=sorted({r['date']for r in rows if lower<=r['date']<a['date']and r['station']==members[0]and all((r['date'],s)in by for s in members)})
    if method in['total10','total20','total50']:dates=dates[-int(method[5:]):]
    draws=[[n[-k:]for s in members for n in by[d,s]['numbers']if len(n)>=k]for d in dates];tot=collections.Counter(n for dr in draws for n in dr);presence=collections.Counter(n for dr in draws for n in set(dr));scores={}
    for i in range(10**k):
     n=str(i).zfill(k)
     if method.startswith('total'):score=tot[n]
     elif method=='rawgap':score=next((j for j,dr in enumerate(reversed(draws))if n in dr),len(draws))
     else:
      score=0
      for dr in reversed(draws):
       if n not in dr:break
       score+=1
     scores[n]=score
    top=sorted(scores,key=lambda n:(-scores[n],-presence[n],n))[:3];assert top==a['top3'].split(),(a,top);checks+=1
labels={'total1y':'Tổng lượt 1 năm','total3y':'Tổng lượt 3 năm','total5y':'Tổng lượt 5 năm','total10':'Tổng lượt 10 kỳ','total20':'Tổng lượt 20 kỳ','total50':'Tổng lượt 50 kỳ','rawgap':'Vắng lâu nhất','streak':'Ra liên tiếp'}
regionname={'STATION':'MN từng đài','PAIR':'MN cặp chung','MB':'XSMB'}
def pct(x):return f'{x*100:.2f}%'
def ci(xs):return '['+'; '.join(f'{x*100:+.2f}'for x in xs)+']'
lines=['# Nghiên cứu chọn số cho kỳ kế tiếp — tham khảo thống kê Minh Ngọc','', 'Ngày13/11/2026. Đã chạy8quy tắc×2chế độ×3phạm vi=48tổ hợp, so18đối chứnggốc. Không tự nhận đã thử mọi quy tắc có thể tồn tại. Đây là môhình Top3 do nghiêncứu địnhnghĩa dựa trên ýtưởng thốngkê, KHÔNG phải dựbáo được MinhNgọc côngbố.','', '**Mục tiêu:** chỉ nhìn lịch sử trước kỳt, chọn3số, sauđó chấm kếtquả kỳt. Số liệu dưới đây đo hiệuquả chọn cho kỳkếtiếp trong hồi cứu, không chỉ xếp thốngkê và không là xácsuất đảm bảo kỳtới.','', 'Nguồn14.658bảng10/11/2016–11/11/2026; khởi tạo5năm, chấm10/11/2021–11/11/2026. Không sử dụng ngày12/11/2026. Đãxem cácgiaiđoạn trướcđây, không gọi kiểmtra tươnglai mới. Còn480vịtrílịch chưa phânloại nghỉ/thaylịch/thiếu; kếtquảtạmthời.','', '## 2 số — toàn bộ tám quy tắc','', '| Quy tắc | MN từng đài,5745kỳ | CặpMN,1828kỳ | XSMB,1808kỳ |','|---|---:|---:|---:|']
for k in[2,3]:
 if k==3:lines+=['','## 3 số — toàn bộ tám quy tắc','','| Quy tắc | MN từng đài,5745kỳ | CặpMN,1828kỳ | XSMB,1808kỳ |','|---|---:|---:|---:|']
 for m in labels:lines.append('| '+labels[m]+' | '+' | '.join(pct(next(a['rate']for a in result['summary']if a['region']==region and a['digits']==k and a['method']==m))for region in['STATION','PAIR','MB'])+' |')
 lines.append('| Mốc chính | '+' | '.join(pct(next(a['control_rate']for a in result['summary']if a['region']==region and a['digits']==k))for region in['STATION','PAIR','MB'])+' |')
lines+=['','Mốc chính:từngđàiMN frequency5năm chỉ là mốc kỹthuật (app có6lựa chọn),cặpMNrepeat5năm,MBfrequency5năm. MNtừngđài có nhiềuđài/ngày nên bấtđịnh ghép toàn bộđài theo ngày; không coi5745kỳ là5745ngày độc lập. Không so trực tiếp ba cột vì khác sốgiải/cơhội.','', '## Tín hiệu thăm dò đáng theo dõi: tổng lượt50kỳ XSMB2số','', 'Toànphần:57,91% vsapp5năm54,37%,chênh+3,54điểm%,CI95môtả[+0,22;+6,75]. So frequency1năm57,08%,chỉhơn0,83điểm%. So đếm sốkỳhiệndiện cùng50kỳ và cùngpháhòa:55,20%,chênh+2,71điểm%,CI[+0,94;+4,48]. Đốichứng50kỳ này có pháhòa theo cùng50kỳ; recent50gốc pháhòa theo tầnsuấttoàncửasổ nên làđốichứng khác, vẫnđược giữ trong bảng18côngthức.','', 'Pháttriển1084kỳ57,47%; xác thực361kỳ53,46%; cuối363kỳ63,64% (10/11/2025–11/11/2026). Cuối soapp54,82%,chênh+8,82điểm%,CI[+1,65;+15,71]. Nhưng ứngviên KHÔNG được chọn trên xác thực; chúý nó saukhi thấy nămcuối là chọnlọc saukếtquả. CI chưahiệuchỉnh48tổhợp và lịch sửthử trước. Không đổi63,64% thành xácsuất kỳtới.','', 'CặpMN3số tổnglượt3năm đượcchọnxácthực:cuối12,81%vsapp8,99%,CIchênh[-0,27;+8,17];so đối chứng repeat1năm11,72% chỉhơn1,09điểm%. Toànphần9,52% thấp hơn mốcđồngđều thực tế9,71%. Chưađủbằngchứng.','', '## Ứng viên chọn đúng phần xác thực','','| Phạm vi | Đuôi | Ứng viên | Cuối mới | Cuối mốc chính | Cuối mốc cũ chọn xác thực | CI chênh mốc chính | Đạt sàng lọc |','|---|---:|---|---:|---:|---:|---|---|']
for a in result['summary']:
 if a['selected_on_validation']:lines.append('| '+' | '.join([regionname[a['region']],str(a['digits']),labels[a['method']],pct(a['late']['rate']),pct(a['late']['control_rate']),a['validation_best_old']+':'+pct(a['late_vs_validation_best']['control_rate']),ci(a['late']['ci95']),'Có'if a['screen_pass']else'Chưa'])+' |')
lines+=['','Không ứngviên chọnxácthực nào đạt toàn bộ tiêu chí. Điểmhay đángnghiêncứu là phânbiệt sốlần lặp và sốkỳhiệndiện; chưa có căn cứ thayapp. Cácquytắcrawgap/streak chỉdùng ngàytrướcđích, khôngmặcđịnh vắnglâu thì sắpra. Không có Brier/hiệuchỉnh vì chưađịnhnghĩa xácsuấttừngsố.','', '## Đầy đủ48so sánh và bất định','','| Phạm vi | Đuôi | Quy tắc | Tỷ lệ | Mốc chính | CI95 chênh điểm% | Đồng đều |','|---|---:|---|---:|---:|---|---:|']
for a in result['summary']:lines.append('| '+' | '.join([regionname[a['region']],str(a['digits']),labels[a['method']],pct(a['rate']),pct(a['control_rate']),ci(a['ci95']),pct(a['uniform'])])+' |')
lines+=['','## Kiểm toán, lưu trữ, bước tiếp',f'- {len(pred):,} dự báo ứngviên được chấm lại độc lập từ bảngthật; {checks}Top3 được dựng lại bằng Counter trực tiếp; {result["verified_baselines"]:,} kếtquảđối chứng frequency/repeat được đốichiếu lại. Không phát hiệnkhácbiệt.','- Giữ18đối chứng đủtừnggiaiđoạn trongresults.json; đủtừngnăm/từngđài/cặp và2/3số; predictions.json lưuTop3 thực tế tính lại. Mỗiđích chỉ dùng dữliệu trướcngàyđích; cậpnhật last/streak sauchấm.','- 48tổhợp mới cộng vào16tổhợp khác thường và14tổhợp trước; giữ19biếnthểMN/10MN→MB cũ và nghiêncứucửasổ, không đặt bộđếm về0. Một số ýtưởng trùng loại môhìnhđãthử nên không gọi toàn bộ là giảthuyết độc lập.','- Không thêm hoánvị saukhi xem kếtquả. Không dùng phép dịchngày lỗi củađợttrước đểkhẳngđịnh. Cần địnhtrước phépkiểmtraâm tính chạy lại toànchuỗihuấnluyện nếu nghiêncứu tiếp.','- Chỉ đềxuất đưa total50MB2 vào một phép theo dõi tươnglai riêng với côngthức và thờiđiểmkhóa cốđịnh; chưa tạo bảnkhóa hay áp dụng tronglượt này. Không sửa app, không sửa snapshot1/3/5năm.','- Chỉ báo cáo liênquan mục tiêu kỳkếtiếp; không kếtluận MinhNgọc hơn/kém môhình mình vì website không côngbố quytrìnhTop3 dựbáo tươngứng.','',f'Source SHA256:{result["source_hash"]}',f'Protocol SHA256:{result["protocol_hash"]}',f'Hoàn tất:{datetime.datetime.now(datetime.timezone.utc).isoformat()}']
(p/'BAO_CAO_DOI_CHIEU_MINH_NGOC.md').write_text('\n'.join(lines));(p/'validation.json').write_text(json.dumps(dict(predictions=len(pred),direct_top3_checks=checks,baseline_checks=result['verified_baselines'],valid=True)))
j=p/'MR_AN_TOP3_CHUNG_NHAT_KY_NGHIEN_CUU.md';j.write_text(j.read_text()+'\n\n## Định hướng kỳ kế tiếp và đối chiếu MinhNgọc — 13/11/2026\n'+(p/'BAO_CAO_DOI_CHIEU_MINH_NGOC.md').read_text()+'\nGói nối tiếp: MR_AN_DOI_CHIEU_MINH_NGOC_KY_KE_TIEP_2026_11_13.zip\n')
with zipfile.ZipFile(p/'MR_AN_DOI_CHIEU_MINH_NGOC_KY_KE_TIEP_2026_11_13.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in p.iterdir():
  if f.suffix in['.py','.json','.md','.mjs']and'NHAT_KY'not in f.name:z.write(f,f.name)
print('verified',len(pred),checks)
