import json,datetime,math,zipfile
from pathlib import Path
p=Path(__file__).parent;a=json.loads((p/'audit.json').read_text());status=json.loads((p/'status.json').read_text());state=json.loads((p.parent/'run/state.json').read_text());methods=['frequency','recent10','recent20','recent50','gap','repeat']
assert not a['changed'],'Corrections require reversing prior aggregates'
for r in a['incremental_retrospective']:
 assert r['date']not in state['processed_complete_day_hashes']
 y=int(r['date'][:4])-(r['date'][5:]<'11-10');summary=state['summary_year_station'];row=next((t for t in summary if(t['year'],t['station'],t['digits'])==(y,r['station'],r['digits'])),None)
 if row is None:row={'year':y,'station':r['station'],'digits':r['digits'],'n':0,'hits':{m:0 for m in methods}};summary.append(row)
 row['n']+=1
 for m in methods:row['hits'][m]+=r['hits'][m]
 b=next(t for t in state['calibration_bins_cumulative']if(t['station'],t['digits'])==(r['station'],r['digits']))
 b['bins']=[[x+y for x,y in zip(old,new)]for old,new in zip(b['bins'],r['bins'])]
for d in a['new_complete']:state['processed_complete_day_hashes'][d]=a['hashes'][d]
state['last_run']=a['lastCheck'];state['pending']=a['pending'];state['missing_forecasts']=a['missing_forecasts'];state['actual_scored_records']+=a['scored'];state['research_trials_added']=0
(p/'state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
ci=[]
for row in state['summary_year_station']:
 for method in methods:
  n=row['n'];ph=row['hits'][method]/n;z=1.96;den=1+z*z/n;center=(ph+z*z/(2*n))/den;half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
  ci.append({'station':row['station'],'year':row['year'],'digits':row['digits'],'method':method,'n':n,'wins':row['hits'][method],'rate':ph,'wilson95':[max(0,center-half),min(1,center+half)]})
(p/'intervals.json').write_text(json.dumps(ci,ensure_ascii=False,indent=2))
lines=['# Site cũ — cập nhật và đánh giá ngày13/11/2026','',f"Kiểm tra: {a['lastCheck']} (19:01:27 giờ Việt Nam). POST /api/update và GET /api/status, /data.json, /api/tracking thành công; errors={status['errors']}.",f"Kho có{a['rows']}bảng. Đủ ngày13/11: Bình Dương, Trà Vinh, Vĩnh Long, XSMB. Kiểm tra toàn kho không trùng đài/ngày, số lượng/độ dài đúng, số0đầu được giữ, lịch đài phù hợp. Kiểm tra bảng phẳng, không tái đối chiếu từng HTML trong lượt này. Không có hash ngày đã xử lý bị sửa; chỉ xử lý ngày13/11. Không phát hiện khoảng thiếu dài mới;20ngày lịch sử thiếuMB giữ trạng thái chờ xác minh như trước.",'','## Dự báo thực tế','/api/tracking chỉ có4bản ngày11/11. Không có bản khóa trướcquay13/11 cho cả4đài. Dự báo thực tế mới chấm=0. Không nhập bản của Site khác, không tạo lại dự báo sau thấy kết quả. Vấn đề thiếu bản khóa đã ghi ngày12/11 tiếp tục xảy ra; cần xử lý quy trình lưu trước16hMN/18hMB. Không tự đổi lịch/mã trong lượt này.','', '## Hồi cứu ngày mới — không tính là dự báo thật','| Đài | Đuôi | frequency | recent10 | recent20 | recent50 | gap | repeat | Brier prior20 | Đồng đều |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
for r in a['incremental_retrospective']:lines.append('| '+' | '.join([r['station'],str(r['digits'])]+[str(r['hits'][m])for m in methods]+[f"{r['brier']:.8f}",f"{r['uniform_brier']:.8f}"])+' |')
lines+=['','1=Top3 có ít nhất1số ra,0=không. Một dòng là một kỳ, không phải phần trăm kỳ tới. Các sốTop3 đầyđủ vàbins nằm trongaudit.json. Sáu côngthức six-methods-v1 giữnguyên; chỉ dùng lịch sử đúngđài từ10/11/2021 đến trước ngàyđích. Mô hình xácsuất nghiên cứu prior20: p=(hits+20p0)/(n+20),p0=1-(1-1/N)^K; không suy xácsuất từ điểmxếphạng. Brier là hồi cứu, không có bản xácsuất đãkhóa trướcquay. Không thay tham số.','MốcTop3 độc lập đồngđều cùng3lựa chọn:MN2=42,205%;MN3=4,979%;MB2=56,062%;MB3=6,677%. Chưa có bằngchứng lợi thế mới; không tăng%hiểnthị.','Đã cộng8dòng mới vào tổnghợp từngnăm/đài, giữ lịch sử cũ; bins cộng theo đúngđài và chếđộ. intervals.json cậpnhật Wilson95 theo sốkỳ của mỗiđài, chỉmô tả, giảđịnhkỳđộc lập và chưahiệu chỉnhnhiều so sánh. Không dùng100/1000số như mẫukỳ độc lập. Một ngày mới chưa đủ cậpnhật kếtluận ưu thế.','', '## Tiếp nối nghiên cứu','Không mở côngthức hay tốiưu mới (0thử). Giữ các giảthuyết và bộđếm đãghi, gồm38so sánhMN và20nhánhMB; tổngcấu hìnhduynhất chưa kiểm kê đầyđủ. Giảthuyết lạ vẫn phải địnhtrước và có đốichứng/kiểmtraâm tính phùhợp. Không chạy lại hai giảthuyết5năm đãxem tronglượt này; ưu tiên khâu bảnkhóa đang thiếu, chấtlượng và chấm kỳ mới. Không nhập kếtquả từ SiteTop3chung vào thành tích Sitecũ.','Không sửa app/mã/cách tính/quyền/người xem và không xuất bản. Nghiên cứu liên tục chưa hoàn thành; một lần cập nhật dữ liệu không phải điều kiện dừng.','',f"Hash13/11: {a['hashes']['2026-11-13']}",'Gói nối tiếp: XO_SO_MR_AN_KIEM_TRA_2026_11_13.zip.']
report='\n'.join(lines);(p/'BAO_CAO_2026_11_13.md').write_text(report)
j=p/'XO_SO_MR_AN_NHAT_KY_NGHIEN_CUU.md';j.write_text(j.read_text()+'\n\n## Cập nhật13/11/2026 — bản ghi mới nhất\n'+report+'\n\n```json\n'+json.dumps({'processed_new_day_hashes':{d:a['hashes'][d]for d in a['new_complete']},'lastCheck':a['lastCheck'],'pending':a['pending'],'missing_forecasts':a['missing_forecasts'],'new_actual_scores':len(a['scored']),'research_trials_added':0},ensure_ascii=False,indent=2)+'\n```\n')
with zipfile.ZipFile(p/'XO_SO_MR_AN_KIEM_TRA_2026_11_13.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name in ['audit.py','report.py','audit.json','state.json','intervals.json','data.json','status.json','tracking.json','update.json','BAO_CAO_2026_11_13.md']:z.write(p/name,name)
print(report)
