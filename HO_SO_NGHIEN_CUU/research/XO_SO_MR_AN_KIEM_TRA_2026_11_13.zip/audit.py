import json,re,hashlib,collections,datetime,math
from pathlib import Path
import numpy as np
p=Path(__file__).parent;rows=json.loads((p/'data.json').read_text());track=json.loads((p/'tracking.json').read_text());journal=(p/'XO_SO_MR_AN_NHAT_KY_NGHIEN_CUU.md').read_text();blocks=[json.loads(b)for b in re.findall(r'```json\s*(.*?)```',journal,re.S)];old=dict(blocks[4])
for block in blocks[5:]:
 if isinstance(block,dict):old.update(block.get("processed_new_day_hashes",{}))
schedule=[['TP. HCM','Đồng Tháp','Cà Mau'],['Bến Tre','Vũng Tàu','Bạc Liêu'],['Đồng Nai','Cần Thơ','Sóc Trăng'],['Tây Ninh','An Giang','Bình Thuận'],['Vĩnh Long','Bình Dương','Trà Vinh'],['TP. HCM','Long An','Bình Phước','Hậu Giang'],['Tiền Giang','Kiên Giang','Đà Lạt']]
by=collections.defaultdict(list);quality=[];seen=set()
for r in rows:
 key=(r['date'],r['station']);assert key not in seen;seen.add(key)
 expected={2:4,3:3,4:10,5:10}if r['station']=='XSMB'else{2:1,3:1,4:4,5:11,6:1}
 assert all(isinstance(s,str)and s.isdigit()for s in r['numbers'])and dict(collections.Counter(map(len,r['numbers'])))==expected
 assert r['station']=='XSMB'or r['station']in schedule[datetime.date.fromisoformat(r['date']).weekday()]
 by[r['date']].append(r)
# Recover journal hash serialization by matching previously processed last date, without assuming change.
sample='2026-11-11';serializer=None
for sortrows in[False,True]:
 for sortkeys in[False,True]:
  for ascii in[False,True]:
   for compact in[False,True]:
    def enc(rs,sr=sortrows,sk=sortkeys,a=ascii,c=compact):return json.dumps(sorted(rs,key=lambda r:r['station'])if sr else rs,ensure_ascii=a,sort_keys=sk,**({'separators':(',',':')}if c else{})).encode()
    if hashlib.sha256(enc(by[sample])).hexdigest()==old[sample]:serializer=enc
serializer=lambda rs:json.dumps({r['station']:r['numbers'] for r in rs},ensure_ascii=False,sort_keys=True).encode()
assert hashlib.sha256(serializer(by[sample])).hexdigest()==old[sample]
hashes={d:hashlib.sha256(serializer(rs)).hexdigest()for d,rs in by.items()};new=[];pending={};changed=[]
for d,rs in sorted(by.items()):
 exp=set(schedule[datetime.date.fromisoformat(d).weekday()]+['XSMB']);missing=exp-{r['station']for r in rs}
 if missing:pending[d]=sorted(missing)
 elif d not in old:new.append(d)
 elif hashes[d]!=old[d]:changed.append(d)
scored=[];missingforecast=[];retro=[];methods=['frequency','recent10','recent20','recent50','gap','repeat']
# Recheck all available actual locks, but append only new-date scores.
for f in track:
 if f['date'] not in new+changed:continue
 cutoff=f['date']+('T18:00:00+07:00'if f['station']=='XSMB'else'T16:00:00+07:00')
 valid=datetime.datetime.fromisoformat(f['createdAt'].replace('Z','+00:00'))<datetime.datetime.fromisoformat(cutoff)and f['historyThrough']<f['date']
 if not valid:continue
 actual=next((r for r in by[f['date']]if r['station']==f['station']),None)
 if not actual:continue
 for k,ms in f['predictions'].items():
  ss={s[-int(k):]for s in actual['numbers']if len(s)>=int(k)}
  for m,top in ms.items():
   match=[s for s in top if s in ss];assert match==f['scores'][k][m]
   scored.append(dict(date=f['date'],station=f['station'],digits=int(k),method=m,selected=top,matched=match,hit=int(bool(match)),createdAt=f['createdAt']))
for d in new+changed:
 for r in by[d]:
  s=r['station'];hist=[a for a in rows if a['station']==s and a['date']<d];hist.sort(key=lambda a:a['date'])
  if not any(f['date']==d and f['station']==s for f in track):missingforecast.append([d,s])
  for k in[2,3]:
   N=10**k;count=np.zeros((len(hist),N),int)
   for i,a in enumerate(hist):
    for x in a['numbers']:
     if len(x)>=k:count[i,int(x[-k:])]+=1
   h=(count>0).sum(axis=0);n=len(hist);last=np.full(N,-1)
   for i,a in enumerate(count):last[a>0]=i
   gap=np.where(last>=0,n-last-1,n);scores=[h,*[(count[-z:]>0).sum(axis=0)for z in[10,20,50]],h*np.minimum(gap,20)/20,count[-1]];actual=np.zeros(N)
   for x in r['numbers']:
    if len(x)>=k:actual[int(x[-k:])]=1
   K=sum(len(x)>=k for x in r['numbers']);p0=1-(1-1/N)**K;prob=(h+20*p0)/(n+20);bins=[]
   for b in range(10):
    ix=(prob>=b/10)&(prob<(b+1)/10);bins.append([int(ix.sum()),float(prob[ix].sum()),float(actual[ix].sum())])
   tops={m:[str(x).zfill(k)for x in np.lexsort((np.arange(N),-h,-v))[:3]]for m,v in zip(methods,scores)}
   retro.append(dict(date=d,station=s,digits=k,n=n,top3=tops,hits={m:int(any(actual[int(x)]for x in top))for m,top in tops.items()},brier=float(np.mean((prob-actual)**2)),uniform_brier=float(np.mean((p0-actual)**2)),bins=bins,uniform_top3=1-(1-3/N)**K,type='retrospective_not_locked'))
result=dict(lastCheck=json.loads((p/'status.json').read_text())['lastCheck'],rows=len(rows),new_complete=new,changed=changed,pending=pending,hashes=hashes,scored=scored,missing_forecasts=missingforecast,incremental_retrospective=retro,quality='all flattened counts widths duplicates schedule passed',version='daily-audit-v2; six-methods-v1; prior20 unchanged')
(p/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items()if k not in['hashes','scored','incremental_retrospective']},ensure_ascii=False));print('retro',len(retro),'actual locks',len(scored))
