import json,hashlib,datetime,collections,math
from pathlib import Path
p=Path(__file__).resolve().parent
def read(n):return json.loads((p/n).read_text())
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
rows=read('data.json');status=read('status.json');track=read('tracking.json');lock=read('locked/LOCK_1_3_5_2026-11-12.json');day='2026-11-12';by={};bad=[];duplicates=[]
for r in rows:
 key=r['date']+'|'+r['station'];nums=r['numbers'];north=r['station']=='XSMB';wanted=collections.Counter({2:4,3:3,4:10,5:10})if north else collections.Counter({2:1,3:1,4:4,5:11,6:1})
 if key in by:duplicates.append(key)
 if any(not isinstance(x,str)or not x.isdigit()for x in nums)or collections.Counter(map(len,nums))!=wanted:bad.append(key)
 else:by[key]=r
current={s:by[day+'|'+s]for s in ['Tây Ninh','An Giang','Bình Thuận','XSMB']if day+'|'+s in by};hashes={s:digest(r)for s,r in current.items()};missing=[s for s in ['Tây Ninh','An Giang','Bình Thuận','XSMB']if s not in current];scored=[]
for r in lock['records']:
 cutoff=day+('T11:00:00+00:00'if r['station']=='XSMB'else'T09:00:00+00:00')
 assert datetime.datetime.fromisoformat(lock['createdAt'].replace('Z','+00:00'))<datetime.datetime.fromisoformat(cutoff)
 complete=all(s in current for s in r['members']);sets={s:set(x[-r['digits']:]for x in current[s]['numbers']if len(x)>=r['digits'])for s in r['members']if s in current};actual=set().union(*sets.values())if complete else set();match=[x for x in r['top3']if x in actual]if complete else None
 scored.append({k:r[k]for k in ['targetDate','station','members','years','digits','method','top3']}|{'complete':complete,'matches':match,'hit':bool(match)if complete else None,'perMember':{s:[x for x in r['top3']if x in ns]for s,ns in sets.items()}if complete else None,'sameNumberBoth':[x for x in r['top3']if all(x in ns for ns in sets.values())]if complete and len(sets)==2 else None})
siteScores=[]
for t in track:
 if t['date']!=day:continue
 assert datetime.datetime.fromisoformat(t['createdAt'].replace('Z','+00:00'))<datetime.datetime.fromisoformat(day+('T11:00:00+00:00'if t['station']=='XSMB'else'T09:00:00+00:00'))
 complete=all(s in current for s in t['members'])
 for d,preds in t['predictions'].items():
  d=int(d);sets={s:set(x[-d:]for x in current[s]['numbers']if len(x)>=d)for s in t['members']if s in current};actual=set().union(*sets.values())if complete else set()
  for m,ns in preds.items():
   match=[n for n in ns if n in actual]if complete else None
   assert match==t['scores'][str(d)][m]
   siteScores.append({'station':t['station'],'digits':d,'method':m,'top3':ns,'matches':match,'hit':bool(match)if complete else None,'complete':complete,'createdAt':t['createdAt'],'version':t['version']})
descriptive={}
if all(s in current for s in ['Tây Ninh','An Giang']):
 for d in [2,3]:
  counts={s:collections.Counter(x[-d:]for x in current[s]['numbers']if len(x)>=d)for s in ['Tây Ninh','An Giang']};u=set(counts['Tây Ninh'])|set(counts['An Giang']);both=set(counts['Tây Ninh'])&set(counts['An Giang']);mb=set(x[-d:]for x in current['XSMB']['numbers']if len(x)>=d)if 'XSMB'in current else None
  descriptive[d]={'uniqueSouth':len(u),'sameNumberBoth':sorted(both),'southCounts':{s:dict(c)for s,c in counts.items()},'overlapNorth':sorted(u&mb)if mb is not None else None,'purpose':'Descriptive only; not a pre-draw MN-to-MB forecast; do not score as a prediction.'}
result={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'date':day,'lastCheck':status.get('lastCheck'),'errors':status.get('errors'),'totalRows':len(rows),'duplicates':duplicates,'badRows':bad,'dayMissing':missing,'dayComplete':not missing,'stationHashes':hashes,'stageHashes':{'MN':digest([current[s]for s in ['Tây Ninh','An Giang','Bình Thuận']])if all(s in current for s in ['Tây Ninh','An Giang','Bình Thuận'])else None,'MB':hashes.get('XSMB')},'lockedResearchScores':scored,'siteScores':siteScores,'descriptiveSouthNorth':descriptive,'newHypothesisTrials':0,'brier':'Not computed: locked forecasts contain ranks/Top3, no pre-registered per-number probability model.','conclusion':'One target date cannot establish a predictive advantage. No production changes.'}
(p/'assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:result[k]for k in ['checkedAt','lastCheck','errors','totalRows','duplicates','badRows','dayMissing','dayComplete','stageHashes']},ensure_ascii=False));print('primary',json.dumps([r for r in scored if r['station']in ['Tây Ninh + An Giang','XSMB']and r['digits']==2 and r['method']==('frequency'if r['station']=='XSMB'else'repeat')],ensure_ascii=False));print('descriptive',json.dumps(descriptive,ensure_ascii=False))
