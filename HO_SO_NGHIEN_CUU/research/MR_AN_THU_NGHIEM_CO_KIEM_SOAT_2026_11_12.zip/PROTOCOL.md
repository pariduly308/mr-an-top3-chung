# Nghiên cứu bổ sung có kiểm soát — 12/11/2026

Đăng ký trước lần chạy này, sau khi đã xem kết quả hồi cứu 1/3/5 năm. Tất cả giai đoạn 2021–2026 đã được xem ở nghiên cứu trước; không gọi giai đoạn cuối là kiểm tra tương lai độc lập. Không thay app, không sửa các bản khóa 1/3/5 năm.

## Giả thuyết và tham số cố định
1. Kết hợp gần và xa: nếu phân phối thay đổi nhẹ, trộn 50% xác suất hiện diện trong 20 kỳ gần nhất với 50% trong 5 năm có thể ổn định hơn chỉ dùng một cửa sổ. Làm trơn hai thành phần về mốc đồng đều với sức nặng tương ứng 20 kỳ và 52 kỳ MN / 365 kỳ MB. Đây là trực giác cần kiểm tra, chưa có bằng chứng thay đổi phân phối.
2. Giảm trọng số dữ liệu cũ: trung bình có trọng số mũ trên cửa sổ 5 năm, bán rã 26 kỳ của cặp MN và 180 kỳ MB, trọng số kỳ gần nhất bằng 1, prior 20 kỳ về đồng đều. Tránh cắt bỏ đột ngột khi chuyển cửa sổ. Không tối ưu bán rã sau khi thấy kết quả.
3. Phân biệt số lần trong kỳ và số kỳ xuất hiện: ước lượng tần suất theo từng giải từ 5 năm rồi chuyển thành xác suất có ít nhất một lần. Prior tương đương 52 kỳ MN / 365 kỳ MB. Công thức p=1-(1-q)^m giả định độc lập giữa giải, cần kiểm tra hiệu chỉnh; không mặc định số lặp có sức dự báo.
4. Cặp MN theo từng thành viên: ước lượng xác suất xuất hiện từng số riêng mỗi đài trong 5 năm, prior 52 kỳ về đồng đều, rồi gộp p=1-(1-pA)(1-pB). Giả định độc lập giữa đài có thể sai; so với cách gộp quan sát của app. Không áp dụng mô hình này cho MB.

Mốc xác suất: p0=1-(1-1/N)^m, N=100/1000; m bằng số giải có đủ chữ số (MN cặp36/34, từng đài18/17, MB27/23). Thêm mốc tần suất hiện diện5năm làm trơn cùng prior để chấm Brier; đây là mốc hiệu chỉnh, không coi là công thức xếp hạng mới vì làm trơn đồng đều không đổi thứ tự tần suất.

## Thiết kế
- Cặp MN: 7 cặp đã thống nhất, chấm union, đúng Top3. MB dùng riêng dữ liệu MB. Không thử nhánh MN→MB trong lần này.
- Chế độ2/3số, cùng kỳ đích10/11/2021–11/11/2026. Mọi đặc trưng dùng ngày trước đích; cửa sổ5năm, sau chấm mới cập nhật. Giữ sáu phương pháp gốc làm đối chứng xếp hạng, đủ ba cửa sổ cũ trong báo cáo trước.
- Giai đoạn phát triển:10/11/2021–09/11/2024; xác thực10/11/2024–09/11/2025; giai đoạn cuối10/11/2025–11/11/2026. Không điều chỉnh tham số qua các phần. Chỉ chọn một ứng viên mỗi miền/chế độ theo tỷ lệ Top3 trên xác thực, phá hòa bằng Brier thấp, rồi tên; ghi kết quả phần cuối của ứng viên được chọn. Phần cuối đã được xem ở nghiên cứu trước, chỉ là hồi cứu.
- 4 giả thuyết:8 tổ hợp MN và6 tổ hợp MB (2/3số),14 phép thử mới. Ghi đủ kết quả kể cả thua. Không tìm thêm biến thể sau khi chạy lần này.
- Chỉ tiêu Top3 trúng ít nhất1, Brier trung bình toàn bộ số theo từng kỳ, hiệu chỉnh10nhóm, so với đồng đều và phiên bản app (repeatMN,frequencyMB trên5năm). Brier của app xếp hạng không được tự suy ra.
- Bất định ghép cặp theo ngày, bootstrap khối7kỳ,2000lần,seed12112026. CI chỉ mô tả, chưa hiệu chỉnh14phép thử; không dùng p nhỏ lẻ để kết luận cải thiện.
- Giữ để nghiên cứu tương lai chỉ khi ứng viên được chọn theo xác thực tăng ít nhất3điểm% so app ở phần cuối, tăng ở ít nhất2/3giai đoạn, Brier không tệ hơn đồng đều, và CI chênh lệch phần cuối không chứa0. Nếu không đạt thì ghi 'chưa đủ bằng chứng', không đổi app. Ngay cả đạt cũng cần đăng ký và kiểm chứng bằng các kỳ tương lai.
- Có480vị trí lịch chưa phân loại đầy đủ ở dữ liệu10năm; mọi kết quả tạm thời, không tự lấp khoảng thiếu.
