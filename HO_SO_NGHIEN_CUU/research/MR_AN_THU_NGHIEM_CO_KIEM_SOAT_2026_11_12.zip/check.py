import csv,json,collections
from pathlib import Path
p=Path(__file__).resolve().parent
old={};stats=collections.defaultdict(lambda:[0,0])
with(p.parent/'windows_study/retrospective_predictions.csv').open()as f:
 for r in csv.DictReader(f):
  target=r['target']
  if target!='XSMB'and' + 'not in target:continue
  reg='MB'if target=='XSMB'else'MN';phase='development'if r['date']<'2024-11-10'else'validation'if r['date']<'2025-11-10'else'late_seen'
  for ph in [phase,'ALL']:
   s=stats[(reg,int(r['digits']),r['method'],int(r['years']),ph)];s[0]+=int(r['hit']);s[1]+=1
  if r['years']=='5':old[(r['date'],target,r['digits'],'old_'+r['method'])]=(r['top3'],int(r['hit']))
checked=0
with(p/'predictions.csv').open()as f:
 for r in csv.DictReader(f):
  if not r['model'].startswith('old_'):continue
  assert old[(r['date'],r['target'],r['digits'],r['model'])]==(r['top3'],int(r['hit'])),r
  checked+=1
chosen=[]
for reg in ['MN','MB']:
 for digits in [2,3]:
  candidates=[(v[0]/v[1],k[2],k[3])for k,v in stats.items()if k[0]==reg and k[1]==digits and k[4]=='validation'];best=sorted(candidates,key=lambda x:(-x[0],x[1],x[2]))[0];method,y=best[1:]
  chosen.append({'region':reg,'digits':digits,'method':method,'years':y,'selection':'validation only; contextual baseline comparison','stages':{ph:{'wins':stats[(reg,digits,method,y,ph)][0],'n':stats[(reg,digits,method,y,ph)][1],'rate':stats[(reg,digits,method,y,ph)][0]/stats[(reg,digits,method,y,ph)][1]}for ph in ['development','validation','late_seen','ALL']}})
(p/'validation_audit.json').write_text(json.dumps({'matched_old_predictions':checked,'chosen_old_baselines':chosen},ensure_ascii=False,indent=2));print(json.dumps({'matched':checked,'old_baselines':chosen},ensure_ascii=False))
