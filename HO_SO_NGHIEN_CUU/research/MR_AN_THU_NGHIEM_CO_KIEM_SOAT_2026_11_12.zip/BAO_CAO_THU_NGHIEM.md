# Thử nghiệm bổ sung trên dữ liệu 10 năm — 12/11/2026

Đây là nghiên cứu riêng; app và các bản dự báo đã khóa không thay đổi.

Đã thử 4 giả thuyết, tương ứng 14 tổ hợp miền/chế độ. Tham số và tiêu chí được ghi trước lần chạy trong PROTOCOL.md. Có 8 tổ hợp MN và 6 tổ hợp MB; phương pháp gộp riêng hai đài chỉ dành cho MN. Không phát sinh biến thể sau khi xem kết quả. Giữ đủ sáu công thức gốc làm đối chứng; mốc làm trơn tần suất không tính là công thức xếp hạng mới vì không đổi thứ tự.

Dữ liệu từ 10/11/2016–11/11/2026; đích hồi cứu từ 10/11/2021. Mỗi dự báo chỉ dùng dữ liệu trước ngày đích, lịch sử tối đa5năm. Chia theo thời gian: phát triển đến09/11/2024; xác thực10/11/2024–09/11/2025; phần cuối10/11/2025–11/11/2026. Chọn một ứng viên mỗi miền/chế độ bằng phần xác thực, rồi báo phần cuối; tất cả các phần này đã được xem ở nghiên cứu trước nên KHÔNG là kiểm chứng tương lai độc lập. Không tối ưu tham số sau kết quả.

## Ứng viên chọn bằng phần xác thực
Tỷ lệ dưới đây là Top3 có ít nhất một số xuất hiện, không là xác suất từng số. App đối chứng: repeatMN vàfrequencyMB, cùng cửa sổ5năm, cùng kỳ đích. Cả14tổ hợp đều lưu trong results.json và predictions.csv, không chỉ bốn dòng được chọn.

| Phạm vi | Ứng viên | Số kỳ toàn phần | Toàn phần mới / app | Phần cuối mới / app | Đạt tiêu chí sàng lọc? |
|---|---|---:|---:|---:|---|
| MN 2 số | Giảm trọng số dữ liệu cũ | 1828 | 66.25% / 67.83% | 68.94% / 70.57% | Chưa đạt |
| MN 3 số | Tính riêng từng đài rồi gộp | 1828 | 10.28% / 8.10% | 13.08% / 8.99% | Chưa đạt |
| MB 2 số | Kết hợp gần–xa 50/50 | 1808 | 58.74% / 54.37% | 57.30% / 54.82% | Chưa đạt |
| MB 3 số | Tần suất theo từng giải | 1808 | 7.91% / 7.85% | 8.82% / 8.54% | Chưa đạt |

## Bất định và xác suất
- MN 2 số, 367 kỳ phần cuối: chênh -1.63 điểm%, CI95% [-6.81; +3.81]; Brier ứng viên trừ đồng đều +0.00110450 (dương là kém hơn).
- MN 3 số, 367 kỳ phần cuối: chênh +4.09 điểm%, CI95% [+0.00; +8.17]; Brier ứng viên trừ đồng đều +0.00008892 (dương là kém hơn).
- MB 2 số, 363 kỳ phần cuối: chênh +2.48 điểm%, CI95% [-4.68; +9.37]; Brier ứng viên trừ đồng đều +0.00063502 (dương là kém hơn).
- MB 3 số, 363 kỳ phần cuối: chênh +0.28 điểm%, CI95% [-0.55; +1.38]; Brier ứng viên trừ đồng đều +0.00000691 (dương là kém hơn).

Khoảng bất định dùng bootstrap ghép cặp theo khối7quan sát,2.000lần. Chưa hiệu chỉnh14phép thử, nên không coi khoảng tốt của một mô hình là bằng chứng đã phát hiện lợi thế. Brier tính cho toàn bộ số nhưng lấy trung bình theo kỳ rồi mới tính bất định; không coi100/1000số là mẫu độc lập. Hiệu chỉnh10nhóm được lưu; các nhóm rộng, nhất là chế độ3số, nên không đủ một mình để kết luận xác suất đã hiệu chỉnh tốt.

Cả bốn ứng viên được chọn đều có Brier kém mốc đồng đều. Vì vậy các phần trăm xác suất nội bộ của chúng chưa đáng để đưa lên app. Làm trơn có thể giảm độ quá tự tin mà không đổi Top3; cần phân biệt cải thiện xác suất và cải thiện xếp hạng.

## Đối chiếu thêm với hệ cũ để tránh chọn đối chứng yếu
Mốc cũ dưới đây chọn từ18tổ hợp (6công thức×3cửa sổ) chỉ dựa phần xác thực, phá hòa bằng tên/cửa sổ. Đây là phân tích bổ sung theo cùng quy tắc thời gian, không chọn theo kết quả phần cuối.

| Phạm vi | Mốc cũ được chọn | Phần cuối cũ | Phần cuối ứng viên mới |
|---|---|---:|---:|
| MN 2 số | repeat, 3 năm | 66.49% | 68.94% |
| MN 3 số | repeat, 1 năm | 11.72% | 13.08% |
| MB 2 số | repeat, 3 năm | 54.27% | 57.30% |
| MB 3 số | gap, 1 năm | 4.68% | 8.82% |

## Kết luận và hạn chế
Có dấu hiệu hồi cứu đáng theo dõi ở XSMB2số (kết hợp gần–xa) và MN3số (tính từng đài rồi gộp). Chưa mô hình nào đạt toàn bộ tiêu chí đã ghi trước: cải thiện phần cuối ít nhất3điểm%, CI chênh không chứa0, tăng ở ít nhất2/3giai đoạn và Brier không kém đồng đều. Không áp dụng, không gọi là xác suất cao hơn đã được chứng minh.

Giữ kết quả thất bại của MN2số và mức chênh rất nhỏ MB3số. Hai hướng có tín hiệu chỉ được lưu để nghiên cứu tiếp; không tự thay bản khóa1/3/5năm đã lưu. Trước thử nghiệm tương lai phải cố định phiên bản và tiêu chí, lưu dự báo thực sự trước quay.

Còn480vị trí lịch ở bộ10năm chưa phân loại đầy đủ nghỉ/ngừngquay/thiếu; kết quả tạm thời. Nguồn và kiểm toán nằm trong gói10năm đã lưu. Không thêm kết quả giả. Lần kiểm tra mã này đã đối chiếu toàn bộ43.632dự báo đối chứng với nghiên cứu1/3/5năm trước: khớp Top3 và đạt/khôngđạt. Mốc đồng đều trong mã chỉ cung cấp xác suất/Brier và tỷ lệTop3 lý thuyết, không giả lập một bộ số rồi gọi là tỷ lệ ngẫu nhiên đã đo.
