import json,datetime,collections,csv,math,hashlib
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent;source=p.parent/'windows_study/research_10y_data.json';rows=json.loads(source.read_text())
pairs=[['Tiền Giang','Kiên Giang'],['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An']]
groups={}
for members in pairs+[['XSMB']]:
 by=collections.defaultdict(dict)
 for r in rows:
  if r['station']in members:by[r['date']][r['station']]=r['numbers']
 groups[' + '.join(members)]=[(d,[g[s]for s in members])for d,g in sorted(by.items())if all(s in g for s in members)]
def lower(date):
 d=datetime.date.fromisoformat(date)
 try:return d.replace(year=d.year-5).isoformat()
 except ValueError:return d.replace(year=d.year-5,month=3,day=1).isoformat()
def stage(d):return 'development'if d<'2024-11-10'else'validation'if d<'2025-11-10'else'late_seen'
records=[];cal=collections.defaultdict(lambda:np.zeros((10,3)));summary=collections.defaultdict(lambda:[0,0,0.,0.])
for station,ds in groups.items():
 north=station=='XSMB';region='MB'if north else'MN';dates=np.array([d for d,g in ds]);n=len(ds);alpha=365 if north else 52;half=180 if north else 26
 for digits in [2,3]:
  size=10**digits;nums=np.arange(size);m=(27 if digits==2 else 23)if north else(36 if digits==2 else 34);base=1-(1-1/size)**m
  cc=np.zeros((n,len(ds[0][1]),size),dtype=np.int16)
  for i,(d,gs)in enumerate(ds):
   for j,g in enumerate(gs):
    for x in g:
     if len(x)>=digits:cc[i,j,int(x[-digits:])]+=1
  count=cc.sum(axis=1);hit=count>0
  hp=np.vstack([np.zeros((1,size)),np.cumsum(hit,axis=0)]);cp=np.vstack([np.zeros((1,size)),np.cumsum(count,axis=0)]);sp=np.concatenate([np.zeros((1,cc.shape[1],size)),np.cumsum(cc>0,axis=0)],axis=0)
  weights=2.**(np.arange(n)/half);wp=np.r_[0,np.cumsum(weights)];wh=np.vstack([np.zeros((1,size)),np.cumsum(hit*weights[:,None],axis=0)]);last=np.full(size,-1)
  for i,date in enumerate(dates):
   if date>='2021-11-10':
    lo=int(np.searchsorted(dates,lower(str(date))));k=i-lo;h=hp[i]-hp[lo];recent=hp[i]-hp[max(lo,i-20)];pr=(recent+20*base)/(min(k,20)+20);long=(h+alpha*base)/(k+alpha);gap=np.where(last>=lo,i-last-1,k)
    norm=weights[i-1];ew=(wh[i]-wh[lo])/norm;ewden=(wp[i]-wp[lo])/norm
    probs={'mix50':.5*pr+.5*long,'decay':(ew+20*base)/(ewden+20),'multiplicity':1-(1-((cp[i]-cp[lo])+alpha*m/size)/(k*m+alpha*m))**m,'smooth5_baseline':long,'uniform':np.full(size,base)}
    if not north:
     single=1-(1-1/size)**(m/2);ps=(sp[i]-sp[lo]+alpha*single)/(k+alpha);probs['station_union']=1-np.prod(1-ps,axis=0)
    scores={'old_frequency':h,'old_recent10':hp[i]-hp[max(lo,i-10)],'old_recent20':recent,'old_recent50':hp[i]-hp[max(lo,i-50)],'old_gap':h*np.minimum(gap,20)/20,'old_repeat':count[i-1]}
    for name,sc in list(scores.items())+list(probs.items()):
     prob=probs.get(name);top=np.lexsort((nums,-h,-sc))[:3];win=None if name=='uniform' else int(hit[i,top].any());loss=float(np.mean((prob-hit[i])**2))if prob is not None else None
     record=dict(date=str(date),target=station,region=region,digits=digits,model=name,stage=stage(date),top3='' if name=='uniform' else ' '.join(str(x).zfill(digits)for x in top),hit=win,brier=loss,uniformTop3=1-(1-3/size)**m)
     records.append(record)
     for phase in [stage(date),'ALL']:
      a=summary[(region,digits,name,phase)];a[0]+=win or 0;a[1]+=1;a[2]+=loss or 0;a[3]+=int(loss is not None)
      if prob is not None:
       ix=np.minimum((prob*10).astype(int),9);bins=cal[(region,digits,name,phase)];bins[:,0]+=np.bincount(ix,minlength=10);bins[:,1]+=np.bincount(ix,weights=prob,minlength=10);bins[:,2]+=np.bincount(ix,weights=hit[i].astype(int),minlength=10)
   last[hit[i]]=i
 print('finished',station,flush=True)
with(p/'predictions.csv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=records[0].keys());w.writeheader();w.writerows(records)
ss=[dict(region=k[0],digits=k[1],model=k[2],stage=k[3],wins=v[0],n=v[1],rate=None if k[2]=='uniform' else v[0]/v[1],brier=v[2]/v[3]if v[3]else None)for k,v in summary.items()]
cs=[dict(region=k[0],digits=k[1],model=k[2],stage=k[3],bins=[dict(n=int(v[0]),predicted=float(v[1]/v[0])if v[0]else None,observed=float(v[2]/v[0])if v[0]else None)for v in arr])for k,arr in cal.items()]
rng=np.random.default_rng(12112026)
def ci(delta):
 delta=np.array(delta);n=len(delta);boots=[]
 for _ in range(2000):
  starts=rng.integers(0,n,size=math.ceil(n/7));ix=((starts[:,None]+np.arange(7))%n).ravel()[:n];boots.append(delta[ix].mean())
 return [float(x)for x in np.quantile(boots,[.025,.975])]
selected=[]
for region in ['MN','MB']:
 for digits in [2,3]:
  candidates=['mix50','decay','multiplicity']+(['station_union']if region=='MN'else[]);baseline='old_repeat'if region=='MN'else'old_frequency'
  v=[x for x in ss if x['region']==region and x['digits']==digits and x['stage']=='validation'and x['model']in candidates];best=sorted(v,key=lambda x:(-x['rate'],x['brier'],x['model']))[0]['model'];comparisons=[]
  for phase in ['development','validation','late_seen','ALL']:
   rr=[x for x in records if x['region']==region and x['digits']==digits and(phase=='ALL'or x['stage']==phase)];by=collections.defaultdict(dict)
   for x in rr:by[(x['date'],x['target'])][x['model']]=x
   by=[v for k,v in sorted(by.items())];delta=[v[best]['hit']-v[baseline]['hit']for v in by];bdelta=[v[best]['brier']-v['uniform']['brier']for v in by]
   comparisons.append(dict(stage=phase,n=len(by),rate=float(np.mean([v[best]['hit']for v in by])),app_rate=float(np.mean([v[baseline]['hit']for v in by])),difference=float(np.mean(delta)),difference95=ci(delta),brier_difference_uniform=float(np.mean(bdelta)),brier_difference95=ci(bdelta),uniform_top3=by[0][best]['uniformTop3']))
  late=next(c for c in comparisons if c['stage']=='late_seen');passes=late['difference']>=.03 and late['difference95'][0]>0 and late['brier_difference_uniform']<=0 and sum(c['difference']>0 for c in comparisons if c['stage']!='ALL')>=2
  selected.append(dict(region=region,digits=digits,selected_on_validation=best,comparisons=comparisons,passes_provisional_screen=passes))
result={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHash':hashlib.sha256(source.read_bytes()).hexdigest(),'protocolHash':hashlib.sha256((p/'PROTOCOL.md').read_bytes()).hexdigest(),'new_trial_configurations':14,'status':'retrospective_all_targets_previously_seen_quality_gaps_unverified','summary':ss,'calibration':cs,'selection':selected}
(p/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(selected,ensure_ascii=False),flush=True)
