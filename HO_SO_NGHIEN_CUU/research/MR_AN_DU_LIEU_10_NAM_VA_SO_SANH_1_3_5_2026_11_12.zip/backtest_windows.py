import json,csv,datetime,collections,math
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent;rows=json.loads((p/'research_10y_data.json').read_text());audit=json.loads((p/'quality_audit.json').read_text())
if audit['finishedPages']!=522 or audit['conflicts']:raise SystemExit('Archive incomplete or conflicts; stop backtest')
pairs=[['Tiền Giang','Kiên Giang'],['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An']]
groups=collections.defaultdict(list)
for r in rows:groups[r['station']].append(r)
for pair in pairs:
 by=collections.defaultdict(dict)
 for r in rows:
  if r['station'] in pair:by[r['date']][r['station']]=r['numbers']
 name=' + '.join(pair)
 groups[name]=[{'date':d,'station':name,'numbers':sum([g[s] for s in pair],[])} for d,g in sorted(by.items()) if all(s in g for s in pair)]
methods=['frequency','recent10','recent20','recent50','gap','repeat'];summ=collections.defaultdict(lambda:[0,0]);primary={};out=p/'retrospective_predictions.csv'
def lower(date,y):
 d=datetime.date.fromisoformat(date)
 try:return d.replace(year=d.year-y).isoformat()
 except ValueError:return d.replace(year=d.year-y,month=3,day=1).isoformat()
with out.open('w') as f:
 w=csv.writer(f);w.writerow(['date','target','digits','method','years','training_draws','top3','hit'])
 for station,ds in groups.items():
  ds.sort(key=lambda r:r['date']);dates=np.array([r['date'] for r in ds]);n=len(ds)
  for digits in [2,3]:
   size=10**digits;nums=np.arange(size);count=np.zeros((n,size),dtype=np.int16)
   for i,r in enumerate(ds):
    for x in r['numbers']:
     if len(x)>=digits:count[i,int(x[-digits:])]+=1
   hits=count>0;prefix=np.vstack([np.zeros((1,size),dtype=np.int32),np.cumsum(hits,axis=0,dtype=np.int32)]);last=np.full(size,-1,dtype=np.int32)
   for i,date in enumerate(dates):
    if date>='2021-11-10':
     actual=hits[i];records={}
     for y in [1,3,5]:
      lo=int(np.searchsorted(dates,lower(str(date),y)));h=prefix[i]-prefix[lo];gap=np.where(last>=lo,i-last-1,i-lo)
      scores=[h,*[prefix[i]-prefix[max(lo,i-k)] for k in [10,20,50]],h*np.minimum(gap,20)/20,count[i-1]]
      for method,sc in zip(methods,scores):
       top=np.lexsort((nums,-h,-sc))[:3];hit=int(actual[top].any());w.writerow([date,station,digits,method,y,i-lo,' '.join(str(x).zfill(digits) for x in top),hit])
       for yr in [str(date)[:4],'ALL']:
        a=summ[(station,digits,method,y,yr)];a[0]+=hit;a[1]+=1
       if digits==2 and ((' + 'in station and method=='repeat') or(station=='XSMB'and method=='frequency')):records[y]=hit
     if records:primary[(str(date),station)]=records
    last[hits[i]]=i
  print('done',station,n,flush=True)
summary=[]
for (station,digits,method,years,year),(wins,n) in sorted(summ.items()):
 z=1.96;ph=wins/n;den=1+z*z/n;center=(ph+z*z/(2*n))/den;half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
 summary.append(dict(target=station,digits=digits,method=method,years=years,year=year,wins=wins,n=n,rate=ph,wilson95=[max(0,center-half),min(1,center+half)]))
comp=[];rng=np.random.default_rng(1352026)
for region in ['pair_south','north']:
 a=[v for (d,s),v in sorted(primary.items()) if (s=='XSMB')==(region=='north')];n=len(a)
 for y in [1,3]:
  delta=np.array([v[y]-v[5] for v in a]);boots=[]
  for _ in range(2000):
   starts=rng.integers(0,n,size=math.ceil(n/7));ix=((starts[:,None]+np.arange(7))%n).ravel()[:n];boots.append(float(delta[ix].mean()))
  comp.append(dict(region=region,comparison=f'{y} vs5',n=n,rate_short=float(np.mean([v[y] for v in a])),rate_5=float(np.mean([v[5] for v in a])),difference=float(delta.mean()),block7_bootstrap95=np.quantile(boots,[.025,.975]).tolist()))
report={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'type':'retrospective_already_seen_targets_not_future_validation','parameters':{'windows':[1,3,5],'target_start':'2021-11-10','target_end':'2026-11-11','method_selection':'none;all six fixed formulas','bootstrap':'paired circular 7-observation blocks,2000 replicates,seed1352026;descriptive CI,no multiplicity-adjusted claim'},'quality_note':'Missing observations under current schedule are not imputed; historical schedule/pauses require verification; results provisional.', 'primary_comparisons':comp,'summary':summary}
(p/'retrospective_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(comp,ensure_ascii=False),flush=True)
