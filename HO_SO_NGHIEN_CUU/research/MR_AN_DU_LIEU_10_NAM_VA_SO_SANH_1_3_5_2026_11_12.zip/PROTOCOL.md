# Thí nghiệm cửa sổ 1–3–5 năm — window-study-v1
Định trước ngày 12/11/2026. Chỉ nghiên cứu; không sửa cách tính app.

Cửa sổ theo năm lịch [ngày đích trừ 1/3/5 năm, ngày đích), tính bằng UTC date; 29/2 theo quy tắc Date.setUTCFullYear. Giữ nguyên rank() và sáu công thức cùng quy tắc hòa điểm của app. Cùng một kỳ đích, cùng Top 3 và số giải. Cặp miền Nam cần đủ cả hai đài; đích từng đài và XSMB báo riêng. Dữ liệu thiếu phải ghi, không tự lấp. 3 số bỏ giải chỉ có 2 chữ số.

Khóa trước 16h miền Nam và 18h miền Bắc giờ Việt Nam, dữ liệu đầu vào chỉ trước ngày đích. Mỗi bản ghi có timestamp, hash dữ liệu, hash thuật toán, số kỳ từng cửa sổ. Không ghi đè; nếu hết giờ thì bỏ kỳ khỏi dự báo thực tế. Không nhập kết quả chiều vào thí nghiệm độ dài lịch sử XSMB; nhánh MN→MB là nghiên cứu khác.

Chỉ tiêu chính: Top 3 có ít nhất một số xuất hiện. Miền Nam cặp: một trong hai đài là đạt. Phương pháp chính định trước: repeat cho cặp miền Nam, frequency cho XSMB, chế độ 2 số. Đối chiếu 1 vs5 và3 vs5 cho hai đích chính, bốn so sánh; hiệu chỉnh Holm ở alpha0,05 khi kiểm định chính thức. Sáu công thức ×2/3số ×3cửa sổ đều báo cáo, không chọn kết quả thắng rồi gọi là thử nghiệm chính. Từng đài và3số là phân tích phụ.

Theo dõi tích lũy, báo số kỳ và CI chênh lệch ghép cặp theo ngày; không coi các số cùng ngày là mẫu độc lập. Kiểm tra vận hành sau30ngày, đánh giá mô tả sau90ngày, đánh giá chính thức định trước sau365ngày hoàn tất (nếu thiếu giữ nguyên ngày mục tiêu, báo số mẫu thực tế). Không dừng sớm vì kết quả đẹp. Mức cải thiện đáng quan tâm định trước là +3 điểm phần trăm trên chỉ tiêu chính, cần bất định hỗ trợ và không chỉ do một giai đoạn/cặp đài. Mốc365ngày không bảo đảm đủ lực kiểm định cho chênh nhỏ, cần tiếp tục nếu chưa rõ.

Điểm xếp hạng không là xác suất. Phiên bản này khóa Top3 và thống kê đầu vào, chưa định nghĩa mô hình xác suất riêng nên không báo Brier giả; việc so Brier cần đăng ký mô hình xác suất và khóa toàn bộ xác suất trước kỳ mới trong phiên bản riêng.

Dữ liệu cũ: mục tiêu thêm 10/11/2016–09/11/2021. Dùng2016–2021làm khởi tạo, cùng kỳ đích2021–2026so1/3/5năm. Toàn bộ kết quả là hồi cứu, không thay dữ liệu tương lai. Báo từng năm/từng cặp/từng đài, số kỳ đủ/thiếu, thay đổi lịch/ngày nghỉ và bất định; không mặc định lịch hiện tại đúng cho10năm.

Gói LOCK chứa bản khóa thật ngày12/11/2026 lúc13:32giờVN, mã tạo, công thức và dữ liệu đầu vào để tái lập. Mọi lượt tương lai tạo gói mới theo ngày, chỉ chấm sau kết quả, liên kết nhật ký. File khóa không sửa.
