const stationDays=[['Tiền Giang','Kiên Giang','Đà Lạt'],['TP. HCM','Đồng Tháp','Cà Mau'],['Bến Tre','Vũng Tàu','Bạc Liêu'],['Đồng Nai','Cần Thơ','Sóc Trăng'],['Tây Ninh','An Giang','Bình Thuận'],['Vĩnh Long','Bình Dương','Trà Vinh'],['TP. HCM','Long An','Bình Phước','Hậu Giang']];
function stationsOn(date){return [...stationDays[new Date(date+'T12:00:00Z').getUTCDay()],'XSMB'];}
async function readObjects(bucket,prefix){
 const values=[];let cursor;
 do{const page=await bucket.list({prefix,cursor});for(const object of page.objects){const value=await bucket.get(object.key);if(value)values.push(await value.json());}cursor=page.truncated?page.cursor:undefined;}while(cursor);
 return values;
}
async function allDraws(bucket,seed){
 const rows=new Map(seed.map(r=>[r.station+'|'+r.date,r]));
 for(const batch of await readObjects(bucket,'draws/'))for(const row of batch)rows.set(row.station+'|'+row.date,row);
 return [...rows.values()].sort((a,b)=>a.date.localeCompare(b.date)||a.station.localeCompare(b.station));
}
const pairDays=[['Tiền Giang','Kiên Giang'],['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An']];
function pairHistory(draws,pair){const by=new Map();for(const r of draws){if(!pair.includes(r.station))continue;if(!by.has(r.date))by.set(r.date,{});by.get(r.date)[r.station]=r.numbers;}return [...by].filter(([d,g])=>pair.every(s=>g[s])).map(([date,g])=>({date,station:pair.join(' + '),numbers:pair.flatMap(s=>g[s])})).sort((a,b)=>a.date.localeCompare(b.date));}
const northHolidays=[{"tu": "2022-01-31", "den": "2022-02-03", "nguon": "https://www.minhngoc.net.vn/ket-qua-xo-so/mien-bac/04-02-2022.html"}, {"tu": "2023-01-21", "den": "2023-01-24", "nguon": "https://www.minhngoc.net.vn/ket-qua-xo-so/mien-bac/25-01-2023.html"}, {"tu": "2024-02-09", "den": "2024-02-12", "nguon": "https://www.minhngoc.net.vn/ket-qua-xo-so/mien-bac/13-02-2024.html"}, {"tu": "2025-01-28", "den": "2025-01-31", "nguon": "https://www.minhngoc.net.vn/ket-qua-xo-so/mien-bac/01-02-2025.html"}, {"tu": "2026-02-16", "den": "2026-02-19", "nguon": "https://www.minhngoc.net.vn/ket-qua-xo-so/mien-bac/20-02-2026.html"}];
function isNorthHoliday(day){return northHolidays.some(h=>h.tu<=day&&day<=h.den);}
function previousDue(station,day){let d=new Date(day+'T12:00:00Z');do{d.setUTCDate(d.getUTCDate()-1);}while(station==='XSMB'?isNorthHoliday(d.toISOString().slice(0,10)):!stationDays[d.getUTCDay()].includes(station));return d.toISOString().slice(0,10);}
async function captureForecasts(bucket,draws,now=new Date()){
 const date=now.toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}),hour=Number(now.toLocaleTimeString('en-GB',{timeZone:'Asia/Ho_Chi_Minh',hour:'2-digit',hour12:false})),weekday=new Date(date+'T12:00:00Z').getUTCDay();const saved=[];
 for(const members of [pairDays[weekday],...(isNorthHoliday(date)?[]:[['XSMB']])]){
  const station=members.join(' + '),north=station==='XSMB';
  if(hour>=(north?18:16)||draws.some(r=>r.date===date&&members.includes(r.station)))continue;
  if(members.some(s=>!draws.some(r=>r.station===s&&r.date===previousDue(s,date))))continue;
  const key='forecasts/'+date+'/'+encodeURIComponent(station)+'.json';if(await bucket.get(key))continue;
  const history=(north?draws.filter(r=>r.station==='XSMB'):pairHistory(draws,members)).filter(r=>r.date<date);if(history.length<30)continue;
  const predictions={};for(const d of [2,3]){const ranked=rank(history,d);predictions[d]=Object.fromEntries(Object.keys(methods).map(m=>[m,[...ranked].sort((a,b)=>score(b,m)-score(a,m)||b.hits-a.hits||a.number.localeCompare(b.number)).slice(0,3).map(r=>r.number)]));}
  const s={date,station,members,createdAt:now.toISOString(),historyThrough:history.at(-1).date,historyCount:history.length,version:north?'six-methods-v1':'pair-six-v1',predictions};
  if(await bucket.put(key,JSON.stringify(s),{onlyIf:{etagDoesNotMatch:'*'}}))saved.push(station);
 }
 return saved;
}
async function trackingReport(bucket,draws){return (await readObjects(bucket,'forecasts/')).sort((a,b)=>b.date.localeCompare(a.date)).map(s=>{
 const actual=s.members.map(station=>draws.find(r=>r.date===s.date&&r.station===station));const complete=actual.every(Boolean),scores={};
 for(const d of [2,3]){const tails=new Set(complete?actual.flatMap(r=>r.numbers).filter(n=>n.length>=d).map(n=>n.slice(-d)):[]);scores[d]=Object.fromEntries(Object.entries(s.predictions[d]).map(([m,ns])=>[m,complete?ns.filter(n=>tails.has(n)):null]));}
 return {...s,complete,scores};});}

export function parse(html,region){
 const result=[];const shapes=region==='mien-bac'?{giai7:[4,2],giai6:[3,3],giai5:[6,4],giai4:[4,4],giai3:[6,5],giai2:[2,5],giai1:[1,5],giaidb:[1,5]}:{giai8:[1,2],giai7:[1,3],giai6:[3,4],giai5:[1,4],giai4:[7,5],giai3:[2,5],giai2:[1,5],giai1:[1,5],giaidb:[1,6]};
 for(const block of html.split('<div class="box_kqxs">').slice(1)){
  const match=block.match(new RegExp('class="title"[\\s\\S]*?/('+region+')/(\\d{2})-(\\d{2})-(\\d{4})\\.html'));if(!match)continue;
  const date=`${match[4]}-${match[3]}-${match[2]}`,dt=new Date(date+'T12:00:00Z');if(!Number.isFinite(+dt)||dt.toISOString().slice(0,10)!==date)continue;
  const tables=region==='mien-nam'?[...block.matchAll(/<table[^>]*class="rightcl"[^>]*>([\s\S]*?)<\/table>/g)].map(m=>m[1]):[block];
  for(const table of tables){
   const station=region==='mien-bac'?'XSMB':table.match(/class="tinh"[^>]*>\s*<a[^>]*>(.*?)<\/a>/s)?.[1].trim();if(!station||(station!=='XSMB'&&!stationDays.flat().includes(station)))continue;
   const prizes={};let bad=false;
   for(const cell of table.matchAll(/<td class="(giai[1-8]|giaidb)"[^>]*>([\s\S]*?)<\/td>/g)){
    if(!shapes[cell[1]]||prizes[cell[1]]){bad=true;break;}
    const ns=[...cell[2].matchAll(/<div[^>]*>\s*(\d{2,6})\s*<\/div>/g)].map(x=>x[1]),[count,width]=shapes[cell[1]];
    if(ns.length!==count||ns.some(n=>n.length!==width)){bad=true;break;}prizes[cell[1]]=ns;
   }
   if(!bad&&Object.keys(shapes).every(k=>prizes[k]))result.push({date,station,numbers:Object.keys(shapes).flatMap(k=>prizes[k])});
  }
 }
 return result;
}
async function fetchResults(url){let error;for(let i=0;i<2;i++){try{const r=await fetch(url,{signal:AbortSignal.timeout(25000)});if(!r.ok)throw Error('HTTP '+r.status);return await r.text();}catch(e){error=e;}}throw error;}
const json=value=>Response.json(value,{headers:{'Cache-Control':'no-store'}});
export function createService(page,seed,evaluation){return {async fetch(request,env){
 const path=new URL(request.url).pathname;
 if(request.method==='POST'&&request.headers.get('Origin')&&request.headers.get('Origin')!==new URL(request.url).origin)return new Response('Forbidden',{status:403});
 if(path==='/')return new Response(page,{headers:{'Content-Type':'text/html;charset=utf-8','Cache-Control':'no-cache'}});
 if(path==='/analysis-worker.js')return new Response(analysisWorkerSource,{headers:{'Content-Type':'text/javascript;charset=utf-8','Cache-Control':'no-cache'}});
 if(path==='/evaluation.json')return json(evaluation);
 if(path==='/api/status'){const obj=await env.BUCKET.get('status.json');return json(obj?await obj.json():{lastCheck:null});}
 if(path==='/data.json')return json(await allDraws(env.BUCKET,seed));
 if(path==='/api/tracking')return json(await trackingReport(env.BUCKET,await allDraws(env.BUCKET,seed)));
 if(path==='/api/forecast'&&request.method==='POST')return json({saved:await captureForecasts(env.BUCKET,await allDraws(env.BUCKET,seed))});
 if(path==='/api/update'&&request.method==='POST'){
  // The Site remains owner-private. Sites dispatch authenticates visitors and service callers.
  const now=new Date(),today=now.toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}),parts=today.split('-');
  const status={lastCheck:now.toISOString(),draws:0,errors:[],latestDate:null};
  for(const region of ['mien-nam','mien-bac']){
   try{
    const rows=parse(await fetchResults(`https://www.minhngoc.net.vn/ket-qua-xo-so/${region}/${[...parts].reverse().join('-')}.html`),region).filter(r=>r.date<=today);
    if(!rows.length)throw new Error('Chưa có bảng đủ giải');
    const byDate=new Map();for(const row of rows){if(!byDate.has(row.date))byDate.set(row.date,[]);byDate.get(row.date).push(row);}
    for(const [date,values] of byDate){
     const key=`draws/${region}-${date}.json`,old=await env.BUCKET.get(key);
     const merged=new Map((old?await old.json():[]).map(r=>[r.station,r]));
     values.forEach(r=>merged.set(r.station,r));
     await env.BUCKET.put(key,JSON.stringify([...merged.values()]));
    }
    status.draws+=rows.length;status.latestDate=[status.latestDate,...rows.map(r=>r.date)].filter(Boolean).sort().at(-1);
   }catch(e){status.errors.push(region+': '+e.message);}
  }
  try{status.forecastsSaved=await captureForecasts(env.BUCKET,await allDraws(env.BUCKET,seed));}catch(e){status.errors.push('Lưu dự báo: '+e.message);}
  const current=await allDraws(env.BUCKET,seed);status.pending=stationsOn(today).filter(s=>!(s==='XSMB'&&isNorthHoliday(today))&&!current.some(r=>r.station===s&&r.date===today));status.message=status.pending.length?'Đang chờ bảng đủ giải của ngày hôm nay.':'Đã đủ bảng của ngày hôm nay.';
  await env.BUCKET.put('status.json',JSON.stringify(status));return json(status);
 }
 return new Response('Not found',{status:404});
}}}
