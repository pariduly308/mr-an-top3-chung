# XSMB tổng lượt 50 kỳ — mb-total50-v1
Cố định trước kỳ 13/11/2026. Nghiên cứu riêng, không sửa sản phẩm hay bản khóa khác.

Lý do: hồi cứu đã xem cho tổng50 đạt57,91% so frequency1năm57,08% và5năm54,37%; 48 tổ hợp đã thử, ứng viên không thắng phần xác thực. Đây là lựa chọn sau xem dữ liệu, chỉ là tín hiệu thăm dò. Bắt đầu xác nhận tương lai mới từ bản khóa này; không cộng hồi cứu vào thành tích tương lai.

Công thức: XSMB 2 số, toàn27 giải. Lấy đúng50 kỳ đầy đủ trước ngày đích, đếm mọi lượt xuất hiện đuôi00–99; xếp tổng lượt giảm, hòa thì số kỳ hiện diện giảm, rồi số tăng. Chọn đúng3 số khác nhau. Giữ số0 đầu. Không đổi cửa sổ hoặc tham số khi có kết quả mới.

Đối chứng chính: frequency1năm vàfrequency5năm, đếm số kỳ có xuất hiện, hòa chọn số tăng; cửa sổ năm lịch [đích trừY năm, đích). Phụ: frequency3năm vàpresence50. Khóa đồng thời tất cả trước18hVN, với timestamp/hash/mốc dữ liệu/số kỳ. Lưu thành tệp mới bất biến; không có lưu trước quay thì không tính dự báo thật. Không tạo lại dự báo sau thấy kết quả.

Chỉ tiêu chính: Top3 có ít nhất1số ra. Phụ: số số chọn trúng khác nhau0–3, không tính một số lặp nhiều lần thành nhiều số đúng. So sánh ghép cặp trên cùng ngày đủ kết quả và bản khóa. Mốc đồng đều: 1-C(100-U,3)/C(100,3), U là số đuôi khác nhau thực tế trong27giải; đây là kỳ vọng chọn ngẫu nhiên, không phải dự báo đã khóa. Điểm hạng không là xác suất; Brier/hiệu chỉnh N/A.

Đánh giá mô tả sau90 kỳ đủ điều kiện, đánh giá chính thức365 kỳ đủ điều kiện, không dừng sớm vì đẹp. Hai kiểm định McNemar exact hai phía tổng50 vsfrequency1/5, Holm alpha0,05. Báo CI95 chênh ghép cặp bootstrap theo ngày10000lần seed1350; thêm độ nhạy block7ngày vì cửa sổ chồng lấp. Mức cải thiện thực tế định trước+3điểm% trên cả hai đối chứng, CI dưới>0 và Holm đạt, không thấp mốc đồng đều, không chỉ do một giai đoạn. Đủ điều kiện chỉ đề xuất người dùng xem xét, không tự áp dụng. Không đạt: kết luận chưa có bằng chứng, không tự tái tối ưu;365kỳ không bảo đảm đủ lực thống kê.

Kiểm tra đủ27giải và phân bố độ dài2:4,3:3,4:10,5:10; không trùng ngày; kỳ gần nhất phải có, khoảng thiếu phải phân loại bằng chứng. Không tự lấp. Lưu các hạn chế lịch sử và số kỳ từng cửa sổ. Nếu khoảng thiếu gần đây chưa giải quyết thì chờ, không khóa. Dữ liệu sửa: giữ bản dự báo, tạo phiên bản chấm lại kèmhash; không thay snapshot gốc.

Tích lũy tất cả đúng/sai/chờ/không có dự báo. Không coi100số trong một kỳ độc lập. Không reset bộ đếm nghiên cứu: đây là xác nhận tương lai của một trong48tổ hợp đã thử, không phải phát hiện độc lập mới. Giữ nguyên nghiên cứu1/3/5năm và hai mốcMN/MB. Nhánh này chỉ XSMB, không dùng MN làm đặc trưng. Thông báo khi lỗi cần xử lý hoặc bằng chứng đáng chú ý; ngày bình thường lưu nhật ký.
