import json,hashlib,sys,datetime,collections,pathlib
from zoneinfo import ZoneInfo
p=pathlib.Path(__file__).parent
src=pathlib.Path(sys.argv[1]); target=datetime.date.fromisoformat(sys.argv[2]);now=datetime.datetime.now(ZoneInfo('Asia/Ho_Chi_Minh'))
assert now.date()==target and now.hour<18, 'Must lock on target day before 18h VN'
rows=sorted([x for x in json.loads(src.read_text()) if x['station']=='XSMB' and x['date']<str(target)],key=lambda x:x['date'])
assert len({x['date'] for x in rows})==len(rows)
for r in rows:
 assert collections.Counter(map(len,r['numbers']))=={2:4,3:3,4:10,5:10}
 assert all(isinstance(n,str) and n.isascii() and n.isdigit() for n in r['numbers'])
assert rows[-1]['date']==str(target-datetime.timedelta(days=1))
recent=rows[-50:];assert len(recent)==50
assert (datetime.date.fromisoformat(recent[-1]['date'])-datetime.date.fromisoformat(recent[0]['date'])).days==49,'Unverified gap in last50'
def rank(rs,total=False):
 c=collections.Counter(n[-2:] for r in rs for n in r['numbers']);h=collections.Counter(n for r in rs for n in set(s[-2:] for s in r['numbers']))
 return sorted([f'{i:02}' for i in range(100)],key=lambda n:(-c[n],-h[n],n) if total else (-h[n],n))[:3]
sets={'total50':recent,'presence50':recent}
for y in [1,3,5]:
 start=target.replace(year=target.year-y);sets['frequency'+str(y)+'y']=[r for r in rows if r['date']>=str(start)]
obj={'version':'mb-total50-v1','target_date':str(target),'created_at':now.isoformat(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'formula_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'predictions':{k:{'top3':rank(v,k=='total50'),'n':len(v),'first':v[0]['date'],'last':v[-1]['date']} for k,v in sets.items()},'limitations':['Historical calendar gaps outside last50 remain unclassified; do not assume holidays.'],'status':'unscored; durable save required before18h'}
path=p/('LOCK_'+str(target)+'.json')
with path.open('x') as f:json.dump(obj,f,ensure_ascii=False,indent=2)
(p/'input_mb.json').write_text(json.dumps(rows,ensure_ascii=False))
print(json.dumps(obj,ensure_ascii=False,indent=2))
