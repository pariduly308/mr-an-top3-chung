import json
from pathlib import Path
R=Path(__file__).resolve().parent
a=json.loads((R/'audit.json').read_text());res=json.loads((R/'results.json').read_text());v=json.loads((R/'verification.json').read_text());sp=json.loads((R/'source_spotchecks.json').read_text())
labels={'frequency':'Tần suất toàn lịch sử','recent10':'10 kỳ gần nhất','recent20':'20 kỳ gần nhất','recent50':'50 kỳ gần nhất','gap':'Tần suất × độ vắng (chặn ở 20 kỳ)','repeat':'Số lần ra kỳ liền trước','afternoon_count':'Số lần ra trong hai đài buổi chiều'}
phases={'morning':'Trước quay: học từ các số ra ở ít nhất một đài','morning_joint':'Trước quay: học riêng các số cùng ra ở cả hai đài','evening':'Chiều → Bắc: chỉ chọn trong giao hai đài','evening_union':'Đối chứng chiều → Bắc: chọn trong hợp hai đài, cùng số lượng'}
pct=lambda x:f'{100*x:.2f}%'
lines=['# Nghiên cứu cặp đài miền Nam và lặp lại XSMB — 11/11/2026',
'**Chỉ nghiên cứu. Chưa sửa app, website, lịch tự động, quyền truy cập hay thuật toán đang dùng.**',
'## Kết luận',
'Chưa đủ bằng chứng để đổi hướng áp dụng. Hai cách chọn Top 3 trước quay được chọn ở giai đoạn phát triển đều đạt cùng số xuất hiện ở cả hai đài 36/365 ngày (9,86%) cho đuôi 2 số ở giai đoạn sau; mức đối chứng chọn ngẫu nhiên cùng ba số là 7,82%. Khoảng bất định của chênh lệch vẫn chứa 0. Không được đọc 9,86% thành xác suất chắc chắn cho kỳ tới.',
'Với XSMB tối cùng ngày, ưu tiên “tần suất × độ vắng” trong nhóm số trùng hai đài được chọn từ giai đoạn trước nhưng chỉ đạt 159/346 ngày có lựa chọn (45,95%) ở năm sau. Đối chứng chọn ngẫu nhiên cùng số lượng ngay trong nhóm trùng là 47,21%. Chưa thấy lợi ích dự báo đáng tin cậy.',
'## Dữ liệu và kiểm tra',
f'- {a["rows"]:,} bảng đã lưu; từ {a["start"]} đến {a["end"]}; {a["days"]:,} ngày. Dùng tất cả các giải, giữ số 0 đầu. Đuôi 3 số chỉ lấy giải có ít nhất 3 chữ số, không thêm 0 vào giải 2 số.',
'- Kiểm tra toàn bộ bảng: không có khóa đài/ngày trùng, sai độ dài/số lượng giải, sai lịch đài hoặc thiếu cặp đài nghiên cứu. Có 20 ngày không có bảng XSMB trong kho (liệt kê audit.json); bỏ qua khi chấm buổi tối, không điền số. Trong bốn năm chấm có 16 ngày như vậy.',
f'- Đối chiếu trực tiếp 12 trang Minh Ngọc, trải sáu mốc năm: {sum(x["multiset_matched"] for x in sp)}/24 bảng khớp toàn bộ các số và số lần lặp. XSMB lưu thứ tự hạng giải ngược với bộ đọc hiện tại; tập số có lặp vẫn khớp, không ảnh hưởng thống kê đuôi tất cả giải. Đây là kiểm tra mẫu, không phải tái tải xác minh từng bảng của 5 năm.',
f'- Kiểm tra độc lập {v["independent_rank_replays"]} lượt xếp hạng bằng cách tính lại toàn bộ lịch sử; kiểm tra kết quả và điều kiện chọn của {v["all_outcomes_checked"]:,} bản ghi thử nghiệm: đều khớp. Các bản ghi này là nhiều công thức trên cùng ngày, không phải từng ấy mẫu độc lập.',
f'- SHA256 dữ liệu: `{a["sha256"]}`.',
'## Cặp đài cố định',
'| Ngày | Hai đài giữ lại |','|---|---|']
for day,pair in zip(['Thứ hai','Thứ ba','Thứ tư','Thứ năm','Thứ sáu','Thứ bảy','Chủ nhật'],a['pairs']):lines.append(f'| {day} | {" + ".join(pair)} |')
lines += ['\n## Cách thử và chống nhìn trước kết quả',
'- Năm đầu 10/11/2021–09/11/2022 làm lịch sử ban đầu. Chấm cuốn chiếu 1.461 ngày tiếp theo: mỗi dự báo chỉ dùng dữ liệu đã có trước thời điểm dự báo.',
'- Giai đoạn phát triển 10/11/2022–09/11/2025 chọn cách ưu tiên; giai đoạn sau 10/11/2025–09/11/2026 dùng để so kết quả. Bộ dữ liệu này đã được dùng nghiên cứu trước đây, nên đây vẫn là hồi cứu mang tính khám phá, không phải kiểm định tương lai hoàn toàn mới.',
'- Hai biến thể trước quay đều có một Top 3 chung cho cặp đài, học riêng lịch sử của cặp đó. Biến thể thứ nhất đếm các số xuất hiện ở ít nhất một đài; biến thể thứ hai chỉ học số cùng xuất hiện ở cả hai. Thành công chính: tồn tại cùng một số trong Top 3 ra ở cả hai đài. Hai số khác nhau mỗi số trúng một đài không đủ điều kiện.',
'- Buổi tối chỉ dùng hai bảng miền Nam đã đủ giải và lịch sử XSMB trước ngày đang xét. Nhóm giao là số thực sự ra ở cả hai đài. Nếu có dưới 3 số, chỉ chọn số lượng hiện có; nhóm rỗng thì không dự báo. Không tự bù số để đủ Top 3.',
'- Thử 6 cách đã có: toàn lịch sử, 10/20/50 kỳ gần, tần suất × độ vắng, lần ra kỳ trước. Buổi tối thử thêm số lần ra trong hai đài chiều. Phá hòa bằng tần suất lịch sử, sau đó số nhỏ hơn. Không đảo số, cộng nút hoặc tìm quy tắc tùy ý sau khi xem kết quả.',
'- Đối chứng cùng ngày, cùng số lượng: chọn ngẫu nhiên trong 00–99 hoặc 000–999; chọn ngẫu nhiên ngay trong nhóm ứng viên; lấy Top theo tần suất XSMB không giới hạn nhóm; và chọn trong hợp hai đài. Đối chứng hợp hai đài chỉ chấm vào ngày nhóm giao không rỗng và chọn đúng bằng số lượng của nhóm giao. Đây không phải thử tất cả số buổi chiều.',
'- Mức ngẫu nhiên tính chính xác theo tổ hợp trên tập số thực tế mỗi ngày, không cần giả sử các giải độc lập. Khoảng chênh lệch lấy mẫu lại theo tuần lịch, 10.000 lần; chỉ tham khảo, có thêm hiệu chỉnh 52 tổ hợp phương pháp/loại số. Trường hợp quá ít lần trúng không dùng bootstrap để kết luận chắc.',
'- Chọn cách buổi sáng bằng tỷ lệ cùng số trúng cả hai đài ở giai đoạn phát triển; buổi tối bằng tỷ lệ có ít nhất một số trúng trên ngày có dự báo. Không lấy cách tốt nhất của năm cuối rồi gọi đó là lựa chọn từ trước.']
for d in ('2','3'):
 lines += [f'\n## Kết quả đuôi {d} số — giai đoạn sau', 'Tỷ lệ bên dưới là tỷ lệ cả bộ lựa chọn có ít nhất một số đạt điều kiện, không phải xác suất riêng của từng số.']
 for phase in phases:
  obj=res[d][phase];winner=obj['development_selected']
  lines += [f'\n### {phases[phase]}',f'Cách chọn từ giai đoạn trước: **{labels[winner]}**.', '| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |','|---|---:|---:|---:|']
  for method,x in obj['methods'].items():
   q=x['later'];morning=phase.startswith('morning');hits=q['both_hits'] if morning else q['hits'];rate=q['both_rate'] if morning else q['hit_rate'];baseline=q['random_both'] if morning else q['within_random']
   lines.append(f'| {labels[method]} | {hits}/{q["active"]} | {pct(rate)} | {pct(baseline)} |')
  q=obj['methods'][winner]['later']
  if phase.startswith('morning'):
   lines.append(f'Đối chứng là ba số ngẫu nhiên trong toàn bộ không gian số, chấm cùng số ở cả hai đài. Chỉ tiêu phụ “ra ở ít nhất một đài” của cách đã chọn: {q["hits"]}/{q["n"]} = {pct(q["hit_rate"])}; ngẫu nhiên {pct(q["random_rate"])}. Không dùng chỉ tiêu phụ để tuyên bố đạt tiêu chí cả hai đài.')
  else:
   lines.append(f'Đối chứng trong bảng là ngẫu nhiên ngay trong nhóm ứng viên. Trên cùng {q["active"]} ngày có dự báo, ngẫu nhiên toàn không gian đạt kỳ vọng {pct(q["random_rate"])}; Top tần suất XSMB không giới hạn nhóm đạt {pct(q["north_baseline"])}. Có {q["n"]-q["active"]} ngày không có lựa chọn; không tính những ngày đó vào tỷ lệ có dự báo.')
  lines += ['\nDiễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):','| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |','|---|---:|---:|']
  for year,z in obj['methods'][winner]['years'].items():
   hits=z['both_hits'] if phase.startswith('morning') else z['hits'];rate=z['both_rate'] if phase.startswith('morning') else z['hit_rate'];lines.append(f'| 10/11/{year} | {hits}/{z["active"]} | {pct(rate)} |')
 cov=res[d]['coverage']['all'];total=sum(cov.values());zero=cov.get('0',0)
 lines += [f'\nTrong cả bốn năm chấm buổi tối: {zero}/{total} ngày ({pct(zero/total)}) không có đuôi {d} số chung giữa hai đài. Phân bố số lượng số chung: `{json.dumps(cov,ensure_ascii=False)}`.']
lines += ['\n## Điều rút ra và đề xuất chưa áp dụng',
'1. Tiêu chí “cùng số ở cả hai đài” khó hơn nhiều so với “ở ít nhất một đài”. Không lấy tỷ lệ 60–70% của tiêu chí dễ để gắn sang tiêu chí khó.',
'2. Đuôi 2 số: cách học riêng những lần cùng xuất hiện hai đài chưa cho bằng chứng vượt đối chứng. Nên giữ làm nhánh nghiên cứu, chưa thay cách tính chính.',
'3. Buổi tối: việc đã ra ở cả hai đài không đủ để khẳng định dễ ra XSMB hơn. Cách ưu tiên tổng số lần ra buổi chiều đạt 158/346 = 45,66% trong năm sau, cũng chưa tốt hơn ngẫu nhiên trong nhóm 47,21%.',
'4. Đuôi 3 số: 1.080/1.445 ngày không có số chung; cả 4 năm không ngày nào có trên 3 số chung. Vì lấy tối đa 3, mọi cách xếp hạng đều chọn cùng tập số, nên không thể nói một công thức ưu tiên đã cải thiện. Năm sau chỉ có 89 ngày đủ điều kiện và 1 ngày lặp ở Bắc; mẫu quá nhỏ để kết luận lợi thế.',
'5. Nếu anh đồng ý ở bước sau: ghi dự báo giả lập trước giờ quay trong một giai đoạn tương lai cố định, chốt tiêu chí và các cách từ đầu, theo dõi cả thất bại, không đổi cách hằng ngày theo kết quả. Việc ghi theo dõi mới này chưa được thiết lập trong lần nghiên cứu này.',
'6. Không có bằng chứng từ thử nghiệm này để cam kết xác suất trên 60% cho một số riêng lẻ, hoặc cho tiêu chí cùng số xuất hiện cả hai đài. Chỉ xin áp dụng khi đã có bằng chứng và anh đồng ý.',
'\n## Tái lập',
'Chạy `python research.py` (cần NumPy), rồi `python verify.py`. `seed.json` là dữ liệu đóng băng; `forecasts.csv` chứa từng lựa chọn hồi cứu; `results.json` có kết quả theo năm và thứ; `audit.json`, `source_spotchecks.json`, `verification.json` ghi kiểm tra. `make_report.py` tạo lại báo cáo. Không tập tin nào gọi cập nhật hay xuất bản Site.']
(R/'BAO_CAO.md').write_text('\n\n'.join(lines),encoding='utf-8')
print('report ready')
