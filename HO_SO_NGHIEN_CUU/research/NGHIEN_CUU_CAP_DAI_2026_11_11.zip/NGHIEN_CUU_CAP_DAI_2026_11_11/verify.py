"""Independent slow replay of stratified forecasts using Python sets/Counters."""
import csv,json,random
from pathlib import Path
from collections import Counter
from datetime import date
R=Path(__file__).resolve().parent
rows=json.loads((R/'seed.json').read_text())
audit=json.loads((R/'audit.json').read_text());pairs=audit['pairs']
allpred=list(csv.DictReader((R/'forecasts.csv').open(encoding='utf-8-sig')))
lookup={(r['date'],r['station']):r['numbers'] for r in rows}
def vals(nums,d):return [int(s[-d:]) for s in nums if len(s)>=d]
def ranks(hist,method,m,afternoon=None):
 hits=Counter(n for draw in hist for n in set(draw));last={n:i for i,draw in enumerate(hist) for n in draw}
 if method.startswith('recent'):score=Counter(n for draw in hist[-int(method[6:]):] for n in set(draw))
 elif method=='frequency':score=hits
 elif method=='repeat':score=Counter(hist[-1])
 elif method=='gap':score={n:hits[n]*min(len(hist)-last.get(n,-1)-1,20)/20 for n in range(m)}
 else:score=Counter(afternoon)
 return sorted(range(m),key=lambda n:(-score.get(n,0),-hits[n],n))
rng=random.Random(42);sample=[]
for phase in ('morning','morning_joint','evening','evening_union'):
 for digits in ('2','3'):
  for method in sorted({r['method'] for r in allpred if r['phase']==phase}):
   pool=[r for r in allpred if r['phase']==phase and r['digits']==digits and r['method']==method]
   sample.extend(rng.sample(pool,2))
for r in sample:
 day=r['date'];d=int(r['digits']);w=int(r['weekday']);a,b=pairs[w]
 va,vb=vals(lookup[(day,a)],d),vals(lookup[(day,b)],d);sa,sb=set(va),set(vb)
 if r['phase'].startswith('morning'):
  dates=sorted({x['date'] for x in rows if x['date']<day and x['station']==a and date.fromisoformat(x['date']).weekday()==w})
  hist=[vals(lookup[(dt,a)]+lookup[(dt,b)],d) for dt in dates]
  if r['phase']=='morning_joint':
   hist=[[n for n in vals(lookup[(dt,a)]+lookup[(dt,b)],d) if n in set(vals(lookup[(dt,a)],d)) & set(vals(lookup[(dt,b)],d))] for dt in dates]
  selected=ranks(hist,r['method'],10**d)[:3]
  assert int(bool(set(selected)&sa&sb))==int(r['both'])
  actual=sa|sb
 else:
  hist=[vals(x['numbers'],d) for x in sorted(rows,key=lambda x:x['date']) if x['date']<day and x['station']=='XSMB']
  candidates=sa&sb if r['phase']=='evening' else sa|sb
  selected=[n for n in ranks(hist,r['method'],10**d,va+vb) if n in candidates][:int(r['k'])]
  actual=set(vals(lookup[(day,'XSMB')],d))
 assert ','.join(str(n).zfill(d) for n in selected)==r['selected'],r
 assert int(bool(set(selected)&actual))==int(r['hit']),r
# Check every stored outcome and every candidate restriction, not just sampled ranks.
for r in allpred:
 d=int(r['digits']);a,b=pairs[int(r['weekday'])];day=r['date']
 sa=set(vals(lookup[(day,a)],d));sb=set(vals(lookup[(day,b)],d));top=set(map(int,filter(None,r['selected'].split(','))))
 assert len(top)==int(r['k'])
 if r['phase'].startswith('morning'):
  assert int(bool(top&sa&sb))==int(r['both']);actual=sa|sb
 else:
  assert top <= (sa&sb if r['phase']=='evening' else sa|sb)
  assert len(top)==min(3,len(sa&sb))
  actual=set(vals(lookup[(day,'XSMB')],d))
 assert int(bool(top&actual))==int(r['hit'])
out={'independent_rank_replays':len(sample),'all_outcomes_checked':len(allpred),'passed':True}
(R/'verification.json').write_text(json.dumps(out,indent=2));print(out)
