# Nghiên cứu cặp đài miền Nam và lặp lại XSMB — 11/11/2026

**Chỉ nghiên cứu. Chưa sửa app, website, lịch tự động, quyền truy cập hay thuật toán đang dùng.**

## Kết luận

Chưa đủ bằng chứng để đổi hướng áp dụng. Hai cách chọn Top 3 trước quay được chọn ở giai đoạn phát triển đều đạt cùng số xuất hiện ở cả hai đài 36/365 ngày (9,86%) cho đuôi 2 số ở giai đoạn sau; mức đối chứng chọn ngẫu nhiên cùng ba số là 7,82%. Khoảng bất định của chênh lệch vẫn chứa 0. Không được đọc 9,86% thành xác suất chắc chắn cho kỳ tới.

Với XSMB tối cùng ngày, ưu tiên “tần suất × độ vắng” trong nhóm số trùng hai đài được chọn từ giai đoạn trước nhưng chỉ đạt 159/346 ngày có lựa chọn (45,95%) ở năm sau. Đối chứng chọn ngẫu nhiên cùng số lượng ngay trong nhóm trùng là 47,21%. Chưa thấy lợi ích dự báo đáng tin cậy.

## Dữ liệu và kiểm tra

- 7,545 bảng đã lưu; từ 2021-11-10 đến 2026-11-09; 1,826 ngày. Dùng tất cả các giải, giữ số 0 đầu. Đuôi 3 số chỉ lấy giải có ít nhất 3 chữ số, không thêm 0 vào giải 2 số.

- Kiểm tra toàn bộ bảng: không có khóa đài/ngày trùng, sai độ dài/số lượng giải, sai lịch đài hoặc thiếu cặp đài nghiên cứu. Có 20 ngày không có bảng XSMB trong kho (liệt kê audit.json); bỏ qua khi chấm buổi tối, không điền số. Trong bốn năm chấm có 16 ngày như vậy.

- Đối chiếu trực tiếp 12 trang Minh Ngọc, trải sáu mốc năm: 24/24 bảng khớp toàn bộ các số và số lần lặp. XSMB lưu thứ tự hạng giải ngược với bộ đọc hiện tại; tập số có lặp vẫn khớp, không ảnh hưởng thống kê đuôi tất cả giải. Đây là kiểm tra mẫu, không phải tái tải xác minh từng bảng của 5 năm.

- Kiểm tra độc lập 104 lượt xếp hạng bằng cách tính lại toàn bộ lịch sử; kiểm tra kết quả và điều kiện chọn của 75,524 bản ghi thử nghiệm: đều khớp. Các bản ghi này là nhiều công thức trên cùng ngày, không phải từng ấy mẫu độc lập.

- SHA256 dữ liệu: `a2d49d6197fad66fab4dfca06851e7b8f667fc2a65c87030efcfd26c393de1e0`.

## Cặp đài cố định

| Ngày | Hai đài giữ lại |

|---|---|

| Thứ hai | TP. HCM + Đồng Tháp |

| Thứ ba | Bến Tre + Vũng Tàu |

| Thứ tư | Đồng Nai + Cần Thơ |

| Thứ năm | Tây Ninh + An Giang |

| Thứ sáu | Vĩnh Long + Bình Dương |

| Thứ bảy | TP. HCM + Long An |

| Chủ nhật | Tiền Giang + Kiên Giang |


## Cách thử và chống nhìn trước kết quả

- Năm đầu 10/11/2021–09/11/2022 làm lịch sử ban đầu. Chấm cuốn chiếu 1.461 ngày tiếp theo: mỗi dự báo chỉ dùng dữ liệu đã có trước thời điểm dự báo.

- Giai đoạn phát triển 10/11/2022–09/11/2025 chọn cách ưu tiên; giai đoạn sau 10/11/2025–09/11/2026 dùng để so kết quả. Bộ dữ liệu này đã được dùng nghiên cứu trước đây, nên đây vẫn là hồi cứu mang tính khám phá, không phải kiểm định tương lai hoàn toàn mới.

- Hai biến thể trước quay đều có một Top 3 chung cho cặp đài, học riêng lịch sử của cặp đó. Biến thể thứ nhất đếm các số xuất hiện ở ít nhất một đài; biến thể thứ hai chỉ học số cùng xuất hiện ở cả hai. Thành công chính: tồn tại cùng một số trong Top 3 ra ở cả hai đài. Hai số khác nhau mỗi số trúng một đài không đủ điều kiện.

- Buổi tối chỉ dùng hai bảng miền Nam đã đủ giải và lịch sử XSMB trước ngày đang xét. Nhóm giao là số thực sự ra ở cả hai đài. Nếu có dưới 3 số, chỉ chọn số lượng hiện có; nhóm rỗng thì không dự báo. Không tự bù số để đủ Top 3.

- Thử 6 cách đã có: toàn lịch sử, 10/20/50 kỳ gần, tần suất × độ vắng, lần ra kỳ trước. Buổi tối thử thêm số lần ra trong hai đài chiều. Phá hòa bằng tần suất lịch sử, sau đó số nhỏ hơn. Không đảo số, cộng nút hoặc tìm quy tắc tùy ý sau khi xem kết quả.

- Đối chứng cùng ngày, cùng số lượng: chọn ngẫu nhiên trong 00–99 hoặc 000–999; chọn ngẫu nhiên ngay trong nhóm ứng viên; lấy Top theo tần suất XSMB không giới hạn nhóm; và chọn trong hợp hai đài. Đối chứng hợp hai đài chỉ chấm vào ngày nhóm giao không rỗng và chọn đúng bằng số lượng của nhóm giao. Đây không phải thử tất cả số buổi chiều.

- Mức ngẫu nhiên tính chính xác theo tổ hợp trên tập số thực tế mỗi ngày, không cần giả sử các giải độc lập. Khoảng chênh lệch lấy mẫu lại theo tuần lịch, 10.000 lần; chỉ tham khảo, có thêm hiệu chỉnh 52 tổ hợp phương pháp/loại số. Trường hợp quá ít lần trúng không dùng bootstrap để kết luận chắc.

- Chọn cách buổi sáng bằng tỷ lệ cùng số trúng cả hai đài ở giai đoạn phát triển; buổi tối bằng tỷ lệ có ít nhất một số trúng trên ngày có dự báo. Không lấy cách tốt nhất của năm cuối rồi gọi đó là lựa chọn từ trước.


## Kết quả đuôi 2 số — giai đoạn sau

Tỷ lệ bên dưới là tỷ lệ cả bộ lựa chọn có ít nhất một số đạt điều kiện, không phải xác suất riêng của từng số.


### Trước quay: học từ các số ra ở ít nhất một đài

Cách chọn từ giai đoạn trước: **50 kỳ gần nhất**.

| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |

|---|---:|---:|---:|

| Tần suất toàn lịch sử | 31/365 | 8.49% | 7.82% |

| 10 kỳ gần nhất | 36/365 | 9.86% | 7.82% |

| 20 kỳ gần nhất | 37/365 | 10.14% | 7.82% |

| 50 kỳ gần nhất | 36/365 | 9.86% | 7.82% |

| Tần suất × độ vắng (chặn ở 20 kỳ) | 33/365 | 9.04% | 7.82% |

| Số lần ra kỳ liền trước | 40/365 | 10.96% | 7.82% |

Đối chứng là ba số ngẫu nhiên trong toàn bộ không gian số, chấm cùng số ở cả hai đài. Chỉ tiêu phụ “ra ở ít nhất một đài” của cách đã chọn: 249/365 = 68.22%; ngẫu nhiên 66.66%. Không dùng chỉ tiêu phụ để tuyên bố đạt tiêu chí cả hai đài.


Diễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):

| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |

|---|---:|---:|

| 10/11/2022 | 40/365 | 10.96% |

| 10/11/2023 | 31/366 | 8.47% |

| 10/11/2024 | 33/365 | 9.04% |

| 10/11/2025 | 36/365 | 9.86% |


### Trước quay: học riêng các số cùng ra ở cả hai đài

Cách chọn từ giai đoạn trước: **10 kỳ gần nhất**.

| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |

|---|---:|---:|---:|

| Tần suất toàn lịch sử | 27/365 | 7.40% | 7.82% |

| 10 kỳ gần nhất | 36/365 | 9.86% | 7.82% |

| 20 kỳ gần nhất | 35/365 | 9.59% | 7.82% |

| 50 kỳ gần nhất | 35/365 | 9.59% | 7.82% |

| Tần suất × độ vắng (chặn ở 20 kỳ) | 22/365 | 6.03% | 7.82% |

| Số lần ra kỳ liền trước | 38/365 | 10.41% | 7.82% |

Đối chứng là ba số ngẫu nhiên trong toàn bộ không gian số, chấm cùng số ở cả hai đài. Chỉ tiêu phụ “ra ở ít nhất một đài” của cách đã chọn: 240/365 = 65.75%; ngẫu nhiên 66.66%. Không dùng chỉ tiêu phụ để tuyên bố đạt tiêu chí cả hai đài.


Diễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):

| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |

|---|---:|---:|

| 10/11/2022 | 36/365 | 9.86% |

| 10/11/2023 | 33/366 | 9.02% |

| 10/11/2024 | 46/365 | 12.60% |

| 10/11/2025 | 36/365 | 9.86% |


### Chiều → Bắc: chỉ chọn trong giao hai đài

Cách chọn từ giai đoạn trước: **Tần suất × độ vắng (chặn ở 20 kỳ)**.

| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |

|---|---:|---:|---:|

| Tần suất toàn lịch sử | 157/346 | 45.38% | 47.21% |

| 10 kỳ gần nhất | 165/346 | 47.69% | 47.21% |

| 20 kỳ gần nhất | 165/346 | 47.69% | 47.21% |

| 50 kỳ gần nhất | 166/346 | 47.98% | 47.21% |

| Tần suất × độ vắng (chặn ở 20 kỳ) | 159/346 | 45.95% | 47.21% |

| Số lần ra kỳ liền trước | 161/346 | 46.53% | 47.21% |

| Số lần ra trong hai đài buổi chiều | 158/346 | 45.66% | 47.21% |

Đối chứng trong bảng là ngẫu nhiên ngay trong nhóm ứng viên. Trên cùng 346 ngày có dự báo, ngẫu nhiên toàn không gian đạt kỳ vọng 46.72%; Top tần suất XSMB không giới hạn nhóm đạt 47.11%. Có 15 ngày không có lựa chọn; không tính những ngày đó vào tỷ lệ có dự báo.


Diễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):

| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |

|---|---:|---:|

| 10/11/2022 | 148/350 | 42.29% |

| 10/11/2023 | 171/342 | 50.00% |

| 10/11/2024 | 155/342 | 45.32% |

| 10/11/2025 | 159/346 | 45.95% |


### Đối chứng chiều → Bắc: chọn trong hợp hai đài, cùng số lượng

Cách chọn từ giai đoạn trước: **Tần suất × độ vắng (chặn ở 20 kỳ)**.

| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |

|---|---:|---:|---:|

| Tần suất toàn lịch sử | 159/346 | 45.95% | 46.35% |

| 10 kỳ gần nhất | 151/346 | 43.64% | 46.35% |

| 20 kỳ gần nhất | 156/346 | 45.09% | 46.35% |

| 50 kỳ gần nhất | 153/346 | 44.22% | 46.35% |

| Tần suất × độ vắng (chặn ở 20 kỳ) | 146/346 | 42.20% | 46.35% |

| Số lần ra kỳ liền trước | 158/346 | 45.66% | 46.35% |

| Số lần ra trong hai đài buổi chiều | 159/346 | 45.95% | 46.35% |

Đối chứng trong bảng là ngẫu nhiên ngay trong nhóm ứng viên. Trên cùng 346 ngày có dự báo, ngẫu nhiên toàn không gian đạt kỳ vọng 46.72%; Top tần suất XSMB không giới hạn nhóm đạt 47.11%. Có 15 ngày không có lựa chọn; không tính những ngày đó vào tỷ lệ có dự báo.


Diễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):

| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |

|---|---:|---:|

| 10/11/2022 | 165/350 | 47.14% |

| 10/11/2023 | 159/342 | 46.49% |

| 10/11/2024 | 183/342 | 53.51% |

| 10/11/2025 | 146/346 | 42.20% |


Trong cả bốn năm chấm buổi tối: 65/1445 ngày (4.50%) không có đuôi 2 số chung giữa hai đài. Phân bố số lượng số chung: `{"3": 373, "2": 398, "6": 37, "1": 221, "0": 65, "5": 99, "4": 238, "9": 1, "7": 10, "8": 3}`.


## Kết quả đuôi 3 số — giai đoạn sau

Tỷ lệ bên dưới là tỷ lệ cả bộ lựa chọn có ít nhất một số đạt điều kiện, không phải xác suất riêng của từng số.


### Trước quay: học từ các số ra ở ít nhất một đài

Cách chọn từ giai đoạn trước: **Tần suất × độ vắng (chặn ở 20 kỳ)**.

| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |

|---|---:|---:|---:|

| Tần suất toàn lịch sử | 2/365 | 0.55% | 0.09% |

| 10 kỳ gần nhất | 0/365 | 0.00% | 0.09% |

| 20 kỳ gần nhất | 0/365 | 0.00% | 0.09% |

| 50 kỳ gần nhất | 1/365 | 0.27% | 0.09% |

| Tần suất × độ vắng (chặn ở 20 kỳ) | 1/365 | 0.27% | 0.09% |

| Số lần ra kỳ liền trước | 0/365 | 0.00% | 0.09% |

Đối chứng là ba số ngẫu nhiên trong toàn bộ không gian số, chấm cùng số ở cả hai đài. Chỉ tiêu phụ “ra ở ít nhất một đài” của cách đã chọn: 30/365 = 8.22%; ngẫu nhiên 9.70%. Không dùng chỉ tiêu phụ để tuyên bố đạt tiêu chí cả hai đài.


Diễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):

| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |

|---|---:|---:|

| 10/11/2022 | 1/365 | 0.27% |

| 10/11/2023 | 1/366 | 0.27% |

| 10/11/2024 | 0/365 | 0.00% |

| 10/11/2025 | 1/365 | 0.27% |


### Trước quay: học riêng các số cùng ra ở cả hai đài

Cách chọn từ giai đoạn trước: **Tần suất toàn lịch sử**.

| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |

|---|---:|---:|---:|

| Tần suất toàn lịch sử | 1/365 | 0.27% | 0.09% |

| 10 kỳ gần nhất | 0/365 | 0.00% | 0.09% |

| 20 kỳ gần nhất | 0/365 | 0.00% | 0.09% |

| 50 kỳ gần nhất | 0/365 | 0.00% | 0.09% |

| Tần suất × độ vắng (chặn ở 20 kỳ) | 1/365 | 0.27% | 0.09% |

| Số lần ra kỳ liền trước | 0/365 | 0.00% | 0.09% |

Đối chứng là ba số ngẫu nhiên trong toàn bộ không gian số, chấm cùng số ở cả hai đài. Chỉ tiêu phụ “ra ở ít nhất một đài” của cách đã chọn: 35/365 = 9.59%; ngẫu nhiên 9.70%. Không dùng chỉ tiêu phụ để tuyên bố đạt tiêu chí cả hai đài.


Diễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):

| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |

|---|---:|---:|

| 10/11/2022 | 0/365 | 0.00% |

| 10/11/2023 | 1/366 | 0.27% |

| 10/11/2024 | 1/365 | 0.27% |

| 10/11/2025 | 1/365 | 0.27% |


### Chiều → Bắc: chỉ chọn trong giao hai đài

Cách chọn từ giai đoạn trước: **Tần suất toàn lịch sử**.

| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |

|---|---:|---:|---:|

| Tần suất toàn lịch sử | 1/89 | 1.12% | 1.12% |

| 10 kỳ gần nhất | 1/89 | 1.12% | 1.12% |

| 20 kỳ gần nhất | 1/89 | 1.12% | 1.12% |

| 50 kỳ gần nhất | 1/89 | 1.12% | 1.12% |

| Tần suất × độ vắng (chặn ở 20 kỳ) | 1/89 | 1.12% | 1.12% |

| Số lần ra kỳ liền trước | 1/89 | 1.12% | 1.12% |

| Số lần ra trong hai đài buổi chiều | 1/89 | 1.12% | 1.12% |

Đối chứng trong bảng là ngẫu nhiên ngay trong nhóm ứng viên. Trên cùng 89 ngày có dự báo, ngẫu nhiên toàn không gian đạt kỳ vọng 2.70%; Top tần suất XSMB không giới hạn nhóm đạt 2.25%. Có 272 ngày không có lựa chọn; không tính những ngày đó vào tỷ lệ có dự báo.


Diễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):

| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |

|---|---:|---:|

| 10/11/2022 | 2/94 | 2.13% |

| 10/11/2023 | 5/88 | 5.68% |

| 10/11/2024 | 2/94 | 2.13% |

| 10/11/2025 | 1/89 | 1.12% |


### Đối chứng chiều → Bắc: chọn trong hợp hai đài, cùng số lượng

Cách chọn từ giai đoạn trước: **Số lần ra kỳ liền trước**.

| Cách ưu tiên | Lần đạt / ngày có lựa chọn | Tỷ lệ | Đối chứng ngẫu nhiên |

|---|---:|---:|---:|

| Tần suất toàn lịch sử | 5/89 | 5.62% | 2.69% |

| 10 kỳ gần nhất | 1/89 | 1.12% | 2.69% |

| 20 kỳ gần nhất | 1/89 | 1.12% | 2.69% |

| 50 kỳ gần nhất | 2/89 | 2.25% | 2.69% |

| Tần suất × độ vắng (chặn ở 20 kỳ) | 8/89 | 8.99% | 2.69% |

| Số lần ra kỳ liền trước | 3/89 | 3.37% | 2.69% |

| Số lần ra trong hai đài buổi chiều | 1/89 | 1.12% | 2.69% |

Đối chứng trong bảng là ngẫu nhiên ngay trong nhóm ứng viên. Trên cùng 89 ngày có dự báo, ngẫu nhiên toàn không gian đạt kỳ vọng 2.70%; Top tần suất XSMB không giới hạn nhóm đạt 2.25%. Có 272 ngày không có lựa chọn; không tính những ngày đó vào tỷ lệ có dự báo.


Diễn biến bốn năm với cùng công thức được chọn (ba năm đầu đã tham gia lựa chọn):

| Giai đoạn bắt đầu | Lần đạt / ngày có lựa chọn | Tỷ lệ |

|---|---:|---:|

| 10/11/2022 | 2/94 | 2.13% |

| 10/11/2023 | 4/88 | 4.55% |

| 10/11/2024 | 3/94 | 3.19% |

| 10/11/2025 | 3/89 | 3.37% |


Trong cả bốn năm chấm buổi tối: 1080/1445 ngày (74.74%) không có đuôi 3 số chung giữa hai đài. Phân bố số lượng số chung: `{"0": 1080, "1": 314, "2": 50, "3": 1}`.


## Điều rút ra và đề xuất chưa áp dụng

1. Tiêu chí “cùng số ở cả hai đài” khó hơn nhiều so với “ở ít nhất một đài”. Không lấy tỷ lệ 60–70% của tiêu chí dễ để gắn sang tiêu chí khó.

2. Đuôi 2 số: cách học riêng những lần cùng xuất hiện hai đài chưa cho bằng chứng vượt đối chứng. Nên giữ làm nhánh nghiên cứu, chưa thay cách tính chính.

3. Buổi tối: việc đã ra ở cả hai đài không đủ để khẳng định dễ ra XSMB hơn. Cách ưu tiên tổng số lần ra buổi chiều đạt 158/346 = 45,66% trong năm sau, cũng chưa tốt hơn ngẫu nhiên trong nhóm 47,21%.

4. Đuôi 3 số: 1.080/1.445 ngày không có số chung; cả 4 năm không ngày nào có trên 3 số chung. Vì lấy tối đa 3, mọi cách xếp hạng đều chọn cùng tập số, nên không thể nói một công thức ưu tiên đã cải thiện. Năm sau chỉ có 89 ngày đủ điều kiện và 1 ngày lặp ở Bắc; mẫu quá nhỏ để kết luận lợi thế.

5. Nếu anh đồng ý ở bước sau: ghi dự báo giả lập trước giờ quay trong một giai đoạn tương lai cố định, chốt tiêu chí và các cách từ đầu, theo dõi cả thất bại, không đổi cách hằng ngày theo kết quả. Việc ghi theo dõi mới này chưa được thiết lập trong lần nghiên cứu này.

6. Không có bằng chứng từ thử nghiệm này để cam kết xác suất trên 60% cho một số riêng lẻ, hoặc cho tiêu chí cùng số xuất hiện cả hai đài. Chỉ xin áp dụng khi đã có bằng chứng và anh đồng ý.


## Tái lập

Chạy `python research.py` (cần NumPy), rồi `python verify.py`. `seed.json` là dữ liệu đóng băng; `forecasts.csv` chứa từng lựa chọn hồi cứu; `results.json` có kết quả theo năm và thứ; `audit.json`, `source_spotchecks.json`, `verification.json` ghi kiểm tra. `make_report.py` tạo lại báo cáo. Không tập tin nào gọi cập nhật hay xuất bản Site.