"""Research only: no network writes, no production imports or modifications.
Python 3 + numpy. Run from any directory. Dates use Vietnamese draw dates.
"""
import json, csv, hashlib, math
from pathlib import Path
from datetime import date, timedelta
from collections import defaultdict, Counter, deque
import numpy as np

ROOT=Path(__file__).resolve().parent
PAIRS=[['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An'],['Tiền Giang','Kiên Giang']]
METHODS=['frequency','recent10','recent20','recent50','gap','repeat']
EVENING=METHODS+['afternoon_count']
class State:
    def __init__(self,m):
        self.m=m;self.n=0;self.hits=np.zeros(m,int);self.last=np.full(m,-1,int)
        self.repeat=np.zeros(m,int);self.history=deque(maxlen=50)
        self.recent={w:np.zeros(m,int) for w in (10,20,50)}
    def ranks(self):
        scores=[self.hits,self.recent[10],self.recent[20],self.recent[50],self.hits*np.minimum(self.n-self.last-1,20)/20,self.repeat]
        return [np.lexsort((np.arange(self.m),-self.hits,-s)) for s in scores]
    def add(self,c):
        p=(c>0).astype(int)
        for w in self.recent:
            if len(self.history)>=w:self.recent[w]-=self.history[-w]
            self.recent[w]+=p
        self.history.append(p);self.hits+=p;self.last[p>0]=self.n
        self.repeat=c.copy();self.n+=1
def count(nums,d):
    c=np.zeros(10**d,int)
    for s in nums:
        if len(s)>=d:c[int(s[-d:])]+=1
    return c
def chance(m,u,k):
    if k==0:return 0.
    return 1-math.comb(m-u,k)/math.comb(m,k) if m-u>=k else 1.
def fmt(nums,d):return ','.join(str(int(x)).zfill(d) for x in nums)

raw=(ROOT/'seed.json').read_bytes();rows=json.loads(raw)
byday=defaultdict(dict);errors=[]
schedule=defaultdict(set)
for w,pair in enumerate(PAIRS):
    for station in pair:schedule[station].add(w)
schedule.update({'Cà Mau':{0},'Bạc Liêu':{1},'Sóc Trăng':{2},'Bình Thuận':{3},'Trà Vinh':{4},'Bình Phước':{5},'Hậu Giang':{5},'Đà Lạt':{6}})
for row in rows:
    day,station,nums=row['date'],row['station'],row['numbers']
    dt=date.fromisoformat(day)
    if station in byday[day]:errors.append(['duplicate',day,station])
    if any(not isinstance(n,str) or not n.isascii() or not n.isdigit() for n in nums):errors.append(['number format',day,station])
    expected={2:4,3:3,4:10,5:10} if station=='XSMB' else {2:1,3:1,4:4,5:11,6:1}
    if dict(Counter(map(len,nums)))!=expected:errors.append(['prize shape',day,station])
    if station!='XSMB' and dt.weekday() not in schedule.get(station,set()):errors.append(['schedule',day,station])
    byday[day][station]=nums
start,end=min(byday),max(byday);days=[];dt=date.fromisoformat(start)
missing_north=[]
while dt<=date.fromisoformat(end):
    day=dt.isoformat();days.append(day)
    for s in PAIRS[dt.weekday()]:
        if s not in byday[day]:errors.append(['missing pair',day,s])
    if 'XSMB' not in byday[day]:missing_north.append(day)
    dt+=timedelta(days=1)
assert not errors,errors
audit={'rows':len(rows),'sha256':hashlib.sha256(raw).hexdigest(),'start':start,'end':end,'days':len(days),'pairs':PAIRS,'missing_north':missing_north,'internal_errors':errors,'external_reverification':'Not performed in this run; validates saved dataset internally, not each record against live source.'}
(ROOT/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
records=[];coverage=[]
for d in (2,3):
    m=10**d;pair_states=[State(m) for _ in PAIRS];joint_states=[State(m) for _ in PAIRS];north=State(m)
    for day in days:
        w=date.fromisoformat(day).weekday();a,b=PAIRS[w]
        ca,cb=count(byday[day][a],d),count(byday[day][b],d)
        union=(ca+cb)>0;inter=(ca>0)&(cb>0);candidates=np.flatnonzero(inter)
        scored=day>='2022-11-10';period='later' if day>='2025-11-10' else 'development'
        if scored:
            for method,ranks in zip(METHODS,pair_states[w].ranks()):
                top=ranks[:3]
                records.append(dict(date=day,weekday=w,digits=d,phase='morning',method=method,period=period,k=3,candidates=int(inter.sum()),selected=fmt(top,d),both=int(inter[top].any()),hit=int(union[top].any()),random_both=chance(m,int(inter.sum()),3),random_hit=chance(m,int(union.sum()),3),within_random='',north_baseline=''))
            for method,ranks in zip(METHODS,joint_states[w].ranks()):
                top=ranks[:3]
                records.append(dict(date=day,weekday=w,digits=d,phase='morning_joint',method=method,period=period,k=3,candidates=int(inter.sum()),selected=fmt(top,d),both=int(inter[top].any()),hit=int(union[top].any()),random_both=chance(m,int(inter.sum()),3),random_hit=chance(m,int(union.sum()),3),within_random='',north_baseline=''))
        # Morning forecasts exist before admitting either afternoon result.
        pair_states[w].add(ca+cb)
        joint_states[w].add(np.where(inter,ca+cb,0))
        if 'XSMB' not in byday[day]:continue
        actual=count(byday[day]['XSMB'],d)>0
        if scored:
            k=min(3,len(candidates));ranks=north.ranks()
            # Afternoon score ties: previous North frequency, then number ascending.
            ranks.append(np.lexsort((np.arange(m),-north.hits,-(ca+cb))))
            coverage.append(dict(date=day,digits=d,period=period,weekday=w,candidates=len(candidates),k=k,matching=int(actual[candidates].sum())))
            for method,order in zip(EVENING,ranks):
                top=order[inter[order]][:k]
                records.append(dict(date=day,weekday=w,digits=d,phase='evening',method=method,period=period,k=k,candidates=len(candidates),selected=fmt(top,d),both='',hit=int(actual[top].any()),random_both='',random_hit=chance(m,int(actual.sum()),k),within_random=chance(len(candidates),int(actual[candidates].sum()),k),north_baseline=int(actual[ranks[0][:k]].any())))
            for method,order in zip(EVENING,ranks):
                top=order[union[order]][:k]
                records.append(dict(date=day,weekday=w,digits=d,phase='evening_union',method=method,period=period,k=k,candidates=int(union.sum()),selected=fmt(top,d),both='',hit=int(actual[top].any()),random_both='',random_hit=chance(m,int(actual.sum()),k),within_random=chance(int(union.sum()),int(actual[union].sum()),k),north_baseline=int(actual[ranks[0][:k]].any())))
        # Today's North result only enters training AFTER every evening forecast.
        north.add(count(byday[day]['XSMB'],d))
def writecsv(name,items):
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(items[0]));wr.writeheader();wr.writerows(items)
writecsv('forecasts.csv',records);writecsv('coverage.csv',coverage)
rng=np.random.default_rng(20261111)
def ci(part,target,baseline):
    # Calendar week cluster bootstrap; paired differences, approximate exploratory CIs.
    if target=='both' and sum(r[target] for r in part)<10:return {'unreliable_rare_events':True}
    groups=defaultdict(list)
    for r in part:groups[(date.fromisoformat(r['date'])-date(2021,11,8)).days//7].append(r[target]-r[baseline])
    vals=np.array([[sum(v),len(v)] for v in groups.values()])
    if len(vals)<2:return None
    draws=rng.integers(len(vals),size=(10000,len(vals)))
    sums=vals[draws].sum(axis=1);diff=sums[:,0]/sums[:,1]
    return {'ci95':np.quantile(diff,[.025,.975]).tolist(),'ci_family52':np.quantile(diff,[.05/104,1-.05/104]).tolist()}
def summ(part,phase,interval=False):
    active=[r for r in part if r['k']>0]
    if not active:return {'n':len(part),'active':0}
    out={'n':len(part),'active':len(active),'hits':sum(r['hit'] for r in active),'hit_rate':float(np.mean([r['hit'] for r in active])),'random_rate':float(np.mean([r['random_hit'] for r in active]))}
    if phase.startswith('morning'):
        out.update(both_hits=sum(r['both'] for r in active),both_rate=float(np.mean([r['both'] for r in active])),random_both=float(np.mean([r['random_both'] for r in active])))
        if interval:out['both_difference']=ci(active,'both','random_both')
    else:
        out.update(within_random=float(np.mean([r['within_random'] for r in active])),north_baseline=float(np.mean([r['north_baseline'] for r in active])),ranking_days=sum(r['candidates']>3 for r in active))
        if interval:
            out['vs_within']=ci(active,'hit','within_random');out['vs_unrestricted_north']=ci(active,'hit','north_baseline')
    return out
results={}
for d in (2,3):
    result={}
    for phase,methods in [('morning',METHODS),('morning_joint',METHODS),('evening',EVENING),('evening_union',EVENING)]:
        bymethod={}
        for method in methods:
            part=[r for r in records if r['digits']==d and r['phase']==phase and r['method']==method]
            bymethod[method]={p:summ([r for r in part if p=='all' or r['period']==p],phase,p=='later') for p in ('all','development','later')}
            bymethod[method]['years']={str(y):summ([r for r in part if f'{y}-11-10'<=r['date']<f'{y+1}-11-10'],phase) for y in range(2022,2026)}
            bymethod[method]['weekday']={str(w):summ([r for r in part if r['weekday']==w],phase) for w in range(7)}
        metric='both_rate' if phase.startswith('morning') else 'hit_rate'
        winner=max(methods,key=lambda method:bymethod[method]['development'][metric])
        result[phase]={'methods':bymethod,'development_selected':winner,'selection_metric':metric}
    cov=[r for r in coverage if r['digits']==d]
    result['coverage']={p:dict(Counter(r['candidates'] for r in cov if p=='all' or r['period']==p)) for p in ('all','development','later')}
    results[str(d)]=result
(ROOT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(audit,ensure_ascii=False))
for d,r in results.items():
    print('DIGITS',d,'COVERAGE',r['coverage'])
    for phase in ('morning','evening'):
        print(phase,'SELECTED',r[phase]['development_selected'])
        for method,res in r[phase]['methods'].items():print(method,json.dumps(res['later']))
