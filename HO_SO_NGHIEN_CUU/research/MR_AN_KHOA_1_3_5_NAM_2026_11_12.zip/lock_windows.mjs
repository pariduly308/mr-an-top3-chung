import fs from 'node:fs';
import crypto from 'node:crypto';
import {rank,methods} from './analysis.mjs';
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const now=new Date(),date=now.toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}),hour=Number(now.toLocaleTimeString('en-GB',{timeZone:'Asia/Ho_Chi_Minh',hour:'2-digit',hour12:false}));
const raw=fs.readFileSync(new URL('./data.json',import.meta.url),'utf8'),draws=JSON.parse(raw),pairDays=[['Tiền Giang','Kiên Giang'],['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An']],pair=pairDays[new Date(date+'T12:00:00Z').getUTCDay()];
const records=[],skipped=[];
for(const members of [pair,...pair.map(x=>[x]),['XSMB']]){
 const north=members[0]==='XSMB',station=members.join(' + ');
 if(hour>=(north?18:16)||draws.some(r=>r.date===date&&members.includes(r.station))){skipped.push({station,reason:'cutoff_or_results_already_available'});continue;}
 const by=new Map();for(const r of draws.filter(r=>r.date<date&&members.includes(r.station))){if(!by.has(r.date))by.set(r.date,{});if(by.get(r.date)[r.station])throw Error('Duplicate station/date');by.get(r.date)[r.station]=r;}
 const complete=[...by].filter(([d,g])=>members.every(s=>g[s])).map(([date,g])=>({date,station,numbers:members.flatMap(s=>g[s].numbers)})).sort((a,b)=>a.date.localeCompare(b.date));
 for(const years of [1,3,5]){
  const boundary=new Date(date+'T00:00:00Z');boundary.setUTCFullYear(boundary.getUTCFullYear()-years);const start=boundary.toISOString().slice(0,10),history=complete.filter(r=>r.date>=start);
  if(history.length<30)throw Error('Insufficient history');
  for(const digits of [2,3])for(const method of Object.keys(methods)){
   const ranked=rank(history,digits,method);
   records.push({targetDate:date,station,members,years,windowStart:start,windowEndExclusive:date,historyCount:history.length,historyFirst:history[0].date,historyLast:history.at(-1).date,historyHash:hash(JSON.stringify(history)),digits,method,top3:ranked.slice(0,3).map(r=>r.number),top3Details:ranked.slice(0,3),uniformTop3Baseline:1-(1-3/10**digits)**(members.length*(north?(digits===2?27:23):(digits===2?18:17))),probabilityModel:null});
  }
 }
}
const output={schema:'window-study-v1',createdAt:now.toISOString(),timezone:'Asia/Ho_Chi_Minh',date,sourceDataHash:hash(raw),algorithmHash:hash(fs.readFileSync(new URL('./analysis.mjs',import.meta.url))),cutoffs:{south:'16:00',north:'18:00'},purpose:'Research only. No changes to live apps. Never overwrite locked predictions.',rule:'calendar-year windows [target minus years,target); same formulas, same targets, Top3, any hit within target member(s); all six methods retained; no per-number probability claimed',records,skipped};
fs.writeFileSync(new URL('./LOCK_1_3_5_'+date+'.json',import.meta.url),JSON.stringify(output,null,2),{flag:'wx'});
console.log(JSON.stringify({date,createdAt:output.createdAt,records:records.length,skipped,counts:records.filter(r=>r.digits===2&&r.method==='frequency').map(r=>({station:r.station,years:r.years,count:r.historyCount}))}));
