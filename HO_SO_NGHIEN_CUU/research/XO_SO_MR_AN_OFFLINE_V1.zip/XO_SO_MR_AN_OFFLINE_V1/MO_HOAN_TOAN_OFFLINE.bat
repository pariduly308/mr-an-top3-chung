@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 -c "import sys;sys.exit(sys.version_info < (3,10))" >nul 2>&1
if not errorlevel 1 (
    py -3 app.py --no-sync
    if errorlevel 1 pause
    exit /b
)
python app.py --no-sync
if errorlevel 1 pause
