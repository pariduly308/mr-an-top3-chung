@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 -c "import sys;sys.exit(sys.version_info < (3,10))" >nul 2>&1
if not errorlevel 1 (
    py -3 app.py
    if errorlevel 1 pause
    exit /b
)
python -c "import sys;sys.exit(sys.version_info < (3,10))" >nul 2>&1
if not errorlevel 1 (
    python app.py
    if errorlevel 1 pause
    exit /b
)
echo Cần cài Python 3.10 trở lên. Khi cài, chọn Add Python to PATH.
echo Tải tại https://www.python.org/downloads/windows/
pause
