"""Cùng sáu cách xếp hạng với bản web; tỷ lệ lịch sử không phải cam kết kỳ tới."""
from .domain import now_vn, stations_on, expected_keys, VN

METHODS = ['frequency','recent10','recent20','recent50','gap','repeat']

def rank(draws,digits,method='frequency'):
    rows=[dict(number=str(n).zfill(digits),hits=0,total=0,gap=len(draws),last='Chưa thấy',recent10=0,recent20=0,recent50=0,repeat=0,count=len(draws)) for n in range(10**digits)]
    for i,draw in enumerate(draws):
        counts={}
        for value in draw['numbers']:
            if len(value)>=digits:
                n=int(value[-digits:]);counts[n]=counts.get(n,0)+1
        for n,count in counts.items():
            row=rows[n];row['hits']+=1;row['total']+=count;row['gap']=len(draws)-i-1;row['last']=draw['date']
            for window in (10,20,50):
                if i>=len(draws)-window:row['recent'+str(window)]+=1
            if i==len(draws)-1:row['repeat']=count
    return sorted(rows,key=lambda r:(-score(r,method),-r['hits'],r['number']))

def score(row,method):
    if method=='gap':return row['hits']*min(row['gap'],20)/20
    return row['hits'] if method=='frequency' else row[method]

def capture_forecasts(db,now=None):
    now=(now or now_vn()).astimezone(VN); today=now.date().isoformat();draws=db.draws();saved=[]
    keys=db.keys(); start=db.meta('start_date',today)
    missing=set(expected_keys(start,now))-keys
    for station in stations_on(today):
        if now.hour >= (18 if station=='XSMB' else 16) or (today,station) in keys:continue
        history=[r for r in draws if r['station']==station and r['date']<today]
        # Chờ bù hết kỳ đã đến hạn của đài trước khi khóa dự báo.
        if len(history)<30 or any(s==station for _,s in missing):continue
        predictions={}
        for digits in (2,3):
            rows=rank(history,digits)
            predictions[str(digits)]={m:[r['number'] for r in sorted(rows,key=lambda r:(-score(r,m),-r['hits'],r['number']))[:3]] for m in METHODS}
        snapshot=dict(date=today,station=station,createdAt=now.isoformat(),historyThrough=history[-1]['date'],historyCount=len(history),version='six-methods-v1-local',predictions=predictions)
        if db.save_forecast(snapshot):saved.append(station)
    return saved

def tracking_report(db):
    draws={(r['date'],r['station']):r for r in db.draws()};result=[]
    for snapshot in db.forecasts():
        actual=draws.get((snapshot['date'],snapshot['station']));scores={}
        for digits in (2,3):
            tails={n[-digits:] for n in actual['numbers'] if len(n)>=digits} if actual else set()
            scores[str(digits)]={m:[n for n in ns if n in tails] if actual else None for m,ns in snapshot['predictions'][str(digits)].items()}
        result.append(dict(snapshot,scores=scores,complete=bool(actual)))
    return result
