"""Quy tắc đài và bảng đủ giải. Không có dữ liệu ngẫu nhiên."""
import json
from pathlib import Path
from collections import Counter
from datetime import date, datetime, timedelta, timezone

VN = timezone(timedelta(hours=7))
# Python: Monday=0.
SCHEDULE = [
    ['TP. HCM', 'Đồng Tháp', 'Cà Mau'],
    ['Bến Tre', 'Vũng Tàu', 'Bạc Liêu'],
    ['Đồng Nai', 'Cần Thơ', 'Sóc Trăng'],
    ['Tây Ninh', 'An Giang', 'Bình Thuận'],
    ['Vĩnh Long', 'Bình Dương', 'Trà Vinh'],
    ['TP. HCM', 'Long An', 'Bình Phước', 'Hậu Giang'],
    ['Tiền Giang', 'Kiên Giang', 'Đà Lạt'],
]
STATIONS = set(sum(SCHEDULE, [])) | {'XSMB'}
PRIZES = {
    'mien-nam': {'giai8': (1, 2), 'giai7': (1, 3), 'giai6': (3, 4), 'giai5': (1, 4), 'giai4': (7, 5), 'giai3': (2, 5), 'giai2': (1, 5), 'giai1': (1, 5), 'giaidb': (1, 6)},
    'mien-bac': {'giai7': (4, 2), 'giai6': (3, 3), 'giai5': (6, 4), 'giai4': (4, 4), 'giai3': (6, 5), 'giai2': (2, 5), 'giai1': (1, 5), 'giaidb': (1, 5)},
}
def now_vn():
    return datetime.now(VN)

HOLIDAYS = json.loads((Path(__file__).resolve().parent.parent/'LICH_NGHI.json').read_text(encoding='utf-8'))['mien_bac']

def is_holiday(day):
    key = day if isinstance(day,str) else day.isoformat()
    return any(h['tu'] <= key <= h['den'] for h in HOLIDAYS)

def stations_on(day):
    if isinstance(day, str): day = date.fromisoformat(day)
    return SCHEDULE[day.weekday()] + ([] if is_holiday(day) else ['XSMB'])

def region_of(station):
    return 'mien-bac' if station == 'XSMB' else 'mien-nam'

def valid_draw(row):
    try:
        station = row['station']; day = date.fromisoformat(row['date'])
        if day.isoformat() != row['date'] or station not in stations_on(day): return False
        numbers = row['numbers']
        if not isinstance(numbers, list) or any(not isinstance(n,str) or not n.isascii() or not n.isdigit() for n in numbers): return False
        expected = Counter()
        for count, width in PRIZES[region_of(station)].values(): expected[width] += count
        return Counter(map(len, numbers)) == expected
    except (KeyError, TypeError, ValueError): return False

def expected_keys(start, now=None):
    now = now or now_vn()
    if now.tzinfo is None: raise ValueError('Thời gian phải có múi giờ')
    now = now.astimezone(VN)
    day = date.fromisoformat(start)
    while day <= now.date():
        for station in stations_on(day):
            # Chờ đến sau giờ thường có đủ bảng, tránh báo thiếu khi chưa quay xong.
            cutoff = (18, 45) if station == 'XSMB' else (16, 45)
            if day == now.date() and (now.hour, now.minute) < cutoff: continue
            yield (day.isoformat(), station)
        day += timedelta(days=1)
