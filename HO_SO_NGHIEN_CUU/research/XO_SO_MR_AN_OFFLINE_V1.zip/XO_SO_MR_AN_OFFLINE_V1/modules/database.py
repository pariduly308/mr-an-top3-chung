import json
import sqlite3
from pathlib import Path
from .domain import valid_draw

class Database:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS draws (date TEXT NOT NULL, station TEXT NOT NULL, numbers TEXT NOT NULL, source TEXT NOT NULL, PRIMARY KEY(date,station));
            CREATE TABLE IF NOT EXISTS forecasts (date TEXT NOT NULL, station TEXT NOT NULL, snapshot TEXT NOT NULL, PRIMARY KEY(date,station));
            CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            ''')
    def connect(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.execute('PRAGMA busy_timeout=30000')
        return db
    def seed(self, path):
        if self.meta('seed_loaded'): return
        rows = json.loads(Path(path).read_text(encoding='utf-8'))
        if not rows or any(not valid_draw(r) for r in rows): raise ValueError('Dữ liệu ban đầu có bảng sai cấu trúc; dừng nhập.')
        with self.connect() as db:
            db.executemany('INSERT OR IGNORE INTO draws VALUES (?,?,?,?)', [(r['date'],r['station'],json.dumps(r['numbers']), 'Minh Ngọc / bản kèm theo') for r in rows])
            db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)', ('seed_loaded',json.dumps(True)))
            db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)', ('start_date',json.dumps(min(r['date'] for r in rows))))
    def meta(self, key, default=None):
        with self.connect() as db: row=db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
        return json.loads(row[0]) if row else default
    def set_meta(self,key,value):
        with self.connect() as db: db.execute('INSERT OR REPLACE INTO meta VALUES (?,?)',(key,json.dumps(value,ensure_ascii=False)))
    def draws(self):
        with self.connect() as db: rows=db.execute('SELECT date,station,numbers FROM draws ORDER BY date,station').fetchall()
        return [dict(date=d,station=s,numbers=json.loads(n)) for d,s,n in rows]
    def keys(self):
        with self.connect() as db: return set(db.execute('SELECT date,station FROM draws').fetchall())
    def merge(self, rows):
        if any(not valid_draw(r) for r in rows): raise ValueError('Từ chối bảng không đủ giải hoặc sai định dạng')
        added=0
        with self.connect() as db:
            for r in rows:
                cursor=db.execute('INSERT OR IGNORE INTO draws VALUES (?,?,?,?)',(r['date'],r['station'],json.dumps(r['numbers']),'https://www.minhngoc.net.vn/'))
                added+=cursor.rowcount
        return added
    def save_forecast(self,snapshot):
        with self.connect() as db:
            result=db.execute('INSERT OR IGNORE INTO forecasts VALUES (?,?,?)',(snapshot['date'],snapshot['station'],json.dumps(snapshot,ensure_ascii=False)))
            return result.rowcount == 1
    def forecasts(self):
        with self.connect() as db: return [json.loads(r[0]) for r in db.execute('SELECT snapshot FROM forecasts ORDER BY date DESC,station')]
