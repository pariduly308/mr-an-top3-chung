"""Chỉ nhận bảng đủ từng hạng giải từ Minh Ngọc."""
import re
import time
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from .domain import PRIZES, valid_draw

class Node:
    def __init__(self,tag='',attrs=()):
        self.tag=tag; self.attrs=dict(attrs); self.children=[]
    def classes(self): return self.attrs.get('class','').split()
    def text(self): return ''.join(c.text() if isinstance(c,Node) else c for c in self.children)
    def walk(self):
        for c in self.children:
            if isinstance(c,Node):
                yield c
                yield from c.walk()

class Tree(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.root=Node(); self.stack=[self.root]
    def handle_starttag(self,tag,attrs):
        node=Node(tag,attrs);self.stack[-1].children.append(node)
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}: self.stack.append(node)
    def handle_startendtag(self,tag,attrs): self.stack[-1].children.append(Node(tag,attrs))
    def handle_endtag(self,tag):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==tag:
                del self.stack[i:];break
    def handle_data(self,data): self.stack[-1].children.append(data)

def parse(html,region):
    tree=Tree();tree.feed(html);result={}
    for block in tree.root.walk():
        if 'box_kqxs' not in block.classes(): continue
        titles=[n for n in block.walk() if 'title' in n.classes()]
        match=None
        for title in titles:
            for a in title.walk():
                match=re.search('/'+re.escape(region)+r'/(\d{2})-(\d{2})-(\d{4})\.html',a.attrs.get('href',''))
                if match:break
            if match:break
        if not match: continue
        day=f'{match[3]}-{match[2]}-{match[1]}'
        tables=[n for n in block.walk() if n.tag=='table' and 'rightcl' in n.classes()] if region=='mien-nam' else [block]
        for table in tables:
            if region=='mien-bac': station='XSMB'
            else:
                names=[n for n in table.walk() if 'tinh' in n.classes()]
                anchors=[a for n in names for a in n.walk() if a.tag=='a']
                if not anchors: continue
                station=anchors[0].text().strip()
            prizes={};bad=False
            for cell in table.walk():
                if cell.tag!='td':continue
                key=next((k for k in cell.classes() if k in PRIZES[region]),None)
                if not key:continue
                if key in prizes: bad=True;break
                numbers=[n.text().strip() for n in cell.walk() if n.tag=='div' and re.fullmatch(r'[0-9]{2,6}',n.text().strip())]
                count,width=PRIZES[region][key]
                if len(numbers)!=count or any(len(n)!=width for n in numbers):bad=True;break
                prizes[key]=numbers
            if bad or prizes.keys()!=PRIZES[region].keys():continue
            numbers=[n for key in PRIZES[region] for n in prizes[key]]
            row=dict(date=day,station=station,numbers=numbers)
            if valid_draw(row):result[(day,station)]=row
    return list(result.values())

def fetch(region,day,opener=urlopen):
    url='https://www.minhngoc.net.vn/ket-qua-xo-so/'+region+'/'+ '-'.join(reversed(day.split('-')))+'.html'
    error=None
    for attempt in range(2):
        try:
            request=Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; MrAnLocalStats/1.0)','Accept':'text/html'})
            with opener(request,timeout=15) as response:
                return parse(response.read(4_000_000).decode('utf-8',errors='replace'),region)
        except Exception as exc:
            error=exc
            if attempt==0:time.sleep(0.5)
    raise ConnectionError('Không lấy được '+region+' ngày '+day+' sau 2 lần: '+str(error)) from error
