import threading
import time
from .domain import now_vn, expected_keys, region_of
from .source import fetch
from .analysis import capture_forecasts

class SyncManager:
    def __init__(self,db,fetcher=fetch,clock=now_vn):
        self.db=db;self.fetcher=fetcher;self.clock=clock;self.lock=threading.Lock();self.state_lock=threading.Lock()
        self.stop_event=threading.Event()
        self.state=db.meta('sync_status',{'lastCheck':None,'errors':[]})
        self.state['inProgress']=False
    def status(self):
        with self.state_lock:return dict(self.state)
    def publish(self,**changes):
        with self.state_lock:self.state.update(changes);current=dict(self.state)
        self.db.set_meta('sync_status',current)
    def missing(self,now):
        return set(expected_keys(self.db.meta('start_date',now.date().isoformat()),now))-self.db.keys()
    def start(self):
        if not self.lock.acquire(blocking=False):return False
        threading.Thread(target=self.run,daemon=True).start();return True
    def run(self):
        now=self.clock();errors=[];added=0;pages=0
        try:
            missing=self.missing(now)
            self.publish(inProgress=True,lastCheck=now.isoformat(),errors=[],added=0,remaining=len(missing),pages=0,message='Đang tìm các kỳ còn thiếu…')
            # Trang ngày mới thường kèm nhiều ngày trước, lấy mới trước giúp bù nhiều kỳ trong một lần.
            tasks=sorted({(d,region_of(s)) for d,s in missing},reverse=True)
            consecutive_failures=0
            for day,region in tasks:
                if self.stop_event.is_set():break
                pending=[(d,s) for d,s in missing if d==day and region_of(s)==region]
                if not pending:continue
                self.publish(message='Đang lấy '+region+' · '+day)
                try:
                    rows=self.fetcher(region,day)
                    rows=[r for r in rows if self.db.meta('start_date')<=r['date']<=now.date().isoformat()]
                    added+=self.db.merge(rows);pages+=1;consecutive_failures=0
                    missing=self.missing(now)
                    self.publish(added=added,pages=pages,remaining=len(missing))
                except Exception as exc:
                    errors.append(str(exc));consecutive_failures+=1
                    if consecutive_failures>=2:break
                if self.stop_event.wait(0.3):break
            missing=self.missing(now)
            forecasts=capture_forecasts(self.db,self.clock())
            draws=self.db.draws()
            message=('Còn '+str(len(missing))+' kỳ chưa có bảng đủ giải; sẽ thử lại lần sau.') if missing else 'Đã bù đủ các kỳ đến hạn.'
            if errors:message='Chưa cập nhật xong. Vẫn dùng dữ liệu đã lưu; lần sau sẽ thử lại.'
            self.publish(inProgress=False,lastFinished=self.clock().isoformat(),errors=errors[:20],remaining=len(missing),missingSample=[{'date':d,'station':s} for d,s in sorted(missing,reverse=True)[:50]],added=added,pages=pages,forecastsSaved=forecasts,latestDate=draws[-1]['date'] if draws else None,message=message)
        except Exception as exc:
            self.publish(inProgress=False,errors=[str(exc)],message='Cập nhật lỗi. Dữ liệu đã lưu được giữ nguyên.')
        finally:self.lock.release()
    def periodic(self):
        while not self.stop_event.wait(600):self.start()
