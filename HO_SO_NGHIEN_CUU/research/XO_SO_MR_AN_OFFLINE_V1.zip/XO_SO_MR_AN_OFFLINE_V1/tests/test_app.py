import copy
import json
import re
import tempfile
import threading
import unittest
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from modules.database import Database
from modules.domain import VN, expected_keys, valid_draw
from modules.source import parse, fetch
from modules.sync import SyncManager
from modules.analysis import capture_forecasts, tracking_report, rank
from app import create_server

ROOT=Path(__file__).resolve().parent.parent
SOUTH=(ROOT/'tests/fixtures/south.html').read_text()
NORTH=(ROOT/'tests/fixtures/north.html').read_text()
ROWS=parse(SOUTH,'mien-nam')+parse(NORTH,'mien-bac')

class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.db=Database(Path(self.tmp.name)/'data.db');self.db.seed(ROOT/'seed.json')
    def tearDown(self):self.tmp.cleanup()
    def run_sync(self,fetcher,now):
        manager=SyncManager(self.db,fetcher=fetcher,clock=lambda:now)
        manager.lock.acquire();manager.run();return manager.status()
    def test_real_source_and_complete_seed(self):
        self.assertEqual(len(parse(SOUTH,'mien-nam')),22)
        self.assertEqual(len(parse(NORTH,'mien-bac')),7)
        self.assertTrue(all(valid_draw(r) for r in ROWS))
        self.assertEqual(len(self.db.draws()),7545)
        self.assertFalse(set(expected_keys('2021-11-10',datetime(2026,11,10,9,tzinfo=VN)))-self.db.keys())
    def test_partial_prize_and_wrong_width_rejected(self):
        broken=SOUTH.replace('class="giai8"','class="missing"')
        keys={(r['date'],r['station']) for r in parse(broken,'mien-nam')}
        self.assertNotIn(('2026-11-10','Bến Tre'),keys)
        row=next(r for r in ROWS if r['date']=='2026-11-10' and r['station']=='Bến Tre')
        row=copy.deepcopy(row);row['numbers'][0]='999'
        count=len(self.db.draws())
        with self.assertRaises(ValueError):self.db.merge([row])
        self.assertEqual(len(self.db.draws()),count)
    def test_merge_station_same_day_and_idempotence(self):
        rows=[r for r in ROWS if r['date']=='2026-11-10']
        self.assertEqual(self.db.merge(rows[:1]),1)
        self.assertEqual(self.db.merge(rows),3)
        self.assertEqual(self.db.merge(rows),0)
        self.assertEqual(len(self.db.keys()),7549)
    def test_find_old_hole_and_backfill_many_days(self):
        all_rows=self.db.draws()+[r for r in ROWS if r['date']=='2026-11-10']
        with self.db.connect() as c:
            c.execute("DELETE FROM draws WHERE date>='2026-11-01'")
            c.execute("DELETE FROM draws WHERE date='2024-06-07' AND station='Vĩnh Long'")
        calls=[]
        def get(region,day):
            calls.append((region,day))
            return [r for r in all_rows if r['date']<=day and r['date']>=('2026-11-01' if day>='2026-11-01' else day) and (r['station']=='XSMB')==(region=='mien-bac')]
        status=self.run_sync(get,datetime(2026,11,10,20,tzinfo=VN))
        self.assertEqual(status['remaining'],0);self.assertFalse(status['errors']);self.assertEqual(len(self.db.draws()),7549)
        self.assertLess(len(calls),10)
        # Lần mở sau không tải lại lịch sử đã đủ.
        before=len(calls);self.run_sync(get,datetime(2026,11,10,20,tzinfo=VN));self.assertEqual(before,len(calls))
    def test_network_retry_and_offline_preserves_database(self):
        attempts=[]
        def offline(*a,**kw):attempts.append(1);raise OSError('Offline test')
        with self.assertRaises(ConnectionError):fetch('mien-bac','2026-11-10',opener=offline)
        self.assertEqual(len(attempts),2)
        before=self.db.draws();status=self.run_sync(lambda *a:offline(),datetime(2026,11,10,20,tzinfo=VN))
        self.assertEqual(self.db.draws(),before);self.assertTrue(status['errors']);self.assertEqual(status['remaining'],4)
    def test_forecasts_cutoff_immutable_and_scored(self):
        saved=capture_forecasts(self.db,datetime(2026,11,10,2,tzinfo=timezone.utc))
        self.assertEqual(len(saved),4)
        before=self.db.forecasts()
        self.assertEqual(capture_forecasts(self.db,datetime(2026,11,10,10,tzinfo=VN)),[])
        self.assertEqual(before,self.db.forecasts())
        self.assertTrue(all(not s['complete'] for s in tracking_report(self.db)))
        self.db.merge([r for r in ROWS if r['date']=='2026-11-10'])
        for s in tracking_report(self.db):
            self.assertTrue(s['complete'])
            actual=next(r for r in ROWS if r['date']==s['date'] and r['station']==s['station'])
            for digits in (2,3):
                for method,top in s['predictions'][str(digits)].items():
                    self.assertEqual(s['scores'][str(digits)][method],[n for n in top if n in {x[-digits:] for x in actual['numbers'] if len(x)>=digits}])
        with self.db.connect() as c:c.execute('DELETE FROM forecasts')
        self.assertEqual(capture_forecasts(self.db,datetime(2026,11,10,19,tzinfo=VN)),[])
    def test_leading_zero_and_count_vs_multiple_appearances(self):
        rows=[r for r in self.db.draws() if r['station']=='XSMB'][-100:]
        ranked=rank(rows,3)
        self.assertTrue(all(len(r['number'])==3 for r in ranked))
        for r in rank(rows,2):
            counts=[sum(n[-2:]==r['number'] for n in row['numbers']) for row in rows]
            self.assertEqual(r['hits'],sum(c>0 for c in counts));self.assertEqual(r['total'],sum(counts))
    def test_local_http_offline_and_csrf(self):
        manager=SyncManager(self.db);server=create_server(self.db,manager,0)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_port}'
        try:
            with urlopen(base) as r:page=r.read().decode()
            self.assertNotIn('__LOCAL_TOKEN__',page);self.assertNotIn('__HOLIDAYS__',page);self.assertNotIn('/*UI*/',page)
            with urlopen(base+'/analysis-worker.js') as r:self.assertIn('onmessage=',r.read().decode())
            with urlopen(base+'/data.json') as r:self.assertEqual(len(json.load(r)),7545)
            with self.assertRaises(HTTPError) as error:urlopen(Request(base+'/api/update',method='POST'))
            self.assertEqual(error.exception.code,403)
            with self.assertRaises(HTTPError) as error:urlopen(Request(base+'/api/status',headers={'Host':'evil.test'}))
            self.assertEqual(error.exception.code,403)
            token=re.search("'X-Local-Token':'([^']+)'",page)[1]
            with urlopen(Request(base+'/api/forecast',method='POST',headers={'X-Local-Token':token})) as r:self.assertEqual(r.status,200)
        finally:server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main()
