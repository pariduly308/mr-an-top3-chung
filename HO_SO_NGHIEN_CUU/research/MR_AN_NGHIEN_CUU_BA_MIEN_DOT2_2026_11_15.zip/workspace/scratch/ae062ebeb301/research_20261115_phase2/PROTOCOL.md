# Đợt tiếp theo — định trước 15/11/2026
Hồi cứu trên dữ liệu thật đã lưu, cùng đích10/11/2021–11/11/2026, không phải tươnglai. Kế thừa lịchMN/MT (ĐàNẵngT4riêng),MTloại3đài và kiểmtoán thiếu. Không sửa sảnphẩm/lịch/bảnkhóa. Mỗi giađình dướiđây chỉ kiểmtra biếnthể địnhnghĩa,không tuyên bố thửmọicách.
## NN
RNNtanh vàLSTM PyTorch,1lớp hidden8,chuỗi8bảng trướcđích,đầu vào vector đếmđãchặn3/chia3,output100/1000logits. Mỗi miền/chếđộ riêng,chuỗi ngày;3năm huấnluyện trước10/11hằngnăm;180ngày cuối3năm làmvalidation nội bộ, chọncheckpoint BCE tốt nhất trong12epochs. Adam lr.003,batch64,weight_decay.001,seed15112026;BCEWithLogitsLoss khôngclassweight. Toàn bộtrain/validation trước đích;validation khôngphải testnămđích. 12cấu hình(NN2×3miền×2chếđộ),72lầnfitnăm;12checkpoint mỗi fit là lựa chọn nội bộ,ghi đầyđủloss. Không điều chỉnh kiếntrúc sau xemtest.
## GA
Hỗnhợp6scores thứhạng của6côngthức gốc với lịch sử3năm chuỗi ngày. Population12,8thếhệ,top4elitism,crossover trungbình,mutationGaussian sd.15,chuẩn hóaL1,trọngsố cóthểâm;seed cốđịnh. Fitness tỷlệTop3đúng trên validation365ngày trước mốc10/11, không dùngtest. Mỗi cáthể tínhtrên Top20 của6côngthức vàsáu thứhạng đảo (để hạnchếCPU); dựbáo sau cũng dùng cùngtậpứngviên. Tốiđa96fitness/year/region/digits,ghi mọi weights/fitness; không coi là96phépkiểmtra độc lập.6cấu hình,36fit. Không tuyênbố tìm mọi bộsố tốiưu.
## Pattern/rules
Mỗi miền 2/3số chuỗi ngày,5năm lịch sử:
- bacnho_pair: chỉmộtcặp kíchhoạt địnhtrước gồm2đuôi nhỏnhất khácnhau của kỳtrước. Tìm các cặpkỳ lịch sử cócả2 số vàhọc hiệndiện kỳsau;prior20về tầnsuất; min10lầnkíchhoạt,nếu thiếu dùngfrequency. Không quét hết cặp để chọn thắng.
- dynamic_positions: 12mẫu vịtrí cốđịnh trên chuỗi2giải cuối (danh sách trongcode), chọnmẫu có tỷlệhitcao nhất50chuyểntiếp trướcđích, hòa thứtựmẫu; lấy3mẫuđứngđầu,khửtrùng,bổsungfrequency. Chấmquytrìnhchọnmẫu,không chọnmẫu sau thấyđích.
- triangle/diamond: từ3giải cuối của kỳtrước,canhphải,quét tamgiácA/B/A vàquảtrám3hàng theo địnhnghĩacode; khiđủmẫu cho điểm đuôi2AB/BA,đuôi3ABA/BAB;hòa frequency,bổsungfrequency đủ3. Đây là biếnthể hìnhhọc xácđịnh,khôngchuẩn chung dân gian.
- lunar_day: cùngngàyâmlịch ViệtNam (timezone+7),5năm trướcđích,prior20 tầnsuất; khôngdùng lịchTrungQuốc thaylịchViệtNam. Chỉchạy nếu thưviện trả lịchVN kiểmtra được; nếu không ghi bịchặn.
- weekday: cùngthứ,5năm;đối chiếu để khôngnhầm lịchtỉnh là tínhiệu thứ.
Tốiđa36cấu hình6rules×3miền×2chếđộ.
## Bổ sung ML
5môhình cổđiển đợttrước giữ nguyêntham số,thêm3số vàcửa sổ1/5năm;3năm2số cósẵn. Thực hiện theo chuỗi ngày;không đồngnghĩa đã học toàn bộmôhình riêng mỗiđài.
## Đánhgiá
CùngTop3,kỳđích,sốgiải;đốichứngpairrepeatMN/frequencyMT/MB1/3/5năm. ĐàNẵngT4táchriêng. McNemarexact+Holm trongđợt;CIghépcặp block7,1000lần. Thốngkê năm/đích lưuđầyđủ. NN Brier tínhbìnhquân mỗi kỳ,kèm baseline hiệndiện đồngđều theo sốgiải;không lấy1000số thành1000kỳ. Chọnmôhình mới chỉ làthămdò trênlịchsử đãxem.
Sổmơ khôngcóinputghi trước,khôngthể backtest hợp lệ. Martingale khônglàm tăngxácsuấtsố,phân tíchcấp sốnhân riêng khôngtrộnthànhtích Top3. Kiểmtra âm tính thêm phải ghiđịnhnghĩa;không gọi xoay nhãn sau huấnluyện là refit toànpipeline.

### Giới hạn tính toán ML mở rộng, định trước trước chạy
Chạy lại thống nhất1/3/5năm train cho cả2/3số; mỗi fit lấy tối đa20.000hàng số-ngày train bằng RNG15112026, không oversample, không chọn theo kếtquả. Đây là môhình có lấy mẫu huấnluyện khácđợt1;90cấu hình miền×digits×window×model,540fits năm. Mỗi kỳ vẫn dựbáo đủ100/1000số và chỉ chọn3. Cửa sổ là thời gian train trọngsố;feature frequency20/50/100ngày giữcốđịnh. Chưa triểnkhai mỗi môhình riêngtừngđài;không gọi thử mọi cấu hình. Không dùng subsampling để coi hàng số là kỳ độc lập khi chấm.
