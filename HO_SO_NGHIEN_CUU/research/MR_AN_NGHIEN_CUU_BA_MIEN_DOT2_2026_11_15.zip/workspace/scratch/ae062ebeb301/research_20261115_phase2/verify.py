from common import *
import torch,pandas as pd
from torch import nn
torch.set_num_threads(1)
class Model(nn.Module):
 def __init__(self,N,kind):
  super().__init__();self.r=(nn.LSTM if kind=='lstm' else nn.RNN)(N,8,batch_first=True);self.head=nn.Linear(8,N)
 def forward(self,x):return self.head(self.r(x)[0][:,-1])
df=pd.read_csv(P/'neural.csv',dtype={'top3':str});checked=0
for region in ['MN','MT','MB']:
 for k in [2,3]:
  ds,dates,c,h=dataset(region,k);N=10**k
  for year in range(2021,2027):
   for kind in ['rnn','lstm']:
    m=Model(N,kind);m.load_state_dict(torch.load(P/'checkpoints'/f'{region}_{k}_{kind}_{year}.pt',weights_only=True));m.eval()
    z=df[(df.region==region)&(df.digits==k)&(df.candidate==kind)&(df.date>=f'{year}-11-10')&(df.date<f'{year+1}-11-10')]
    for _,r in z.iloc[[0,-1]].iterrows():
     i=int(np.searchsorted(dates,r.date));assert all(dates[i-8:i]<r.date);x=torch.tensor(np.minimum(c[i-8:i],3).astype(np.float32)/3)[None]
     with torch.no_grad():p=torch.sigmoid(m(x)).numpy()[0]
     top=np.lexsort((np.arange(N),-p))[:3];assert ' '.join(str(v).zfill(k) for v in top)==r.top3
     assert int(h[i,top].any())==r.hit;checked+=1
for f in ['neural','ga','patterns','ml_all']:
 z=pd.read_csv(P/f'{f}.csv',dtype={'top3':str});assert not z.duplicated(['region','date','target','digits','candidate']).any();assert all(len(set(s.split()))==3 for s in z.top3)
(P/'verification.json').write_text(json.dumps({'neural_checkpoint_replays':checked,'exact_top3_hit':True,'all_prediction_files_unique_keys_three_distinct':True,'limitations':'No independent implementation of full neural training or GA; no full historical source re-audit'}))
print('verified',checked)
