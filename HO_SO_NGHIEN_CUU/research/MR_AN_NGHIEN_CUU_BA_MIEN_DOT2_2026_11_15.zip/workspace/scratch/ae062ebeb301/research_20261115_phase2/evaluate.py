from pathlib import Path
import pandas as pd,numpy as np,json
from scipy.stats import binomtest
P=Path(__file__).parent;frames=[pd.read_csv(P/f'{name}.csv') for name in ['neural','ga','patterns','ml_all']];new=pd.concat(frames,ignore_index=True);old=pd.read_csv('research_20261115/predictions.csv');rng=np.random.default_rng(15112026);results=[];tests=[]
for region in ['MN','MT','MB']:
 method='repeat' if region=='MN' else 'frequency'
 for k in [2,3]:
  for scope in (['pair','single'] if region=='MT' else ['all']):
   base=old[(old.region==region)&(old.digits==k)&(old['mode']=='pair')&(old.method==method)]
   z=new[(new.region==region)&(new.digits==k)]
   if scope!='all':
    base=base[base.target.str.contains(' \\+ ') if scope=='pair' else ~base.target.str.contains(' \\+ ')];z=z[z.target.str.contains(' \\+ ') if scope=='pair' else ~z.target.str.contains(' \\+ ')]
   for name,g in z.groupby('candidate'):
    for y in [1,3,5]:
     m=g.merge(base[base.years==y][['date','hit','uniform']],on='date',suffixes=('_a','_b'),validate='one_to_one').sort_values('date');a=m.hit_a.to_numpy();b=m.hit_b.to_numpy();delta=a-b;n=len(m);win=int(((a==1)&(b==0)).sum());loss=int(((a==0)&(b==1)).sum());p=binomtest(win,win+loss,.5).pvalue if win+loss else 1
     r=dict(region=region,digits=k,scope=scope,candidate=name,baseline_years=y,n=n,rate=float(a.mean()),baseline=float(b.mean()),uniform=float(m.uniform.mean()),delta=float(delta.mean()),p=float(p));tests.append(r)
     if y==5:
      boot=[]
      for _ in range(1000):ix=((rng.integers(0,n,(n+6)//7)[:,None]+np.arange(7))%n).ravel()[:n];boot.append(delta[ix].mean())
      r['ci95']=np.quantile(boot,[.025,.975]).tolist()
      if name in ['rnn','lstm']:r['brier']=float(m.brier.mean());r['brier_uniform']=float(m.brier_uniform.mean())
      results.append(r)
alltests=json.load(open('research_20261115/holm_all.json'))+tests;order=np.argsort([r['p'] for r in alltests]);prev=0
for j,i in enumerate(order):prev=max(prev,min(1,alltests[i]['p']*(len(alltests)-j)));alltests[i]['holm_combined']=prev
(P/'all_tests_combined.json').write_text(json.dumps(alltests,indent=2));(P/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));new.groupby(['region','target','digits','candidate',new.date.str[:4]]).hit.agg(['sum','count','mean']).to_csv(P/'by_year_target.csv')
print('rows',len(new),'new configs',len(new[['region','digits','candidate']].drop_duplicates()),'total tests',len(alltests),'positive sig',sum(r['delta']>0 and r['holm_combined']<.05 for r in alltests))
for r in results:
 if r['digits']==2 and r['candidate'] in ['rnn','lstm','ga_rankblend']:print(r)
(P/'run_summary.json').write_text(json.dumps({'rows':len(new),'by_family':{n:len(f) for n,f in zip(['neural','ga','patterns','ml_all'],frames)},'new_configurations':len(new[['region','digits','candidate']].drop_duplicates()),'combined_tests':len(alltests),'positive_significant':sum(r['delta']>0 and r['holm_combined']<.05 for r in alltests)},indent=2))
