import json,datetime,collections
from pathlib import Path
import numpy as np
P=Path(__file__).parent
sources=['research_20261115/sources/mn_mb.json','research_20261115/sources/mt.json']
rows=sum([json.load(open(f)) for f in sources],[]);by=collections.defaultdict(dict)
for r in rows:by[r['date']][r['station']]=r['numbers']
MN=[['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An'],['Tiền Giang','Kiên Giang']]
MT=[['Huế','Phú Yên'],['Đắk Lắk','Quảng Nam'],['Đà Nẵng'],['Bình Định','Quảng Trị'],['Gia Lai','Ninh Thuận'],['Đà Nẵng','Quảng Ngãi'],['Huế','Kon Tum']]
def dataset(region,k):
 sch={'MN':MN,'MT':MT,'MB':[['XSMB']]*7}[region];ds=[]
 for d,g in sorted(by.items()):
  ss=sch[datetime.date.fromisoformat(d).weekday()]
  if d<='2026-11-11' and all(s in g for s in ss):ds.append((d,' + '.join(ss),sum([g[s] for s in ss],[])))
 N=10**k;c=np.zeros((len(ds),N),np.int16)
 for i,(d,s,ns) in enumerate(ds):
  for v in ns:
   if len(v)>=k:c[i,int(v[-k:])]+=1
 return ds,np.array([r[0] for r in ds]),c,c>0
