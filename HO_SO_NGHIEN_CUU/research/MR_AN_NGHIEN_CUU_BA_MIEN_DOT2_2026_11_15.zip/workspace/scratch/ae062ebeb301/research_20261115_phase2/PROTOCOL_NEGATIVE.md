# Chẩn đoán âm tính sau đã xem kết quả
99hoánvị cho từng bộ dựbáo cốđịnh; hoánvị nguyên bảng kếtquả trong cùngđài/cặp vàcùngnăm, giữ sốgiải và số0. Không huấnluyện lại môhình và không chạy lại lựachọnGA; vìvậy chỉ diagnostic, không là kiểmđịnh toànpipeline hoặc p-value chứngminhlợithế. Ghi rõ kếtquả đã xem trước bước này.
