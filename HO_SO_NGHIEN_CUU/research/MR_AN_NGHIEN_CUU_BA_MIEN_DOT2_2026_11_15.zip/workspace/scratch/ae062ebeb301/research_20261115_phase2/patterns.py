from common import *
import csv,vnlunar
assert vnlunar.get_lunar_date(29,1,2025,time_zone=7)["day"]==1
assert vnlunar.get_lunar_date(17,2,2026,time_zone=7)["day"]==1
# Twelve fixed position templates, not selected after test results.
templates=[(0,1),(0,2),(0,3),(0,4),(0,5),(1,2),(1,3),(1,4),(1,5),(2,3),(2,4),(2,5)]
def positions(ns,k):
 s=ns[-1]+ns[-2];return np.array([int(s[a%len(s)]+s[b%len(s)]+(s[(a+b)%len(s)] if k==3 else '')) for a,b in templates])
with (P/'patterns.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['region','date','target','digits','candidate','top3','hit','distinct'])
 for region in ['MN','MT','MB']:
  for k in [2,3]:
   ds,dates,c,h=dataset(region,k);N=10**k;nums=np.arange(N);pref=np.vstack([np.zeros((1,N)),np.cumsum(h,axis=0)]);pos=np.array([positions(ns,k) for d,s,ns in ds]);ph=h[np.arange(1,len(ds))[:,None],pos[:-1]];pp=np.vstack([np.zeros((1,12)),np.cumsum(ph,axis=0)])
   lunar=np.array([vnlunar.get_lunar_date(int(d[8:]),int(d[5:7]),int(d[:4]),time_zone=7)["day"] for d in dates]);week=np.array([datetime.date.fromisoformat(d).weekday() for d in dates])
   for i,(d,s,ns) in enumerate(ds):
    if d<'2021-11-10':continue
    try:lower=datetime.date.fromisoformat(d).replace(year=int(d[:4])-5).isoformat()
    except ValueError:lower=str(int(d[:4])-5)+'-03-01'
    lo=int(np.searchsorted(dates,lower));hits=pref[i]-pref[lo];prior=(hits+1)/(i-lo+2);freq=np.lexsort((nums,-hits));scores={}
    active=np.flatnonzero(h[i-1])[:2];match=np.all(h[lo:i-1,active],axis=1) if len(active)==2 else np.zeros(i-1-lo,bool)
    scores['bacnho_pair']=(h[lo+1:i][match].sum(axis=0)+20*prior)/(match.sum()+20) if match.sum()>=10 else prior
    for name,mask in [('lunar_day',lunar[lo:i]==lunar[i]),('weekday',week[lo:i]==week[i])]:scores[name]=(h[lo:i][mask].sum(axis=0)+20*prior)/(mask.sum()+20)
    order=np.argsort(-(pp[i-1]-pp[max(0,i-51)]),kind='stable');chosen=list(dict.fromkeys(list(pos[i-1,order[:3]])+list(freq)))[:3]
    out={'dynamic_positions':chosen}
    strings=[v.rjust(max(map(len,ds[i-1][2][-3:]))) for v in ds[i-1][2][-3:]]
    for kind in ['triangle','diamond']:
     score=np.zeros(N)
     for j in range(1,len(strings[0])-1):
      a,b=strings[0][j],strings[1][j-1]
      ok=a.isdigit() and b.isdigit() and strings[2][j]==a
      if kind=='diamond':ok=ok and strings[1][j+1]==b
      if ok:
       for v in ([a+b,b+a] if k==2 else [a+b+a,b+a+b]):score[int(v)]+=1
     out[kind]=np.lexsort((nums,-hits,-score))[:3]
    out.update({name:np.lexsort((nums,-sc))[:3] for name,sc in scores.items()})
    for name,top in out.items():
     assert len(set(top))==3
     n=int(h[i,top].sum());w.writerow([region,d,s,k,name,' '.join(str(v).zfill(k) for v in top),int(n>0),n])
   print('PATTERN',region,k,'done',flush=True)
(P/'lunar_checks.json').write_text(json.dumps({'library':'vnlunar','version':vnlunar.__version__,'timezone':7,'checks':['2025-01-29 = 1/1/2025','2026-02-17 = 1/1/2026'],'limitation':'two anchor checks only; no independent audit of all lunar dates'}))
