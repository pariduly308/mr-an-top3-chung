from common import *
import csv
trace=[]
with (P/'ga.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['region','date','target','digits','candidate','top3','hit','distinct'])
 for region in ['MN','MT','MB']:
  for k in [2,3]:
   ds,dates,c,h=dataset(region,k);N=10**k;nums=np.arange(N);pref=np.vstack([np.zeros((1,N)),np.cumsum(h,axis=0)]);last=np.full(N,-1);features=[];candidates=[]
   for i,(d,s,ns) in enumerate(ds):
    try:loD=datetime.date.fromisoformat(d).replace(year=int(d[:4])-3).isoformat()
    except ValueError:loD=str(int(d[:4])-3)+'-03-01'
    lo=int(np.searchsorted(dates,loD));hits=pref[i]-pref[lo];gap=np.where(last>=lo,i-last-1,i-lo)
    sc=[hits,*[pref[i]-pref[max(lo,i-n)] for n in [10,20,50]],hits*np.minimum(gap,20)/20,c[i-1] if i else np.zeros(N)]
    order=[np.lexsort((nums,-hits,-v)) for v in sc];cand=np.unique(np.concatenate([np.r_[o[:20],o[-20:]] for o in order]));rr=[]
    for o in order:
     rank=np.empty(N);rank[o]=1-np.arange(N)/(N-1);rr.append(rank[cand])
    candidates.append(cand);features.append(np.array(rr).T.astype(np.float32));last[h[i]]=i
   for year in range(2021,2027):
    start=f'{year}-11-10';end=f'{year+1}-11-10';vl=(datetime.date.fromisoformat(start)-datetime.timedelta(days=365)).isoformat();train=np.flatnonzero((dates>=vl)&(dates<start));test=np.flatnonzero((dates>=start)&(dates<end));rng=np.random.default_rng(15112026)
    width=max(len(candidates[i]) for i in train);F=np.zeros((len(train),width,6),np.float32);valid=np.zeros((len(train),width),bool);truth=np.zeros_like(valid)
    for j,i in enumerate(train):n=len(candidates[i]);F[j,:n]=features[i];valid[j,:n]=True;truth[j,:n]=h[i,candidates[i]]
    pop=rng.normal(size=(12,6));pop/=np.abs(pop).sum(axis=1)[:,None];best=None;bf=-1
    for gen in range(8):
     fitness=[]
     for weight in pop:
      scores=np.einsum('ijk,k->ij',F,weight);scores[~valid]=-np.inf;top=np.argsort(-scores,axis=1,kind='stable')[:,:3];fit=float(np.take_along_axis(truth,top,axis=1).any(axis=1).mean());fitness.append(fit)
      trace.append(dict(region=region,digits=k,year=year,generation=gen,weights=weight.tolist(),fitness=fit))
      if fit>bf:bf=fit;best=weight.copy()
     elite=pop[np.argsort(-np.array(fitness),kind='stable')[:4]];children=[]
     for _ in range(8):
      child=(elite[rng.integers(4)]+elite[rng.integers(4)])/2+rng.normal(0,.15,6);child/=np.abs(child).sum();children.append(child)
     pop=np.vstack([elite,children])
    for i in test:
     score=features[i]@best;top=candidates[i][np.argsort(-score,kind='stable')[:3]];n=int(h[i,top].sum());w.writerow([region,ds[i][0],ds[i][1],k,'ga_rankblend',' '.join(str(v).zfill(k) for v in top),int(n>0),n])
   print('GA',region,k,'done',flush=True)
(P/'ga_search.json').write_text(json.dumps(trace))
