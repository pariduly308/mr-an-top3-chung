from common import *
import csv
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression,Ridge
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
logs=[]
with (P/'ml_all.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['region','date','target','digits','candidate','top3','hit','distinct'])
 for region in ['MN','MT','MB']:
  for k in [2,3]:
   ds,dates,c,h=dataset(region,k);N=10**k;prefix=np.vstack([np.zeros((1,N)),np.cumsum(h,axis=0)]);last=np.full(N,-1);X=[]
   for i,(d,s,ns) in enumerate(ds):
    freq=[(prefix[i]-prefix[max(0,i-v)])/max(1,min(i,v)) for v in [20,50,100]];day=datetime.date.fromisoformat(d).weekday();opp=(27 if k==2 else 23) if region=='MB' else (18 if k==2 else 17)*(1 if s=='Đà Nẵng' else 2)
    X.append(np.array([*freq,np.minimum(i-last-1,100)/100,c[i-1]/36 if i else np.zeros(N),np.mean(c[max(0,i-5):i]>1,axis=0) if i else np.zeros(N),np.full(N,min(i/365,1)),np.full(N,opp/36),np.arange(N)/(N-1),np.full(N,np.sin(day*2*np.pi/7)),np.full(N,np.cos(day*2*np.pi/7))],dtype=np.float32).T);last[h[i]]=i
   X=np.array(X)
   for years in [1,3,5]:
    for year in range(2021,2027):
     start=f'{year}-11-10';end=f'{year+1}-11-10';lo=f'{year-years}-11-10';tr=np.flatnonzero((dates>=lo)&(dates<start));te=np.flatnonzero((dates>=start)&(dates<end));rng=np.random.default_rng(15112026);flat=rng.choice(len(tr)*N,min(20000,len(tr)*N),replace=False);xx=X[tr[flat//N],flat%N];yy=h[tr[flat//N],flat%N];sc=StandardScaler().fit(xx);xx=sc.transform(xx);tt=sc.transform(X[te].reshape(-1,X.shape[-1]));models={'logistic':LogisticRegression(C=1,max_iter=200),'ridge':Ridge(alpha=100),'svm_linear':LinearSVC(C=.01,dual=False,max_iter=2000),'tree':DecisionTreeClassifier(max_depth=4,min_samples_leaf=200,random_state=15112026),'forest':RandomForestClassifier(n_estimators=40,max_depth=5,min_samples_leaf=200,n_jobs=1,random_state=15112026)}
     for name,m in models.items():
      m.fit(xx,yy);score=m.predict_proba(tt)[:,1] if hasattr(m,'predict_proba') else m.decision_function(tt) if hasattr(m,'decision_function') else m.predict(tt)
      for i,scores in zip(te,score.reshape(-1,N)):
       top=np.lexsort((np.arange(N),-scores))[:3];n=int(h[i,top].sum());w.writerow([region,ds[i][0],ds[i][1],k,f'{name}_train{years}y_sample20k',' '.join(str(v).zfill(k) for v in top),int(n>0),n])
     logs.append(dict(region=region,digits=k,years=years,fit_year=year,training_days=len(tr),sample_rows=len(flat),test_days=len(te)))
    print('ML full',region,k,years,'done',flush=True)
(P/'ml_sampling.json').write_text(json.dumps(logs))
