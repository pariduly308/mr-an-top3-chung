from common import *
import torch,csv,copy
from torch import nn
torch.set_num_threads(1);torch.manual_seed(15112026);np.random.seed(15112026)
class Model(nn.Module):
 def __init__(self,N,kind):
  super().__init__();self.r=(nn.LSTM if kind=='lstm' else nn.RNN)(N,8,batch_first=True);self.head=nn.Linear(8,N)
 def forward(self,x):return self.head(self.r(x)[0][:,-1])
logs=[];(P/'checkpoints').mkdir(exist_ok=True)
with (P/'neural.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['region','date','target','digits','candidate','top3','hit','distinct','brier','brier_uniform'])
 for region in ['MN','MT','MB']:
  for k in [2,3]:
   ds,dates,c,h=dataset(region,k);N=10**k;x=np.minimum(c,3).astype(np.float32)/3
   seq=np.stack([x[i-8:i] for i in range(8,len(ds))]);X=torch.from_numpy(seq);Y=torch.from_numpy(h[8:].astype(np.float32));dates2=dates[8:]
   for year in range(2021,2027):
    start=f'{year}-11-10';end=f'{year+1}-11-10';lo=f'{year-3}-11-10';val=(datetime.date.fromisoformat(start)-datetime.timedelta(days=180)).isoformat()
    ti=np.flatnonzero((dates2>=lo)&(dates2<val));vi=np.flatnonzero((dates2>=val)&(dates2<start));te=np.flatnonzero((dates2>=start)&(dates2<end))
    for kind in ['rnn','lstm']:
     torch.manual_seed(15112026);m=Model(N,kind);opt=torch.optim.Adam(m.parameters(),lr=.003,weight_decay=.001);lossfn=nn.BCEWithLogitsLoss();best=float('inf');state=None;trace=[]
     for epoch in range(12):
      m.train();order=np.random.default_rng(15112026+epoch).permutation(ti)
      for off in range(0,len(order),64):
       idx=order[off:off+64];opt.zero_grad();loss=lossfn(m(X[idx]),Y[idx]);loss.backward();opt.step()
      m.eval()
      with torch.no_grad():vl=float(lossfn(m(X[vi]),Y[vi]))
      trace.append(vl)
      if vl<best:best=vl;state=copy.deepcopy(m.state_dict())
     m.load_state_dict(state);torch.save(state,P/'checkpoints'/f'{region}_{k}_{kind}_{year}.pt');m.eval()
     with torch.no_grad():pred=torch.sigmoid(m(X[te])).numpy()
     for j,p in zip(te,pred):
      i=j+8;top=np.lexsort((np.arange(N),-p))[:3];distinct=int(h[i,top].sum());opp=(27 if k==2 else 23) if region=='MB' else (18 if k==2 else 17)*(1 if ds[i][1]=='Đà Nẵng' else 2);base=1-(1-1/N)**opp
      w.writerow([region,ds[i][0],ds[i][1],k,kind,' '.join(str(v).zfill(k) for v in top),int(distinct>0),distinct,float(np.mean((p-h[i])**2)),float(np.mean((base-h[i])**2))])
     logs.append(dict(region=region,digits=k,year=year,model=kind,train=len(ti),validation=len(vi),test=len(te),validation_loss=trace,selected_epoch=int(np.argmin(trace))+1))
    print('NN',region,k,year,'done',flush=True)
(P/'neural_training.json').write_text(json.dumps(logs,indent=2))
