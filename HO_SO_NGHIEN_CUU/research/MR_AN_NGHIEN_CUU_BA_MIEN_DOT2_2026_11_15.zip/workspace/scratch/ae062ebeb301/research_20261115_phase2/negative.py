from common import *
import pandas as pd
rng=np.random.default_rng(15112026);out=[]
new=pd.concat([pd.read_csv(P/f'{x}.csv',dtype={'top3':str}) for x in ['neural','ga','patterns','ml_all']])
for region in ['MN','MT','MB']:
 for k in [2,3]:
  ds,dates,c,h=dataset(region,k);lookup={d:i for i,d in enumerate(dates)}
  z=new[(new.region==region)&(new.digits==k)]
  for name,g in z.groupby('candidate'):
   g=g.sort_values('date');actual=np.array([lookup[d] for d in g.date]);top=np.array([[int(x) for x in s.split()] for s in g.top3]);groups=list(g.reset_index(drop=True).groupby(['target',g.date.str[:4].to_numpy()]).indices.values());vals=[]
   for _ in range(99):
    perm=np.arange(len(g))
    for ix in groups:perm[ix]=rng.permutation(ix)
    vals.append(float(h[actual[perm,None],top].any(axis=1).mean()))
   out.append(dict(region=region,digits=k,candidate=name,observed=float(g.hit.mean()),fixed_prediction_shuffle_mean=float(np.mean(vals)),diagnostic95=np.quantile(vals,[.025,.975]).tolist(),permutations=99))
(P/'negative_control.json').write_text(json.dumps(out,indent=2))
print('negative diagnostic',len(out))
