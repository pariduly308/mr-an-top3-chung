import json,datetime,collections,csv,hashlib
from pathlib import Path
import numpy as np
P=Path(__file__).parent
sources=['windows_study/research_10y_data.json','central_study/data.json']
rows=sum([json.load(open(f)) for f in sources],[])
manifest={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in sources}
by=collections.defaultdict(dict); duplicates=0
for r in rows:
 d,s=r['date'],r['station']; nums=r['numbers']
 assert all(isinstance(v,str) and v.isdigit() for v in nums)
 assert len(nums)==(27 if s=='XSMB' else 18)
 if s in by[d]:
  assert by[d][s]==nums; duplicates+=1
 by[d][s]=nums
mn=[['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An'],['Tiền Giang','Kiên Giang']]
mt=[['Huế','Phú Yên'],['Đắk Lắk','Quảng Nam'],['Đà Nẵng'],['Bình Định','Quảng Trị'],['Gia Lai','Ninh Thuận'],['Đà Nẵng','Quảng Ngãi'],['Huế','Kon Tum']]
methods=['frequency','recent10','recent20','recent50','gap','repeat']
def lower(d,y):
 x=datetime.date.fromisoformat(d)
 try:return x.replace(year=x.year-y).isoformat()
 except ValueError:return x.replace(year=x.year-y,month=3,day=1).isoformat()
class Series:
 def __init__(self,rs,k):
  self.d=np.array([d for d,n in rs]);N=10**k;self.nums=np.arange(N);self.c=np.zeros((len(rs),N),np.int16)
  for i,(d,ns) in enumerate(rs):
   for v in ns:
    if len(v)>=k:self.c[i,int(v[-k:])]+=1
  self.h=self.c>0;self.p=np.vstack([np.zeros((1,N),np.int32),np.cumsum(self.h,axis=0,dtype=np.int32)])
  self.last=np.maximum.accumulate(np.where(self.h,np.arange(len(rs))[:,None],-1),axis=0)
 def ranks(self,d,y):
  i=int(np.searchsorted(self.d,d));lo=int(np.searchsorted(self.d,lower(d,y)))
  if i<=lo:return None
  h=self.p[i]-self.p[lo];last=self.last[i-1];gap=np.where(last>=lo,i-last-1,i-lo)
  sc=[h,*[self.p[i]-self.p[max(lo,i-k)] for k in [10,20,50]],h*np.minimum(gap,20)/20,self.c[i-1]]
  return [np.lexsort((self.nums,-h,-s)) for s in sc]
with (P/'rule_predictions.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['region','date','target','digits','rule','top3','hit','distinct'])
 for region,schedule in [('MN',mn),('MT',mt),('MB',[['XSMB']]*7)]:
  ds=[]
  for d,g in sorted(by.items()):
   ss=schedule[datetime.date.fromisoformat(d).weekday()]
   if d<='2026-11-11' and all(s in g for s in ss):ds.append((d,' + '.join(ss),sum([g[s] for s in ss],[])))
  for k in [2,3]:
   S=Series([(d,ns) for d,name,ns in ds],k);N=10**k;nums=np.arange(N)
   trans=np.vstack([np.zeros((1,N)),np.cumsum(S.h[:-1]&S.h[1:],axis=0)])
   for i,(d,name,ns) in enumerate(ds):
    if d<'2021-11-10':continue
    lo=int(np.searchsorted(S.d,lower(d,5)));h=S.p[i]-S.p[lo];prior=(h+1)/(i-lo+2)
    den1=S.p[i-1]-S.p[lo];num1=trans[i-1]-trans[lo]
    den0=(i-1-lo)-den1;num0=(S.p[i]-S.p[lo+1])-num1
    markov=np.where(S.h[i-1],(num1+20*prior)/(den1+20),(num0+20*prior)/(den0+20))
    order=np.lexsort((nums,-h,-S.c[i-1]));last=ds[i-1][2];shift=sum(map(int,last[-1]))
    def rev(n):return int(str(n).zfill(k)[::-1])
    def shadow(n):return int(''.join(str((int(c)+5)%10) for c in str(n).zfill(k)))
    position=[int(last[-1][:k]),int(last[-1][::-1][:k]),int(last[-2][-k:])]
    position=list(dict.fromkeys(position+[int(v) for v in np.lexsort((nums,-h))]))[:3]
    candidates={'markov':np.lexsort((nums,-markov))[:3],'cold':np.lexsort((nums,h))[:3],'reverse':[rev(v) for v in order[:3]],'shadow5':[shadow(v) for v in order[:3]],'sum_shift':[(int(v)+shift)%N for v in order[:3]],'position':position}
    for rule,top in candidates.items():
     assert len(set(top))==3
     distinct=int(S.h[i,top].sum());w.writerow([region,d,name,k,rule,' '.join(str(v).zfill(k) for v in top),int(distinct>0),distinct])
   print('rules',region,k,'done',flush=True)
