import pandas as pd,numpy as np,json
from scipy.stats import binomtest
from pathlib import Path
P=Path(__file__).parent;d=pd.read_csv(P/'predictions.csv');ml=pd.read_csv(P/'ml_predictions.csv');ml['digits']=2;ml['candidate']='ml_'+ml.model
rules=pd.read_csv(P/'rule_predictions.csv');rules['candidate']='rule_'+rules.rule
s=d.copy();s['candidate']=s['mode']+'_'+s.method+'_'+s.years.astype(str)
c=pd.concat([s,ml,rules]);res=[];rng=np.random.default_rng(15112026);mc=[]
for region in ['MN','MT','MB']:
 method='repeat' if region=='MN' else 'frequency'
 for k in [2,3]:
  for scope in (['pair','single'] if region=='MT' else ['all']):
   base=d[(d.region==region)&(d.digits==k)&(d['mode']=='pair')&(d.method==method)]
   zz=c[(c.region==region)&(c.digits==k)]
   if scope!='all':
    base=base[base.target.str.contains(' \\+ ') if scope=='pair' else ~base.target.str.contains(' \\+ ')]
    zz=zz[zz.target.str.contains(' \\+ ') if scope=='pair' else ~zz.target.str.contains(' \\+ ')]
   p=base[base.years==5].uniform.to_numpy();draws=[]
   for _ in range(5):draws.extend((rng.random((1000,len(p)))<p).mean(axis=1).tolist())
   mc.append(dict(region=region,digits=k,scope=scope,n=len(p),mean=float(p.mean()),null95=np.quantile(draws,[.025,.975]).tolist(),simulations=5000))
   for name,g in zz.groupby('candidate'):
    for y in [1,3,5]:
     match=g[['date','hit']].merge(base[base.years==y][['date','hit']],on='date',suffixes=('_a','_b'),validate='one_to_one')
     a=match.hit_a.to_numpy();b=match.hit_b.to_numpy();wins=int(((a==1)&(b==0)).sum());loss=int(((a==0)&(b==1)).sum())
     res.append(dict(region=region,digits=k,scope=scope,candidate=name,baseline_years=y,n=len(a),rate=float(a.mean()),baseline=float(b.mean()),delta=float((a-b).mean()),p=binomtest(wins,wins+loss,.5).pvalue if wins+loss else 1))
order=np.argsort([r['p'] for r in res]);prev=0
for j,i in enumerate(order):prev=max(prev,min(1,res[i]['p']*(len(res)-j)));res[i]['holm']=prev
(P/'holm_all.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));(P/'monte_carlo.json').write_text(json.dumps(mc,indent=2))
print('tests',len(res),'positive significant',sum(r['holm']<.05 and r['delta']>0 for r in res))
print([r for r in res if r['region']=='MB' and r['digits']==2 and r['candidate']=='ml_tree'])
