import json,datetime,csv,collections,warnings
from pathlib import Path
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression,Ridge
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
P=Path(__file__).parent
rows=json.load(open('windows_study/research_10y_data.json'))+json.load(open('central_study/data.json'))
by=collections.defaultdict(dict)
for r in rows:by[r['date']][r['station']]=r['numbers']
MN=[['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An'],['Tiền Giang','Kiên Giang']]
MT=[['Huế','Phú Yên'],['Đắk Lắk','Quảng Nam'],['Đà Nẵng'],['Bình Định','Quảng Trị'],['Gia Lai','Ninh Thuận'],['Đà Nẵng','Quảng Ngãi'],['Huế','Kon Tum']]
with (P/'ml_predictions.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['region','date','target','model','top3','hit','distinct'])
 for region,sch in [('MN',MN),('MT',MT),('MB',[['XSMB']]*7)]:
  ds=[]
  for d,g in sorted(by.items()):
   s=sch[datetime.date.fromisoformat(d).weekday()]
   if d<='2026-11-11' and all(n in g for n in s):ds.append((d,' + '.join(s),sum([g[n] for n in s],[]),len(s)))
  c=np.zeros((len(ds),100),np.int16)
  for i,(d,s,ns,n) in enumerate(ds):
   for v in ns:c[i,int(v[-2:])]+=1
  h=c>0;prefix=np.vstack([np.zeros((1,100)),np.cumsum(h,axis=0)]);last=np.full(100,-1);X=[]
  for i,(d,s,ns,n) in enumerate(ds):
   freq=[(prefix[i]-prefix[max(0,i-k)])/max(1,min(i,k)) for k in [20,50,100]]
   day=datetime.date.fromisoformat(d).weekday();opp=27 if region=='MB' else 18*n
   X.append(np.array([*freq,np.minimum(i-last-1,100)/100,c[i-1]/36 if i else np.zeros(100),np.mean(c[max(0,i-5):i]>1,axis=0) if i else np.zeros(100),np.full(100,min(i/365,1)),np.full(100,opp/36),np.arange(100)/99,np.full(100,np.sin(day*2*np.pi/7)),np.full(100,np.cos(day*2*np.pi/7))]).T)
   last[h[i]]=i
  X=np.array(X);dates=np.array([r[0] for r in ds])
  for year in range(2021,2027):
   start=f'{year}-11-10';end=f'{year+1}-11-10';lo=f'{year-3}-11-10'
   train=(dates>=lo)&(dates<start);test=(dates>=start)&(dates<end)
   if not test.any():continue
   xx=X[train].reshape(-1,X.shape[-1]);yy=h[train].ravel();sc=StandardScaler().fit(xx);xx=sc.transform(xx);tt=sc.transform(X[test].reshape(-1,X.shape[-1]))
   models={'logistic':LogisticRegression(C=1,max_iter=200),'ridge':Ridge(alpha=100),'svm_linear':LinearSVC(C=.01,dual=False,max_iter=2000),'tree':DecisionTreeClassifier(max_depth=4,min_samples_leaf=200,random_state=15112026),'forest':RandomForestClassifier(n_estimators=40,max_depth=5,min_samples_leaf=200,n_jobs=1,random_state=15112026)}
   for name,m in models.items():
    m.fit(xx,yy)
    score=m.predict_proba(tt)[:,1] if hasattr(m,'predict_proba') else m.decision_function(tt) if hasattr(m,'decision_function') else m.predict(tt)
    for i,scores in zip(np.flatnonzero(test),score.reshape(-1,100)):
     top=np.lexsort((np.arange(100),-scores))[:3];distinct=int(h[i,top].sum());w.writerow([region,ds[i][0],ds[i][1],name,' '.join(str(v).zfill(2) for v in top),int(distinct>0),distinct])
   print('ML',region,year,'complete',flush=True)
