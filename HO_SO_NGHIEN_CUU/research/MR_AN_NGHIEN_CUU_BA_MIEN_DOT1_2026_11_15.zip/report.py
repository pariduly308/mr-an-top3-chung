import json,pandas as pd,numpy as np
from pathlib import Path
P=Path(__file__).parent;df=pd.read_csv(P/'predictions.csv');ml=pd.read_csv(P/'ml_predictions.csv');rules=pd.read_csv(P/'rule_predictions.csv');rng=np.random.default_rng(15112026)
ml['digits']=2;ml=ml.rename(columns={'model':'candidate'});rules=rules.rename(columns={'rule':'candidate'});c=pd.concat([ml,rules],ignore_index=True)
results=[]
for region in ['MN','MT','MB']:
 method='repeat' if region=='MN' else 'frequency'
 b=df[(df.region==region)&(df['mode']=='pair')&(df.method==method)&(df.years==5)][['date','digits','hit','uniform']].rename(columns={'hit':'base'})
 z=c[c.region==region].merge(b,on=['date','digits'],validate='many_to_one')
 for scope in (['pair','single'] if region=='MT' else ['all']):
  zz=z if scope=='all' else z[z.target.str.contains(' \\+ ') if scope=='pair' else ~z.target.str.contains(' \\+ ')]
  for (k,model),g in zz.groupby(['digits','candidate']):
   g=g.sort_values('date');a=g.hit.to_numpy();delta=a-g.base.to_numpy();n=len(g);boots=[]
   for _ in range(1000):
    ix=((rng.integers(0,n,(n+6)//7)[:,None]+np.arange(7))%n).ravel()[:n];boots.append(delta[ix].mean())
   results.append(dict(region=region,scope=scope,digits=int(k),candidate=model,n=n,rate=float(a.mean()),base=float(g.base.mean()),uniform=float(g.uniform.mean()),delta=float(delta.mean()),ci95=np.quantile(boots,[.025,.975]).tolist()))
(P/'new_candidates_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
c.groupby(['region','target','digits','candidate',c.date.str[:4]]).hit.agg(['sum','count','mean']).to_csv(P/'new_candidates_by_year.csv')
lines=['# Kết quả nghiên cứu ba miền — 15/11/2026','','**Hồi cứu thăm dò, chưa kiểm chứng tương lai. Không sửa app.**','',f'Đợt1: {len(df):,} dòng; đợt2 ML: {len(ml):,} dòng; đợt3 quy tắc: {len(rules):,} dòng.','Đích chung10/11/2021–11/11/2026. Dữ liệu gốc MN/MB tới11/11,MT tới12/11 nhưng cắt cùng đích. Không phải cập nhật dữ liệu tới15/11.','252 cấu hình đợt1 (có đối chứng lặp lại nghiên cứu cũ),15 cấu hình ML và36 quy tắc =303 cấu hình báo cáo, không phải303 giả thuyết độc lập. Phải cộng lịch sử nghiên cứu trước, không reset.','','## Phạm vi thực hiện','- Đợt1 đủ6côngthức,1/3/5năm,2/3số,học từngđài+Borda/học cặp/chuỗi ngày; MB chỉ một chuỗi.','- Đợt2 pilot2số,5môhình Logistic/Ridge/LinearSVC/DecisionTree/RandomForest,chuỗi ngày,tái huấn luyện hàngnăm bằng3năm trước. Chưa chạy ML3số hay so đủ mọi cửa sổ.','- Đợt3 Markov hiệndiện có làmtrơn,ưu tiên sốít,đảo số,bóng+5,dịch tổng,vịtrí cốđịnh;2/3số. Các phép dân gian là định nghĩa cụ thể trong PROTOCOL_RULES, không đại diện mọi biến thể.','- Chưa chạy RNN/LSTM,GA,bạcnhớ tổhợp,cầuđộng,tamgiác/quảtrám,lịchâm,MonteCarlo/hoánvị. Sổmơ thiếu đầu vào ghi trước; Martingale không đánhgiá khả năng dựbáo.','','## Chất lượng và giới hạn','130.896 dòng MN/MB pair khớp nguyên Top3 và hit với backtest cũ. Kiểm tra nội bộ loại trùng mâu thuẫn, sốgiải và dạng chuỗi số; kế thừa kiểm toán độdài của nguồn, chưa xácminh lại toàn bộHTML.','MN0,MT7,MB20 ngày đích thiếu bảng theo lịch nghiên cứu, chưa tự gán ngàynghỉ. Một số cấu hìnhMT thiếu lịch sử khởi tạo nên n giảm thêm1; thống kê ghép cặp chỉ dùng giao ngày. Lịch hiện tại không chứng minh lịch10năm không đổi;480vịtrí kiểm toán cũ vẫn còn hạn chế.','ĐàNẵng thứTư mộtđài chấm riêng. Hướng members dùng cả kỳ thứBảy củaĐàNẵng; hướng pair mộtđài chỉ dùng các ngày thứTư theo lịch đích. Đây là khác biệt chủ đích trong tổchức lịch sử.','CI95% bootstrapkhối7quan sát,1000lần, mô tả chưa hiệu chỉnh toàn bộ nhiều thử nghiệm. Không gọi CI không chứa0 là bằngchứng thắng sau thửnhiều. Không xem hàngtrăm số cùngkỳ là mẫuđộc lập. Không có quy trình chọn tham số thắng trên test; tham số cốđịnh; mọi giaiđoạn đều đã xem.','Brier/hiệuchỉnh chưa tính trong lượt này; Ridge/SVM/điểm hạng không phải xácsuất. ML xácsuất thô chưa đủ để đưa% lên app.','','## Toàn bộ ứng viên mới','|Miền/phạmvi|Đuôi|Ứngviên|Kỳ|Tỷlệ|Đốichứng5năm|Đồngđều|Chênhđiểm% [CI95%]|','|---|---:|---|---:|---:|---:|---:|---|']
for r in results:
 lines.append(f"|{r['region']}/{r['scope']}|{r['digits']}|{r['candidate']}|{r['n']}|{100*r['rate']:.2f}%|{100*r['base']:.2f}%|{100*r['uniform']:.2f}%|{100*r['delta']:+.2f} [{100*r['ci95'][0]:+.2f};{100*r['ci95'][1]:+.2f}]|")
lines+=['','## Tiếp theo','Ưu tiên kiểm toán và kiểm tra âm tính, hiệu chỉnh nhiều thử nghiệm trước chọn ứngviên. Định trước kiếntrúc/seed/ngânsách cho RNN/LSTM/GA, ánhxạ từngquytắc dân gian, kiểm tra lịchâm bằng thưviện đã xácminh. Không tiếp tục quét côngthức vôhạn. Ứngviên mới cần khóa kỳtươnglai và người dùng đồngý trước áp dụng.','Không tạo/cậpnhật lịch tựđộng trong lượt này. Nhật ký cần nối kết gói này để tiếp tục, không tự coi các thửnghiệm chưa chạy là đã hoàn tất.']
(P/'BAO_CAO.md').write_text('\n'.join(lines))
for r in results:
 if r['digits']==2:print(r)
