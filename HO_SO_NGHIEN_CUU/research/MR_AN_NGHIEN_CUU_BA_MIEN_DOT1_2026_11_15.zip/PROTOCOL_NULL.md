# Đợt4: kiểm tra độ bất định sau kết quả thăm dò
Đã xem kết quảđợt1-3 trước định nghĩa bước này; chỉ kiểmtra bổsung, không biến thành xácnhận độc lập.
MonteCarlo5000 chuỗi chọnTop3đồngđều theo từngkỳ, xácsuất chínhxác1-C(N-U,3)/C(N,3); điều kiện theoU thực tế. Không môphỏng kếtquảgiả thay dữliệunguồn; chỉ môphỏng chỉbáotrúng để so với mốcngẫu nhiên. Không giả đây là hoánvị toàn pipeline tìmkiếm/huấnluyện.
McNemarexact2phía cho mọi ứngviên mới/đợt1 so pair chính tại1/3/5năm cùngkỳ; Holm cho toàn bộ so sánh được tạo. SoMB1năm bắtbuộc, khôngchỉ5năm. Các so sánh lặpđốichứng và tươngđương giữtrong bảng, bảo thủ. Giới hạn: chưahiệuchỉnh tổnglịch sử thửnghiệm ngoài lượt này, blockCI mô tả vẫn chưa đồngthời.
