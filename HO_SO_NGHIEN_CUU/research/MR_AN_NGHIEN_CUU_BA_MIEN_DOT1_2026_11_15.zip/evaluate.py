import pandas as pd,numpy as np,json
from pathlib import Path
P=Path(__file__).parent;df=pd.read_csv(P/'predictions.csv');rng=np.random.default_rng(15112026);out=[]
for region in ['MN','MT','MB']:
 for k in [2,3]:
  for scope in (['pair','single'] if region=='MT' else ['all']):
   z=df[(df.region==region)&(df.digits==k)].copy()
   if scope!='all':z=z[z.target.str.contains(' \\+ ') if scope=='pair' else ~z.target.str.contains(' \\+ ')]
   method='repeat' if region=='MN' else 'frequency'
   baseline=z[(z['mode']=='pair')&(z.method==method)&(z.years==5)].set_index('date').hit
   for (mode,met,y),g in z.groupby(['mode','method','years']):
    g=g.sort_values('date');b=baseline.reindex(g.date).to_numpy();a=g.hit.to_numpy();delta=a-b;n=len(a)
    boot=[]
    for _ in range(1000):
     ix=((rng.integers(0,n,(n+6)//7)[:,None]+np.arange(7))%n).ravel()[:n];boot.append(delta[ix].mean())
    out.append(dict(region=region,digits=k,scope=scope,mode=mode,method=met,years=int(y),n=n,rate=float(a.mean()),uniform=float(g.uniform.mean()),delta_vs_pair5=float(delta.mean()),ci95=np.quantile(boot,[.025,.975]).tolist()))
(P/'comparisons.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('PRIMARY FIXED METHODS; NOT WINNER SELECTION')
for r in out:
 if r['years']==5 and r['method']==('repeat' if r['region']=='MN' else 'frequency'):print(r)
a=json.load(open(P/'audit.json'));print('missing', {k:len(v) for k,v in a['missing_targets'].items()})
# Compare exact original single XSMB and MN pairs on same dates, all methods/windows/digits.
old=pd.read_csv('windows_study/retrospective_predictions.csv',dtype={'top3':str})
new=df[(df['mode']=='pair')&(df.region.isin(['MN','MB']))]
check=new.merge(old,on=['date','target','digits','method','years'],suffixes=('_new','_old'))
assert len(check)==len(new),(len(check),len(new))
assert (check.top3_new==check.top3_old).all()
assert (check.hit_new==check.hit_old).all()
(P/'verification.json').write_text(json.dumps({'matched_original_predictions':len(check),'exact_top3_and_hit_match':True}))
print('exact matches',len(check))
