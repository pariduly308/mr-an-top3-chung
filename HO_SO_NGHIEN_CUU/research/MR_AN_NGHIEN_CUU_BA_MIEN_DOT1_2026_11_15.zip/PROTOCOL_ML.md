# Đợt 2 — mô hình cổ điển, cố định trước chạy
15/11/2026. Pilot 2 số, ba miền, chuỗi ngày chọn đúng đài/cặp đích như đợt 1. Không gọi pilot là đã thử hết cả 2/3 số, mọi cửa sổ, mọi cách tổ chức.
5 mô hình: LogisticRegression C=1 max_iter=200; Ridge alpha=100; LinearSVC C=.01 dual=False max_iter=2000; DecisionTree max_depth=4 min_samples_leaf=200; RandomForest 40 cây max_depth=5 min_samples_leaf=200 n_jobs=1. random_state=15112026. Không tìm tham số, không chọn mô hình thắng để áp dụng.
Đặc trưng từng số: tỷ lệ hiện diện 20/50/100 ngày quá khứ; khoảng vắng chặn100/100; số lần xuất hiện ngày gần nhất/36; tỷ lệ lặp5ngày; số ngày lịch sử/365 chặn1; số giải đích/36; mã số/99; sin/cos thứ. Tất cả trước ngày đích. Ngày đích đủ bảng theo lịch; số giải đích lấy lịch 18/36/27, không lấy kết quả để tạo đặc trưng.
Tái huấn luyện tại 10/11 mỗi năm 2021–2026, dữ liệu huấn luyện 3 năm trước mốc, chấm đến trước mốc kế tiếp hoặc11/11/2026. StandardScaler fit chỉ train. Các kỳ sau trong năm dùng đặc trưng cập nhật sau quan sát kết quả, không refit tham số. Không gọi held-out mới vì lịch sử đã xem; không phân loại 100 số một ngày là 100 kỳ độc lập.
Đối chứng pair-repeat5 MN; pair-frequency5 MT/MB và baseline có điều kiện. Top3 cùng ngày. Ridge/SVM chỉ điểm hạng, không xác suất. Chưa hiệu chỉnh xác suất tree/RF/logistic; không đưa% lên app.
Thêm 15 cấu hình vùng×mô hình, không reset thử trước. 3 số / cửa sổ1-5 / mô hình theo từngđài còn chờ đợt sau.
RNN/LSTM và GA chưa chạy trong đợt này; không gọi nghiên cứu các mô hình cổ điển là đã chạy chúng.
