import json,datetime,collections,csv,hashlib
from pathlib import Path
import numpy as np
P=Path(__file__).parent
sources=['windows_study/research_10y_data.json','central_study/data.json']
rows=sum([json.load(open(f)) for f in sources],[])
manifest={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in sources}
by=collections.defaultdict(dict); duplicates=0
for r in rows:
 d,s=r['date'],r['station']; nums=r['numbers']
 assert all(isinstance(v,str) and v.isdigit() for v in nums)
 assert len(nums)==(27 if s=='XSMB' else 18)
 if s in by[d]:
  assert by[d][s]==nums; duplicates+=1
 by[d][s]=nums
mn=[['TP. HCM','Đồng Tháp'],['Bến Tre','Vũng Tàu'],['Đồng Nai','Cần Thơ'],['Tây Ninh','An Giang'],['Vĩnh Long','Bình Dương'],['TP. HCM','Long An'],['Tiền Giang','Kiên Giang']]
mt=[['Huế','Phú Yên'],['Đắk Lắk','Quảng Nam'],['Đà Nẵng'],['Bình Định','Quảng Trị'],['Gia Lai','Ninh Thuận'],['Đà Nẵng','Quảng Ngãi'],['Huế','Kon Tum']]
methods=['frequency','recent10','recent20','recent50','gap','repeat']
def lower(d,y):
 x=datetime.date.fromisoformat(d)
 try:return x.replace(year=x.year-y).isoformat()
 except ValueError:return x.replace(year=x.year-y,month=3,day=1).isoformat()
class Series:
 def __init__(self,rs,k):
  self.d=np.array([d for d,n in rs]);N=10**k;self.nums=np.arange(N);self.c=np.zeros((len(rs),N),np.int16)
  for i,(d,ns) in enumerate(rs):
   for v in ns:
    if len(v)>=k:self.c[i,int(v[-k:])]+=1
  self.h=self.c>0;self.p=np.vstack([np.zeros((1,N),np.int32),np.cumsum(self.h,axis=0,dtype=np.int32)])
  self.last=np.maximum.accumulate(np.where(self.h,np.arange(len(rs))[:,None],-1),axis=0)
 def ranks(self,d,y):
  i=int(np.searchsorted(self.d,d));lo=int(np.searchsorted(self.d,lower(d,y)))
  if i<=lo:return None
  h=self.p[i]-self.p[lo];last=self.last[i-1];gap=np.where(last>=lo,i-last-1,i-lo)
  sc=[h,*[self.p[i]-self.p[max(lo,i-k)] for k in [10,20,50]],h*np.minimum(gap,20)/20,self.c[i-1]]
  return [np.lexsort((self.nums,-h,-s)) for s in sc]
summary=collections.defaultdict(lambda: [0,0,0.,0,0,0,0]);missing={}
with (P/'predictions.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['region','date','target','digits','years','mode','method','top3','hit','distinct','uniform'])
 for region,schedule in [('MN',mn),('MT',mt),('MB',[['XSMB']]*7)]:
  daily=[];pairs=collections.defaultdict(list);targets=[];miss=[]
  for d,g in sorted(by.items()):
   ss=schedule[datetime.date.fromisoformat(d).weekday()];name=' + '.join(ss)
   if not all(s in g for s in ss):
    if d>='2021-11-10' and d<='2026-11-11':miss.append({'date':d,'missing':[s for s in ss if s not in g]})
    continue
   ns=sum([g[s] for s in ss],[]);daily.append((d,ns));pairs[name].append((d,ns))
   if '2021-11-10'<=d<='2026-11-11':targets.append((d,name,ss,ns))
  missing[region]=miss
  for k in [2,3]:
   N=10**k;dailyS=Series(daily,k);pairS={s:Series(rs,k) for s,rs in pairs.items()}
   memberS={s:Series([(d,g[s]) for d,g in sorted(by.items()) if s in g],k) for s in set(sum(schedule,[]))}
   for d,name,ss,ns in targets:
    actual=set(int(v[-k:]) for v in ns if len(v)>=k);U=len(actual);uniform=1-((N-U)*(N-U-1)*(N-U-2))/(N*(N-1)*(N-2))
    for y in [1,3,5]:
     ranks={'pair':pairS[name].ranks(d,y)}
     if region!='MB':
      ranks['daily']=dailyS.ranks(d,y);rr=[memberS[s].ranks(d,y) for s in ss]
      if all(r is not None for r in rr):
       out=[]
       for m in range(6):
        score=np.zeros(N)
        for r in rr:score[r[m]]+=1-np.arange(N)/(N-1)
        out.append(np.lexsort((np.arange(N),-score)))
       ranks['members']=out
     if any(r is None for r in ranks.values()):continue
     for mode,rs in ranks.items():
      for method,order in zip(methods,rs):
       top=order[:3];distinct=sum(int(v) in actual for v in top);hit=int(distinct>0)
       w.writerow([region,d,name,k,y,mode,method,' '.join(str(v).zfill(k) for v in top),hit,distinct,uniform])
       for yr in ['ALL',d[:4]]:
        a=summary[(region,name,k,y,mode,method,yr)];a[0]+=hit;a[1]+=1;a[2]+=uniform;a[3+distinct]+=1
   print(region,k,'done',len(targets),flush=True)
(P/'summary.json').write_text(json.dumps([dict(zip(['region','target','digits','years','mode','method','year'],key),wins=v[0],n=v[1],rate=v[0]/v[1],uniform=v[2]/v[1],distinct=v[3:]) for key,v in summary.items()],ensure_ascii=False))
(P/'audit.json').write_text(json.dumps({'source_hashes':manifest,'duplicate_identical':duplicates,'missing_targets':missing,'rows':len(rows),'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},ensure_ascii=False))
