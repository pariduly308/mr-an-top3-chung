# Đợt 3 — quy tắc cụ thể, định trước trước chạy
6 quy tắc×3 miền×2/3 chữ số=36 cấu hình. Dùng chuỗi ngày đã định, lịch sử 5 năm cho các thống kê, cùng kỳ đích và đối chứng đợt1. Không có tham số tìm sau chạy.
markov: trạng thái số có/không xuất hiện ngày trước; xác suất hiện diện ngày sau điều kiện đó, prior20 về tần suất hiện diện cửa sổ. Chỉ cặp chuyển tiếp có cả hai thời điểm trước đích; cặp ngày thiếu có thể là quan sát kế tiếp chứ không ngày kế tiếp, ghi hạn chế.
cold: xếp tần suất hiện diện tăng, hòa số tăng (đối chứng trái trực giác).
reverse: xếp số đảo thứ tự chữ số từ xếp hạng tổng lượt xuất hiện của kỳ trước, hòa tần suất hiện diện rồi số tăng; đảo cả chuỗi k chữ số, giữ0.
shadow5: ánh xạ mỗi chữ số+5 modulo10 từ cùng thứ hạng kỳ trước. Đây là một định nghĩa bóng cụ thể, không đại diện mọi bóng dân gian.
sum_shift: dịch giá trị số trong bảng kỳ trước theo tổng chữ số giải đặc biệt cuối bảng modulo10^k, xếp theo thứ hạng kỳ trước như trên. Định nghĩa thăm dò mới, không gọi là công thức chuẩn dân gian.
position: ghép k vị trí đầu chuỗi chữ số giải đặc biệt cuối bảng với chuỗi đảo của nó và k vị trí cuối giải nhất cuối bảng; khửtrùng, bổ sung theo tần suất cũ cho đủ3. Với cặp, thứ tự bảng theo lịch cố định. Chỉ là quy tắc vị trí cụ thể, chưa phải cầu động chọn vị trí qua quá khứ, tam giác hay quả trám.
Mọi điểm không hiệu chỉnh thì không công bố % từngsố. MonteCarlo/hoánvị, bạcnhớ tổhợp, lịchâm, hìnhhọc và cầuđộng vẫn chưa chạy đợt này.
